from sklearnex import patch_sklearn
patch_sklearn()

import random

import numpy as np
import torch

import scipy.sparse as sp

import torch.nn as nn

from sklearn.cluster import KMeans
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score, f1_score
from sklearn.preprocessing import OneHotEncoder, normalize


def set_random_seeds(random_seed=0):
    r"""Sets the seed for generating random numbers."""
    torch.manual_seed(random_seed)
    torch.cuda.manual_seed(random_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(random_seed)
    random.seed(random_seed)


def adj_transform(data):
# def adj_transform(n, edge_index):

    n_nodes = data.x.shape[0]
    adj_index = data.edge_index.detach().cpu()
    value = np.ones(len(adj_index[0]))

    sp_adj = sp.coo_matrix((value, (adj_index[0], adj_index[1])), shape=(n_nodes, n_nodes)).tocsr()
    nodes_to_keep = torch.LongTensor(np.arange(data.x.shape[0]))
    adj_matrix = sp_adj[nodes_to_keep][:, nodes_to_keep]
    # 带自环的邻接矩阵
    adj_matrix = adj_matrix + sp.eye(adj_matrix.shape[0])
    adj_matrix = preprocess_adj(adj_matrix)

    # 不带自环的邻接矩阵
    # adj_matrix = preprocess_adj(adj_matrix, self_loop=False) + 2.5 * sp.eye(adj_matrix.shape[0])

    # print(type(adj_matrix))
    # return adj_matrix
    return scipy_sparse_mat_to_torch_sparse_tensor(adj_matrix)


def scipy_sparse_mat_to_torch_sparse_tensor(sparse_mx):
    """
    将scipy的sparse matrix转换成torch的sparse tensor.
    """
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def generate_adj_like_sparse_weight(data, pos_weight):

    num_nodes = 2708
    # connections = torch.sum(adj_matrix).int().item() - num_nodes
    # pos_weight = nn.Parameter(torch.FloatTensor(size=(1, connections)), requires_grad=True)
    # nn.init.constant_(pos_weight, 0.15)

    indices = data.edge_index.detach().cpu()
    values = pos_weight.squeeze(dim=0)

    return torch.sparse.FloatTensor(indices, values, (num_nodes, num_nodes))


def preprocess_features(features):
    rowsum = np.array(features.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    features = r_mat_inv.dot(features)
    return features
    #return sparse_to_tuple(features)


def normalized_adj(adj):
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))

    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.

    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def preprocess_adj(adj, self_loop=True):
    if self_loop is True:
        adj_normalized = normalized_adj(adj + sp.eye(adj.shape[0]))
    else:
        adj_normalized = normalized_adj(adj)
    return adj_normalized
    #return sparse_to_tuple(adj_normalized)


def binary_cross_loss(label, pred):
    log_pred = torch.log(pred)
    return torch.sum(label * pred)


