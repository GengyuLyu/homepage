import logging

from torch.optim import Adam, AdamW
from tqdm import tqdm

from load_data import get_dataset
from scheduler import CosineDecayScheduler
from logistic_regression_eval import *

from gnn_model import *

import random
import argparse
import os
import utils


def train(step):
    model.train()
    optimizer.zero_grad()

    h_tilde, centroids, h = model(data, step)
    loss = model.cal_loss(h_tilde, centroids, h, data)

    if step % args.eval_epochs == 0:
        print('\nEpoch: ', step, ', Loss: ', loss.item())
    loss.backward()

    optimizer.step()


def pre_train():
    for epoch in range(900):
        model.train()
        # update learning rate
        lr = lr_scheduler.get(epoch)
        for param_group in pre_train_optimizer.param_groups:
            param_group['lr'] = lr

        pre_train_optimizer.zero_grad()
        loss = model.cal_recon_loss(data)
        loss.backward()
        pre_train_optimizer.step()

    eval(1)


def eval(epoch):
    model.eval()
    representations, labels = model.infer(data.x, data.edge_index), data.y

    scores, mi_f1s, ma_f1s = fit_logistic_regression(representations.cpu().numpy(), labels.cpu().numpy(),
                                     data_random_seed=args.data_seed, repeat=args.num_eval_splits)

    print('Acc: ' + str(np.mean(scores)) + ' ± ' + str(np.std(scores)))
    print('MiF1: ' + str(np.mean(mi_f1s)) + ' ± ' + str(np.std(mi_f1s)))
    print('MaF1: ' + str(np.mean(ma_f1s)) + ' ± ' + str(np.std(ma_f1s)))


def set_random_seeds(random_seed=0):
    r"""Sets the seed for generating random numbers."""
    torch.manual_seed(random_seed)
    torch.cuda.manual_seed(random_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(random_seed)
    random.seed(random_seed)


if __name__ == '__main__':

    seed = 2024
    set_random_seeds(seed)
    log = logging.getLogger(__name__)

    parser = argparse.ArgumentParser()

    parser.add_argument('--data_seed', type=int, default=seed)
    parser.add_argument('--num_eval_splits', type=int, default=10)
    parser.add_argument('--gpu_id', type=int, default=0)

    dataset_name = 'citeseer'
    parser.add_argument('--dataset', type=str, default=dataset_name)

    parser.add_argument('--dataset_dir', type=str, default='~/data/' + dataset_name, help='Where the dataset resides.')
    # Training hyperparameters.
    parser.add_argument('--epochs', type=int, default=400)
    parser.add_argument('--lr', type=float, default=5.e-5, help='The learning rate for model training.')  # 5e-5
    parser.add_argument('--weight_decay', type=float, default=6.e-6, help='The value of the weight decay for training.')  # 8.e-5
    parser.add_argument('--lr_warmup_epochs', type=int, default=0, help='Warmup period for learning rate.')

    parser.add_argument('--graph_encoder_layer', type=list, default=[512, 256], help='Conv layer sizes.')
    parser.add_argument('--predictor_hidden_size', type=int, default=512, help='Hidden size of projector.')

    # Evaluation
    parser.add_argument('--eval_epochs', type=int, default=50, help='Evaluate every eval_epochs.')
    args = parser.parse_args()

    device = torch.device('cuda:' + str(args.gpu_id)) if torch.cuda.is_available() else torch.device('cpu')
    # device = torch.device('cpu')
    log.info('Using {} for training.'.format(device))

    dataset = get_dataset(args.dataset_dir, args.dataset)
    num_eval_splits = args.num_eval_splits

    data = dataset[0]
    log.info('Dataset {}, {}.'.format(dataset.__class__.__name__, data))
    data = data.to(device)
    num_clu = torch.max(data.y).item() + 1
    # scheduler
    lr_scheduler = CosineDecayScheduler(args.lr, args.lr_warmup_epochs, args.epochs)

    # build networks
    input_size, representation_size = data.x.size(1), args.graph_encoder_layer[-1]

    model = FGCN([input_size] + args.graph_encoder_layer, num_clu, device).to(device)
    pre_train_optimizer = Adam(list(model.parameters()), lr=5e-5, weight_decay=1.e-5)
    optimizer = Adam(list(model.parameters()), lr=args.lr, weight_decay=args.weight_decay)

    if os.path.exists('citeseer_512_256_0.5_0.5.pkl'):
        model.load_state_dict(torch.load('citeseer_512_256_0.5_0.5.pkl'))
        model = model.to(device)
        eval(0)

    for epoch in tqdm(range(1, args.epochs + 1)):
        train(epoch - 1)
        # if (epoch) % args.eval_epochs == 0:
        #     eval(epoch - 1)
    eval(epoch)


