from sklearnex import patch_sklearn
patch_sklearn()

import torch
import torch.nn as nn
from torch_geometric.nn import BatchNorm, GCNConv

import torch.nn.init as Init
import faiss

import numpy as np
# from load_data import adj_transform

from sklearn.cluster import KMeans
import random

import torch.nn.functional as F


class FGCN(nn.Module):
    def __init__(self, layer_sizes, num_clu, device, batchnorm_mm=0.90, mm_shape='gaussian', dropout_rate=0.5):
        super(FGCN, self).__init__()

        self.input = layer_sizes[0]
        self.hidden = layer_sizes[1]
        self.output = layer_sizes[2]

        self.tau = 1
        self.device = device

        self.batchnorm_mm = batchnorm_mm
        self.mm_shape = mm_shape
        self.num_clu = 30
        self.closest_pro_dis = None
        self.intra_class_distance = 0

        self.clu_flag = True
        self.n_rule = 5
        self.dropout = nn.Dropout(p=dropout_rate)

        self.rep_list = []
        self.closest_pro = []
        self.build_model()

    def build_model(self):
        self.prototype = nn.Parameter(torch.FloatTensor(size=(self.num_clu, self.output)), requires_grad=True)
        self.fuzzyprototype = nn.Parameter(torch.FloatTensor(size=(self.num_clu, self.output)), requires_grad=False)
        self.fls = Fuzzifier(self.output, n_rules=self.n_rule, ante_ms_shape='gaussian').to(self.device)
        self.gc1 = GCNConv(self.input, self.hidden)
        self.gc2 = GCNConv(self.hidden, self.hidden)
        self.gc3 = GCNConv(self.hidden, self.output)

        self.decoder = nn.Sequential(nn.Linear(self.output, self.hidden), nn.ELU(),
                                     nn.Linear(self.hidden, self.hidden), nn.ELU(),
                                     nn.Linear(self.hidden, self.input))

        self.mlp = MLP_Predictor(self.output * 2, self.output)


        self.first = True

        self.act1 = nn.ELU()
        self.act2 = nn.ELU()
        self.act3 = nn.ELU()
        self.bn1 = BatchNorm(self.hidden, momentum=self.batchnorm_mm)
        self.bn2 = BatchNorm(self.hidden, momentum=self.batchnorm_mm)
        self.bn3 = BatchNorm(self.output, momentum=self.batchnorm_mm)

        self.final_miu = None

    def forward(self, data, step):
        x = data.x.detach()
        edge_index = data.edge_index
        x = self.dropout(x)

        h = self.encode(x.clone(), edge_index)
        h = F.normalize(h, p=2, dim=-1)
        h = self.dropout(h)

        if step % 20 == 0:
            miu = self.weighting_prototype(h)
        else:
            miu = self.prototype
        self.closest_pro_dis, self.closest_pro = self.clustering(h, miu)

        h_bar = self.centralization(h, miu)
        h_tilde = self.cal_fuzzy_boundary(h_bar)
        h_hat = self.restore(h_tilde, miu)

        self.update_prototype(h_tilde, miu)
        final_miu = self.mlp(self.final_miu)

        final_miu = F.normalize(final_miu, p=2, dim=-1)

        return h_hat, final_miu, h

    def encode(self, x, edge_index):
        x = self.gc1(x, edge_index)
        x = self.bn1(x)
        x = self.act1(x)
        x = self.dropout(x)

        x = self.gc2(x, edge_index)
        x = self.bn2(x)
        x = self.act2(x)

        x = self.gc3(x, edge_index)
        x = self.bn3(x)
        x = self.act3(x)

        return x

    def decode(self, x, edge_index):
        x = self.decoder(x)
        return x

    def clustering(self, x, prototype):
        distances = self.dis_fun(x, prototype)

        closest_pro = torch.argmin(distances, dim=1)
        closest_pro_dis = torch.min(distances, dim=1)
        return closest_pro_dis, closest_pro

    def centralization(self, x, prototype):
        closest_prototype = prototype[self.closest_pro]
        return x - closest_prototype

    def cal_fuzzy_boundary(self, x):
        fz_degree, x = self.fls.fuzzify(x)
        return x

    def cal_loss(self, h_tilde, final_proto, h, data, tau=3.2):
        h_pro_dis = torch.exp(- self.dis_fun(h_tilde, final_proto) * tau)
        inter_dis = torch.sum(h_pro_dis, dim=-1)
        index = self.closest_pro
        index = torch.tensor(list(range(0, self.num_clu * index.shape[0], self.num_clu))).to(self.device) + index
        intra_dis = h_pro_dis.reshape(-1, 1)[index].squeeze(dim=-1)
        contrastive_loss = -torch.log(intra_dis / inter_dis).mean()

        alpha = 0.
        X = self.decode(h, data.edge_index)
        recon_loss = F.mse_loss(X, data.x)
        loss = contrastive_loss + alpha * recon_loss
        return loss

    def cal_recon_loss(self, data):
        h_hat = self.encode(data.x, data.edge_index)
        X = self.decode(h_hat, data.edge_index)
        recon_loss = F.mse_loss(X, data.x)
        loss = recon_loss
        return loss

    @staticmethod
    def dis_fun(x, c):
        xx = (x * x).sum(-1).reshape(-1, 1).repeat(1, c.shape[0])
        cc = (c * c).sum(-1).reshape(1, -1).repeat(x.shape[0], 1)
        xx_cc = xx + cc
        xc = x @ c.T
        distance = xx_cc - 2 * xc
        return distance

    def weighting_prototype(self, x, niter=10):
        kmeans = faiss.Kmeans(x.shape[1], self.num_clu, niter=niter)
        kmeans.train(x.cpu().detach().numpy())
        centroids = torch.FloatTensor(kmeans.centroids).to(x.device)
        self.prototype.data = centroids
        return centroids

    def update_prototype(self, h_tilde, prototype, adjust_affiliation=False):
        alpha = 0.99
        fuzzy_prototype_list = []

        classes = np.unique(self.closest_pro.detach().cpu().numpy())
        for c in classes.tolist():
            indices = torch.where(self.closest_pro == c)
            fuzzy_prototype = torch.mean(h_tilde[indices[0]], axis=0)
            fuzzy_prototype_list.append(fuzzy_prototype)
            self.fuzzyprototype[c].data = fuzzy_prototype
        fuzzy_prototype = torch.stack(fuzzy_prototype_list, dim=1).transpose(0, 1)

        if self.final_miu is None:
            self.final_miu = torch.cat((prototype, fuzzy_prototype), dim=1)
        else:
            self.final_miu = self.final_miu.detach()
        self.final_miu[classes] = torch.cat((prototype[classes], fuzzy_prototype), dim=1)

    def restore(self, x, prototype):
        closest_prototype = prototype[self.closest_pro]
        return x + closest_prototype

    @torch.no_grad()
    def infer(self, x, edge_index):
        return self.encode(x, edge_index)


def feat_mask(x, mask_ratio=0.):
    mask = torch.rand(x.shape[1]).to(x.device)
    x[:, mask <= mask_ratio] = 0
    return x

def sim(z1, z2):
    z1 = F.normalize(z1)
    z2 = F.normalize(z2)
    return torch.mm(z1, z2.t())

def kmean_init(x_train, n_rules):
    Vs = np.ones([x_train.shape[1], n_rules])

    km = KMeans(n_rules, n_init=1)
    km.fit(x_train)
    Cs = km.cluster_centers_.T
    return Cs, None


class Fuzzifier(nn.Module):
    def __init__(self, in_dim, n_rules, ante_ms_shape='gaussian'):
        super(Fuzzifier, self).__init__()
        self.in_dim = in_dim
        self.n_rules = n_rules
        self.eps = 1e-10

        self.ante_ms_shape = ante_ms_shape

        self.build_model()

    def build_model(self):

        self.fz_weight = nn.Parameter(torch.FloatTensor(size=(1, self.n_rules)), requires_grad=True)
        Init.uniform_(self.fz_weight, 0, 1)

        if self.ante_ms_shape == 'gaussian':
            self.Cs = nn.Parameter(torch.FloatTensor(size=(self.in_dim, self.n_rules)), requires_grad=True)
            Init.normal_(self.Cs, mean=0, std=1)
            self.Vs = nn.Parameter(torch.FloatTensor(size=self.Cs.size()), requires_grad=True)

    def fuzzify(self, features):
        if self.ante_ms_shape == 'gaussian':
            sigma = F.relu(self.Vs)
            fz_degree = -(features.unsqueeze(dim=2) - self.Cs) ** 2 / ((2 * sigma ** 2) + self.eps)

            fz_degree = torch.exp(fz_degree)
            weighted_fz_degree = torch.max(fz_degree, dim=2)[0]
        fz_features = torch.mul(features, 2. - weighted_fz_degree)

        return weighted_fz_degree, fz_features


class MLP_Predictor(nn.Module):
    def __init__(self, input_size, output_size):
        super().__init__()
        hidden_size = input_size
        self.net = nn.Sequential(
            nn.Linear(input_size, hidden_size, bias=True),
            nn.ELU(),
            nn.Linear(hidden_size, output_size, bias=True),
        )
        self.reset_parameters()

    def forward(self, x):
        return self.net(x)

    def reset_parameters(self):
        # kaiming_uniform
        for m in self.modules():
            if isinstance(m, nn.Linear):
                m.reset_parameters()


