import numpy as np
import torch
import random
import torch.nn.functional as F

import scipy.io as scio

def set_seed(seed, cuda=True):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if cuda:
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

def partial_loss(output1, target):
    output = F.softmax(output1, dim=1)  #256x10
    l = target * torch.log(output)  #(256x10)
    loss = (-torch.sum(l)) / l.size(0) # 3.2405

    revisedY = target.clone()
    revisedY[revisedY > 0]  = 1
    revisedY = revisedY * output  # 256x10
    revisedY = revisedY / revisedY.sum(dim=1).repeat(revisedY.size(1),1).transpose(0,1)#256x10

    new_target = revisedY


    return loss, new_target

def evaluate(model, features, label_feats, labels):
    model.eval()
    with torch.no_grad():
        logits = model(features, label_feats) #(1010, 16)
        _, indices = torch.max(logits, dim=1) #1010
        correct = torch.sum(indices == labels)
        return correct.item() * 1.0 / len(labels), indices


#获得K折交叉验证某一折的训练集和验证集
def get_kfold_data(k, i, data_path):
    # 返回第 i+1 折 (i = 0 -> k-1) 交叉验证时所需要的训练和验证数据，X_train为训练集，X_valid为验证集
    dataset = scio.loadmat(data_path)
    X = torch.from_numpy(dataset['data'])
    yp = torch.from_numpy(dataset['partial_target']).T  # target  labels
    yt = torch.from_numpy(dataset['target']).T
    label_feats = torch.eye(yp.shape[1])

    #random shuffle
    index = [i for i in range(len(X))]
    random.shuffle(index)
    X, yp, yt = X[index], yp[index], yt[index]

    fold_size = X.shape[0] // k  # 每份的个数:数据总条数/折数（组数）
    val_start = i * fold_size
    if i != k - 1:
        val_end = (i + 1) * fold_size
        X_valid, yt_valid = X[val_start:val_end], yt[val_start:val_end]
        X_train = torch.cat((X[0:val_start], X[val_end:]), dim=0)
        yp_train = torch.cat((yp[0:val_start], yp[val_end:]), dim=0)
        yt_train = torch.cat((yt[0:val_start], yt[val_end:]), dim=0)
    else:  # 若是最后一折交叉验证
        X_valid, yt_valid = X[val_start:], yt[val_start:]  # 若不能整除，将多的case放在最后一折里
        X_train = X[0:val_start]
        yp_train = yp[0:val_start]
        yt_train = yt[0:val_start]

    return X_train, yp_train, yt_train, X_valid, yt_valid, label_feats

