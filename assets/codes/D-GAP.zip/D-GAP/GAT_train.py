import torch
import os
from sklearn.metrics.pairwise import pairwise_distances
import numpy as np
from mymodel import GAT
import torch.nn.functional as F
import dgl
import argparse
from util import evaluate, partial_loss, get_kfold_data, set_seed


parser = argparse.ArgumentParser(description='PyTorch ImageNet Training')
parser.add_argument('--dataset', default='glass_r1p1.mat', type=str, metavar='N', help='run_data')
parser.add_argument('--data_root', default='./dataset/synthetic_dataset/abalone/', type=str, metavar='PATH',
					help='root dir')
parser.add_argument('--train_k', default=3, type=int, help='KNN')
parser.add_argument('--test_k', default=5, type=int, help='KNN')
parser.add_argument('--kfold', default=10, type=int, metavar='H-P', help='k-fold cross validation')
parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
					help='manual epoch number (useful on restarts)')
parser.add_argument('--end_epochs', default=100, type=int, metavar='H-P',
					help='number of total epochs to run')
parser.add_argument('--lr', default=0.001, type=float,
					metavar='H-P', help='initial learning rate')
parser.add_argument('--nheads', default=3, type=int,
					metavar='H-P', help='num_heads')
parser.add_argument('--nlayers', default=1, type=int,
					metavar='H-P', help='n_layers')
parser.add_argument('--num_out_heads', default=1, type=int,
					metavar='H-P', help='num_out_heads')
parser.add_argument('--nhidden', default=64, type=int,
					metavar='H-P', help='n_hidden')
parser.add_argument('--seed', default=42, type=int,
					metavar='H-P', help='n_seed')
parser.add_argument('--gamma', default=1, type=float,
					metavar='H-P', help='scheduler.ExponentialLR')
parser.add_argument('--filter', default=True, type=bool,
					metavar='H-P', help='filter')
parser.add_argument('--visual', default=False, type=bool,
					metavar='H-P', help='filter')

args = parser.parse_args()

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

set_seed(args.seed)

train_loss_sum, valid_loss_sum = 0, 0
train_acc_sum, valid_acc_sum = 0, 0
start = 0

def traink(k, model, X_train, yp_train, yt_train, X_valid, yt_valid, label_feats, test_topk_index):

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0005)

    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[500, 1500], gamma=0.5)

    best_epoch, best_acc = 0, 0
    train_loss, train_acc_list, test_acc_list = [], [], []
    for epoch in range(args.end_epochs):
        model.train()
        out = model(X_train, label_feats)
        loss, new_label = partial_loss(out, yp_train)
        train_loss.append(loss)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        scheduler.step()

        yp_train = new_label.detach()

        acc, pred_index = evaluate(model, X_train, label_feats, yt_train.argmax(1))

        epoch_test_pred = []
        for m in range(yt_valid.shape[0]):
            a = test_topk_index[m]
            b = pred_index[a].tolist()
            epoch_test_pred.append(max(b, key=b.count))

        test_correct = torch.sum(torch.tensor(epoch_test_pred).cuda() == yt_valid.argmax(1))
        test_acc = test_correct.item() * 1.0 / len(yt_valid)


        if best_acc < acc:
            best_acc = acc
            best_epoch = epoch
        print('epoch: ' + str(epoch) + '  loss:' + str(loss.item()) + '  train_acc:' + str(acc) + ' test_acc:' + str(test_acc))
        train_acc_list.append(acc)
        test_acc_list.append(test_acc)

    print('best epoch:' + str(best_epoch) + '    ' + 'best train_acc:' + str(best_acc)+ '    ' + 'best test_acc:' + str(max(test_acc_list)))


    return train_loss, train_acc_list, test_acc_list

for i in range(args.kfold):
    print('*'*25, i+1, '折', '*'*25)
    X_train, yp_train, yt_train, X_valid, yt_valid, label_feats = get_kfold_data(args.kfold, i, args.data_root+args.dataset)

    data_dist = pairwise_distances(X_train, metric='euclidean')
    topk_dist, topk_index = torch.from_numpy(data_dist).topk(dim=1, k=args.train_k, largest=False, sorted=True)  #(1122, 5)
    ins_num, k = topk_index.size()

    dist_idx = topk_index.reshape(-1, 1).type(torch.long) #1122x5=5610, 1
    src_idx = torch.from_numpy(np.array(list(range(ins_num))).repeat(k).reshape(-1, 1)).type(torch.long) #(5610,1)

    test_dist = pairwise_distances(X_valid, X_train, metric='euclidean')  # (112, 1010)
    test_topk_dist, test_topk_index = torch.from_numpy(test_dist).topk(dim=1, k=args.test_k, largest=False, sorted=True)  # (112,5)

    if args.filter:
        flag_list = []
        for j in range(src_idx.shape[0]):
            flag = torch.max(yp_train[src_idx[j]] + yp_train[dist_idx[j]]) < 2
            flag_list.append(flag.tolist())
        filter_index = [i for i, x in enumerate(flag_list) if x is False]
        dist_idx = dist_idx[torch.tensor(filter_index)]
        src_idx = src_idx[torch.tensor(filter_index)]
    ins_edge_index = torch.cat((src_idx, dist_idx), dim=1).transpose(1, 0)  # (2,5610)

    edges1 = ins_edge_index[1].int(), ins_edge_index[0].int()

    g = dgl.graph(edges1)

    heads = ([args.nheads] * args.nlayers) + [args.num_out_heads]  # [8, 1]

    if torch.cuda.is_available():
        g = g.to('cuda:0')
        X_train, yp_train, yt_train, X_valid, yt_valid, label_feats = X_train.float().cuda(), yp_train.cuda(), yt_train.cuda(), X_valid.float().cuda(), yt_valid.cuda(), label_feats.float().cuda()
    else:
        X_train, yp_train, yt_train, X_valid, yt_valid, label_feats = X_train.float(), yp_train, yt_train, X_valid.float(), yt_valid, label_feats.float()

    g.ndata['label'] = yt_train.argmax(1).reshape(-1, 1)

    def msg(edges):
        return {'m':edges.src['label']==edges.dst['label']}

    g.apply_edges(msg)
    print('homelity: '+str(torch.true_divide(g.edata['m'].sum(), g.number_of_edges())))

    Mymodel = GAT(g, args.nlayers, X_train.shape[1], args.nhidden, yp_train.shape[1], heads, F.elu, .2, .2, .2, True)

    if torch.cuda.is_available():
        Mymodel = Mymodel.cuda()

    train_loss, train_acc, val_acc = traink(i, Mymodel, X_train, yp_train, yt_train, X_valid, yt_valid, label_feats, test_topk_index)

    print('train_loss:{:.5f}, train_acc:{:.3f}%'.format(train_loss[-1], max(train_acc)))
    print('valid_acc:{:.4f}%\n'.format(max(val_acc)))

    train_loss_sum += train_loss[-1]
    train_acc_sum += max(train_acc)
    valid_acc_sum += max(val_acc)


print('\n', '#' * 10, '最终k折交叉验证结果', '#' * 10)

print('average train loss:{:.4f}, average train accuracy:{:.3f}'.format(train_loss_sum / args.kfold, train_acc_sum / args.kfold))
print('average valid accuracy:{:.3f}'.format(valid_acc_sum / args.kfold))
