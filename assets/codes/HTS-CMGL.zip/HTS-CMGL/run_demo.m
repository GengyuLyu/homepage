clear
close all
currentFolder = pwd;
addpath(genpath('.'));
addpath([currentFolder, '\funs']);
addpath([currentFolder, '\dataset']);
dataName = 'MSRC-v6'; 
load([dataName, '.mat']);
data= X;
label= Y;
nV = length(data);
for v = 1:nV
    data{v} = normalization(data{v}, 'minmax', 1);
end
%100leaves gamma=1e1;lambda=10，minmax;
%COIL20 gamma=1e-3;lambda=5，l2;
tic;
beta=1e-1;
delta=1e-3;

gamma=1e-2;                                                                                                                  
lambda=5;
[S,y,converge_C,converge_E,C,E,A] = train1(data,label,beta,gamma,delta,lambda);
time = toc;
res = EvaluationMetrics(label, y)
%%%%%%%%%%plot S
% figure()
% S1 = mapminmax(S, 0, 1);
% imshow(S1)
% colormap('jet');
