function [S, y,Convergence, converge_C, converge_E, C, E, A] = train1(data, labels, beta, gamma, delta, lambda, knn)
% TRAIN Main training function for the multi-view clustering model.
%
% Inputs:
%   data    - Cell array of multi-view data
%   labels  - Ground truth labels
%   beta    - Consistency tensor
%   gamma   - diversity tensor
%   delta   - ETR parameters
%   lambda  - Laplacian constraint parameters
%   const   - Parameter for graph construction
%   knn     - Number of nearest neighbors

    % --- Default Parameters ---
    if nargin < 7
        knn = 10;
    end
    % --- Basic Information ---
    numSmp  = length(labels);
    numC    = length(unique(labels));
    numView = length(data);
    sX      = [numSmp, numSmp, numView];

    %% ======================= 1. Initialization =======================
    % Initialize container variables
    A = cell(numView, 1);
    C = cell(numView, 1);
    E = cell(numView, 1);
    J = cell(numView, 1);
    G = cell(numView, 1);
    M = cell(numView, 1);
    N = cell(numView, 1);

    for v = 1:numView
        A{v} = zeros(numSmp);
        C{v} = zeros(numSmp);
        E{v} = zeros(numSmp);
        J{v} = zeros(numSmp);
        G{v} = zeros(numSmp);
        M{v} = zeros(numSmp);
        N{v} = zeros(numSmp);
    end
    Convergence=zeros(100,1);

    %% ================== 2. Construct Initial Graphs ==================
    for v = 1:numView
        A{v} = constructW(data{v}, knn, 1);
    end

    % Initialize S and weights mu
    mu = ones(numView, 1) / numView;
    S0 = zeros(numSmp);
    for v = 1:numView
        S0 = S0 + mu(v) * A{v};
    end
    S = S0;

    % Initialize F
    S0  = S0 - diag(diag(S0));
    S10 = (S0 + S0') / 2;
    D10 = diag(sum(S10));
    L0  = D10 - S10;
    [F0, ~, ~] = eig1(L0, numSmp, 0);
    F = F0(:, 2:(numC + 1));

    %% ================= 3. Optimization Parameters ==================
    Isconverg  = 0;
    epson      = 1e-7;
    max_iter   = 50;
    zr         = 1e-10;

    % ADMM Parameters
    rho=1e-4;
    varphi=1e-2;
    max_rho    = 1e10;
    max_varphi = 1e10;
    tau_inc    = 2;
    tan_varphi = 2;
    tau_lambda = 1.5;

    % History Recording
    converge_C = [];
    converge_E = [];
    iter       = 1;
    %% ===================== 4. Optimization Loop ====================
    while (Isconverg == 0 && iter <= max_iter)
        %% -------- Step 1: Update C (Consistency Graph) --------
        for v = 1:numView
            tmp = 2 * mu(v) * S + rho * J{v} - M{v} + varphi * (A{v} - G{v})+ N{v};
            C{v} = tmp / (2 * mu(v) + rho + varphi);
            C{v} = max(C{v}, C{v}');
            C{v} = max(C{v}, 0);
            C{v} = min(C{v}, A{v});
            
            E{v}=A{v}-C{v};
        end
        %% -------- Step 2: Update S (Consensus Graph) --------
        dist = L2_distance_1(F', F');
        S    = zeros(numSmp);
        
        for i = 1:numSmp
            c0 = zeros(1, numSmp);
            for v = 1:numView
                c0 = c0 + mu(v) * C{v}(i, :);
            end
            
            idxa0 = find(c0 > 0);
            if ~isempty(idxa0)
                ci = c0(idxa0);
                ui = dist(i, idxa0);
                
                % Rank constraint projection
                cu = (ci - 0.5 * lambda * ui) / sum(mu);
                S(i, idxa0) = EProjSimplex_new(cu);
            end
        end

        %% -------- Step 3: Update mu (View Weights) --------
        total_error = 0;
        for v = 1:numView
            error_v = norm(S - C{v}, 'fro')^2;
            if error_v > 1e-10
                total_error = total_error + 0.5 / error_v;
            end
        end

        for v = 1:numView
            error_v = norm(S - C{v}, 'fro')^2;
            if error_v > 1e-10
                mu(v) = (0.5 / error_v) / total_error;
            else
                mu(v) = 0.5 / numView;
            end
        end
        %% -------- Step 4: Update F (Indicator Matrix) --------
        S1  = (S + S') / 2;
        D   = diag(sum(S1));
        L   = D - S1;
        F_old = F;
        [F, ~, ev] = eig1(L, numC, 0);

        %% -------- Step 5: Update lambda (Rank Parameter) --------
        fn1 = sum(ev(1:numC));
        fn2 = sum(ev(1:numC + 1));
        
        if fn1 > zr 
            lambda = lambda * tau_lambda;
        elseif fn2 < zr
            lambda = lambda / tau_lambda;
            F = F_old;
        else
        end       

        %% -------- Step 6: Update J (Low-Rank Tensor) --------
        C_tensor = cat(3, C{:,:});
        M_tensor = cat(3, M{:,:});
        J_tensor = solve_ETR(C_tensor + 1/rho * M_tensor, rho/beta, sX, delta);
        c = C_tensor(:);
        m = M_tensor(:);
        j = J_tensor(:);

        %% -------- Step 7: Update G (Sparse/Diversity Tensor) --------
        E_tensor = cat(3, E{:,:});
        N_tensor = cat(3, N{:,:});
        G_tensor = solve_Gexp((varphi * E_tensor + N_tensor) / varphi, varphi, gamma, sX);
        e = E_tensor(:);
        n = N_tensor(:);
        g = G_tensor(:);

        %% -------- Step 8: Update Multipliers M, N --------
        m = m + rho * (c - j);
        n = n + varphi * (e - g);
        
        M_tensor = reshape(m, sX);
        N_tensor = reshape(n, sX);
        
        for k = 1:numView
            M{k} = M_tensor(:, :, k);
            N{k} = N_tensor(:, :, k);
            J{k} = J_tensor(:, :, k);
            G{k} = G_tensor(:, :, k);
        end

        %% -------- Step 9: Update Parameters rho, varphi --------
        varphi = min(varphi * tan_varphi, max_varphi);
        rho    = min(rho * tau_inc, max_rho);

        %% -------- Step 10: Convergence Check --------
        max_C = 0;
        max_E = 0;
        Isconverg = 1;
        
        for k = 1:numView
            % % Check consistency constraint
            if norm(C{k} - J{k}, inf) > epson
                Isconverg = 0;
                max_C = max(max_C, norm(C{k} - J{k}, inf));
            end
            
            % Check diversity/noise constraint
            if norm(E{k} - G{k}, inf) > epson
                Isconverg = 0;
                max_E = max(max_E, norm(E{k} - G{k}, inf));
            end
        end
        converge_C = [converge_C, max_C];
        converge_E = [converge_E, max_E];

        iter = iter + 1;
    end
    %% ======================= 5. Final Processing =======================
    S = (S + S') / 2;
    y = conncomp(graph(S), 'OutputForm', 'vector');
    y = y';
end