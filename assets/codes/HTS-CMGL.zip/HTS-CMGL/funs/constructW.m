% construct similarity matrix with probabilistic k-nearest neighbors. It is a parameter free, distance consistent similarity.
function W = constructW(X, k, issymmetric)
% X: each column is a data point
% k: number of neighbors
% issymmetric: set W = (W+W')/2 if issymmetric=1是否对称
% W: similarity matrix

X=X';
[dim, n] = size(X);
D = L2_distance_1(X, X);%所有样本对的平方欧氏距离
[dumb, idx] = sort(D, 2); % sort each row行排序得到最近邻索引，

W = zeros(n);
for i = 1:n
    id = idx(i,2:k+2);
    di = D(i, id);
    sigma_i = D(i, idx(i, k+1));
    W(i,id) = exp(-di.^2 / (2 * sigma_i^2));
end

if issymmetric == 1%实现对称
    W = (W+W')/2;
end


