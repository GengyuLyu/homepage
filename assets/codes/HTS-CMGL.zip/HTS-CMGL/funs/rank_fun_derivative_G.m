function y = rank_fun_derivative_G(x)
y  = log(1+x)+x./(1+x);
end