function y = rank_fun_derivative(x,delta)
y  = delta*exp(delta^2)./((x+delta).^2+eps);

end
