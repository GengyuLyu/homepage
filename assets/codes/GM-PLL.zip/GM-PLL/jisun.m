function jisun(x, matches, target)

filtered = zeros(size(target));
for i = 1 : length(x)
    if x(i) > 0.5
        filtered(matches(i,1), matches(i,2)) = 1;
    end
end

num = sum(filtered(:) .* target(:));
accuracy = num / size(target, 2);

fprintf(' train accuracy: %f  ', full(accuracy));

end