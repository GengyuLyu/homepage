

function [affinity,instance_group,label_group, matches] = cal_center3(train_data,partial_label,first_limit,m_bei,end_limit)


ins_conn = pdist2(train_data,train_data,'cosine');

zuida = max(max(ins_conn));
ins_conn = 1 - ins_conn/zuida;

[labels, instances, ~] = find(partial_label);
affinity_row = length(labels);
affinity_col = length(labels);

instance_group = zeros(affinity_row, size(partial_label, 2));
label_group = zeros(affinity_row, size(partial_label,1));
for i = 1 : affinity_row
    instance_group(i, instances(i)) = 1;
    label_group(i, labels(i)) = 1;
end

affinity = zeros(affinity_row, affinity_col);
for i = 1 : affinity_row
    for j = 1 : affinity_col
        if (labels(i) == labels(j))
            affinity(i,j) = ins_conn(instances(i), instances(j));
        else
            affinity(i,j) = (1 - ins_conn(instances(i),instances(j)));          
        end
    end
end

temp_affinity1 = affinity;
temp_affinity2 = affinity;

affinity(affinity < first_limit) = 0.00001; 

for h = 1 : size(affinity,1) 
    for i = 1 : size(partial_label,1)
        a = find(labels == i);
        [r,c] = find(affinity(h,a) > 0.000001);
        temp_affinity1(h,a) = ((affinity(h,a) * length(c)));
    end
    for i = 1 : size(partial_label,1)
        a = find(labels == i);
        [r,c] = find(affinity(a,h) > 0.000001);
        temp_affinity2(a,h) = ((affinity(a,h) * length(c)));
    end
end


    affinity = affinity .* (1 + m_bei .* log2(temp_affinity1 + temp_affinity2));
    matches = [labels, instances];
    
 

affinity(affinity < end_limit) = 0;

save affinity.mat affinity;
save matches.mat matches;
save instance_group.mat instance_group;
save label_group.mat label_group;

end
