function accuarcy = predict5( train_data,test_data,train_target,test_GT,train_p_target,first_limit,m_bei,end_limit,zuidaxge)

data = [train_data;test_data];

train_data = normr(train_data);
kdtree = KDTreeSearcher(train_data);
model.kdtree = kdtree;

testData = (test_data);
[testNeighbor,testDist] = knnsearch(model.kdtree,testData,'k',10);

neighbor_label = [];
for i = 1 : size(test_data,1)
    neighborIns = data(testNeighbor(i,:),:)';
    w = lsqnonneg(neighborIns,testData(i,:)');
    
    neighbor_target = train_p_target(:,testNeighbor(i,:));
    w = w';
    w = repmat(w,size(neighbor_target,1),1);
    neighbor_label = [neighbor_label, sum((w .* neighbor_target),2)];
end


 neighbor_label = full(neighbor_label);
 
 for zuixiao = 1 : zuidaxge
 [min_neigh_value,min_neigh_index] = min(neighbor_label);
 for i = 1 : size(neighbor_label,2)
     j = min_neigh_index(1,i);
     neighbor_label(j,i) = 100;
 end
 end
 neighbor_label(neighbor_label < 100) = 1;
 neighbor_label(neighbor_label == 100) = 0;

hy_test_target = neighbor_label;

save neighbor_label.mat neighbor_label;
target = [train_target,hy_test_target];

ins_conn = pdist2(data,data,'cosine');

zuida = max(max(ins_conn));
ins_conn = 1 - ins_conn/zuida;

[labels, instances, ~] = find(target);
affinity_row = length(labels);
affinity_col = length(labels);

instance_group = zeros(affinity_row, size(target, 2));
label_group = zeros(affinity_row, size(target,1));
for i = 1 : affinity_row
    instance_group(i, instances(i)) = 1;
    label_group(i, labels(i)) = 1;
end

affinity = zeros(affinity_row, affinity_col);
for i = 1 : affinity_row
    for j = 1 : affinity_col
        if (labels(i) == labels(j))
            affinity(i,j) = ins_conn(instances(i), instances(j));
        else
            affinity(i,j) = (1 - ins_conn(instances(i),instances(j)));          
        end
    end
end


temp_affinity1 = affinity;
temp_affinity2 = affinity;

affinity(affinity < first_limit) = 0.00001; 
for h = 1 : size(affinity,1) 
    for i = 1 : size(target,1)
        a = find(labels == i);
        [r,c] = find(affinity(h,a) > 0.000001);
        temp_affinity1(h,a) = ((affinity(h,a) * length(c)));
    end
    for i = 1 : size(target,1)
        a = find(labels == i);
        [r,c] = find(affinity(a,h) > 0.000001);
        temp_affinity2(a,h) = ((affinity(a,h) * length(c)));
    end
end

affinity = affinity .* (1 + m_bei .* log2(temp_affinity1 + temp_affinity2));


matches = [labels, instances];



affinity(affinity < end_limit) = 0; 
save affinity.mat affinity;
save matches.mat matches;
save instance_group.mat instance_group;
save label_group.mat label_group;


affinity = sparse(affinity);
x = PSM(affinity, instance_group);
save x.mat x;




train_target = zeros(size(target));
for k = 1 : length(x)
    if x(k) > 0.5
       train_target(matches(k,1), matches(k,2)) = 1;
    end
end
init = size(train_data,1) + 1;
fini = size(train_data,1) + size(test_data,1);
test_target = train_target(:,init:fini);

result = test_target .* test_GT;
number = sum(sum(result ~= 0));

accuarcy = number/size(test_target,2);
fprintf('test_accuracy: %f \n',full(accuarcy));

end