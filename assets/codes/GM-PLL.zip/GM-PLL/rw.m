load('lost.mat');


sum1 = 0;
[row,col]=size(data);
data = zscore(data);

first_limit = 0.3;
m_bei = 0.5;       
end_limit = 1.4;  
r = 3;            
zuidaxge = size(target,1) - r;


encode=crossvalind('Kfold',data(1:row,col),10);
for i=1:10
    test=(encode==i);
    train_data = data(~test,:);
    test_data=data(test,:);
    train_p_target=partial_target(:,~test);
    test_target=target(:,test);
    train_GT = target(:,~test);
    tic;
    [affinity,instance_group,label_group, matches] = cal_center3(train_data,train_p_target,first_limit,m_bei,end_limit);
    affinity = sparse(affinity);
    haha = sum(sum(affinity~= 0));
    x = PSM(affinity, instance_group,100);
    save x.mat x;
    train_target = zeros(size(train_p_target));
    for k = 1 : length(x)
        if x(k) > 0.5
            train_target(matches(k,1), matches(k,2)) = 1;
        end
    end
    jisun(x, matches, train_GT); 

    accuracy = predict5( train_data,test_data,train_target,test_target,train_p_target,first_limit,m_bei,end_limit,zuidaxge );

    sum1 = sum1 + accuracy;
    
end
fprintf('%f : average accuracy = %f\n',first_limit,sum1/10);

