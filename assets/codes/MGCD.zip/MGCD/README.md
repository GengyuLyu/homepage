# MGCD
Measuring Consistency and Diversity: A Structured Graph Learning Framework for Federated Multi-View Clustering

run main.py to train and valid the performance of MGCD