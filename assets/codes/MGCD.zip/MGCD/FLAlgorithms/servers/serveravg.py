import torch
import os
import pandas as pd
from torch import nn
from torch.utils.data import DataLoader

from FLAlgorithms.users.useravg import UserAVG
from FLAlgorithms.servers.serverbase import Server
import numpy as np
from data import dataloader
from node2vec import Node2Vec
import networkx as nx
from FLAlgorithms.trainmodel import trainmodels

# Implementation for FedAvg Server

class FedAvg(Server):
    def __init__(self, batch_size, device, dataset, learning_rate, feature_dim_ae, num_ae_epochs,
                                  num_glob_iters, local_epochs, cl_epochs,
                                  data, dims, view, data_size, class_num,
                                  clients_lamda1,
                                  server_lamda1):
        super().__init__(batch_size, device, dataset, learning_rate, feature_dim_ae, num_ae_epochs,
                                  num_glob_iters, local_epochs, cl_epochs,
                                  data, dims, view, data_size, class_num,
                                  clients_lamda1, server_lamda1)


        for i in range(self.num_users):
            id = i
            train_data = []
            train_data.append(data.get_view(i))
            train_data.append(data.get_view(-1))
            train_data = list(zip(*train_data))
            user = UserAVG(batch_size, device, id, dims[i],
                           feature_dim_ae, train_data,
                           data_size, learning_rate, local_epochs, class_num,
                                  clients_lamda1)

            self.users.append(user)

        print("Number of users :", self.num_users)
        print("Finished creating FedAvg server.")


    def train(self):
        #user 训练 autoencoder
        for user in self.users:
            epoch = 1
            print("-------------user", user.id, ":  开始训练autoencoder-------------")
            while epoch <= self.num_ae_epochs:
                user.train_ae(epoch)
                epoch += 1

        for glob_iter in range(self.num_glob_iters):
            print("-------------Round number: ",glob_iter, " -------------")

            Gl_loss = 0

            for user in self.users:
                Gl_loss = Gl_loss + user.train(glob_iter, self.num_glob_iters)

            self.aggregate_parameters()

            for i in range(self.cl_epochs):
                self.optimizer.zero_grad()
                loss = 0

                for j in range(len(self.G_Cs[0])):

                    Cs_gpu = []
                    Es_gpu = []
                    for k in range(len(self.G_Cs)):
                        Cs_gpu.append(self.G_Cs[k][j].to(self.device))
                        Es_gpu.append(self.G_Es[k][j].to(self.device))
                    Cs_gpu = torch.stack(Cs_gpu)
                    Es_gpu = torch.stack(Es_gpu)
                    self.optimizer.zero_grad()

                    G_CfEs, Cs_t = self.model(
                        Cs_gpu, Es_gpu
                    )

                    loss_list = []

                    for v in range(len(Cs_t)):
                        Es_v = Es_gpu[v] + Cs_gpu[v] - Cs_t[v]
                        for w in range(v + 1, len(Cs_t)):
                            Es_w = Es_gpu[w] + Cs_gpu[w] - Cs_t[w]
                            temp = torch.matmul(Es_v, Es_w.T)
                            temp = torch.diag(temp)
                            temp = torch.abs(temp)
                            temp = sum(temp)
                            loss_list.append(self.server_lamda1 * temp)

                            loss_list.append(1 * self.contrast_loss(
                                Cs_t[v], Cs_t[w])
                                             )

                    loss_avg = sum(loss_list) / len(loss_list)
                    # print(loss_list)
                    # print(loss_avg.item())

                    loss_avg.backward()
                    self.optimizer.step()
                    loss = loss + loss_avg
                    if i == self.local_epochs - 1:
                        temp = sum(Cs_t) / self.num_users
                        for k in range(len(self.G_Cs)):
                            self.G_Cs[k][j] = temp.cpu().detach()
                            # self.G_Cs[k][j] = Cs_t[k].cpu().detach()

                print(loss.item())

            for i in range(len(self.G_Cs)):
                self.users[i].G_C_Glo = self.G_Cs[i]




