import torch
import os
import numpy as np
import h5py
import networkx as nx
from node2vec import Node2Vec
import copy
from sklearn.preprocessing import normalize, MinMaxScaler
from sklearn import cluster
from sklearn.preprocessing import normalize
from scipy.optimize import linear_sum_assignment
from scipy.sparse.linalg import svds
from sklearn.metrics import accuracy_score, v_measure_score, adjusted_rand_score
from torch.utils.data import DataLoader, Dataset
from scipy.sparse.linalg import svds

from FLAlgorithms.trainmodel import trainmodels

class Server:
    def __init__(self, batch_size, device, dataset, learning_rate, feature_dim_ae, num_ae_epochs,
                                  num_glob_iters, local_epochs, cl_epochs,
                                  data, dims, view, data_size, class_num,
                                  clients_lamda1, server_lamda1):

        # Set up the main attributes
        self.batch_size = batch_size
        self.device = device
        self.dataset = dataset
        self.learning_rate = learning_rate
        self.feature_dim_ae = feature_dim_ae
        self.num_ae_epochs = num_ae_epochs
        self.num_glob_iters = num_glob_iters
        self.local_epochs = local_epochs
        self.cl_epochs = cl_epochs
        self.server_lamda1 = server_lamda1

        self.data = data
        self.dims = dims
        self.num_users = view
        self.data_size = data_size
        self.class_num = class_num
        self.temperature_f = 0.7

        self.G_Cs = []
        self.G_Es = []

        self.users = []
        self.cross_entropy = torch.nn.CrossEntropyLoss(reduction="sum")
        self.mse = torch.nn.MSELoss()
        self.model = trainmodels.MyServerModel(data_size).to(device)
        self.optimizer = torch.optim.Adam(self.model.parameters(),
                                             lr=learning_rate * 1,
                                             weight_decay=0)

    def aggregate_parameters(self):
        assert (self.users is not None and len(self.users) > 0)

        self.G_Cs.clear()
        self.G_Es.clear()
        for user in self.users:
            self.G_Cs.append(user.G_C)
            self.G_Es.append(user.G_E)


    def save_model(self):
        model_path = os.path.join("models", self.dataset)
        if not os.path.exists(model_path):
            os.makedirs(model_path)

        torch.save(self.model, os.path.join(model_path, "server" + ".pt"))


    def test(self):
        for c in self.users:
            acc, nmi, ari, pur = c.test()
        return acc, nmi, ari, pur

    def mask_correlated_samples(self, N):
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(N//2):
            mask[i, N//2 + i] = 0
            mask[N//2 + i, i] = 0
        mask = mask.bool()
        return mask


    def contrast_loss(self, h_i, h_j):
        batch_size = len(h_i)
        N = 2 * batch_size
        h = torch.cat((h_i, h_j), dim=0)  #

        sim = torch.matmul(h, h.T) / self.temperature_f
        sim_i_j = torch.diag(sim, batch_size)
        sim_j_i = torch.diag(sim, -batch_size)

        positive_samples = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        mask = self.mask_correlated_samples(N)
        negative_samples = sim[mask].reshape(N, -1)

        labels = torch.zeros(N).to(positive_samples.device).long()

        logits = torch.cat((positive_samples, negative_samples), dim=1)
        loss_temp = self.cross_entropy(logits, labels)
        loss_temp /= N

        return loss_temp

    def thrC(self, C, ro):
        if ro < 1:
            N = C.shape[1]
            Cp = np.zeros((N, N))
            S = np.abs(np.sort(-np.abs(C), axis=0))
            Ind = np.argsort(-np.abs(C), axis=0)
            for i in range(N):
                cL1 = np.sum(S[:, i]).astype(float)
                stop = False
                csum = 0
                t = 0
                while (stop == False):
                    csum = csum + S[t, i]
                    # if csum > ro * cL1:
                    if csum > ro * cL1 or t == N - 1:
                        stop = True
                        Cp[Ind[0:t + 1, i], i] = C[Ind[0:t + 1, i], i]
                    t = t + 1
        else:
            Cp = C

        return Cp

    def inference_graph(self, graph, y):
        soft_vector = []
        d = 10
        beta = 3.5
        labels_vector = []
        alpha = max(0.4 - (self.class_num - 1) / 10 * 0.1, 0.1)

        Cp = graph
        Cp = Cp.cpu().detach().numpy()
        C = self.thrC(Cp, alpha)
        C = 0.5 * (C + C.T)
        r = d * self.class_num + 1
        U, S, _ = svds(C, r, v0=np.ones(C.shape[0]))
        U = U[:, ::-1]
        S = np.sqrt(S[::-1])
        S = np.diag(S)
        U = U.dot(S)
        U = normalize(U, norm='l2', axis=1)
        Z = U.dot(U.T)
        Z = Z * (Z > 0)
        L = np.abs(Z ** beta)
        L = L / L.max()
        L = 0.5 * (L + L.T)
        spectral = cluster.SpectralClustering(n_clusters=self.class_num, eigen_solver='arpack', affinity='precomputed',
                                              assign_labels='discretize')
        spectral.fit(L)
        grp = spectral.fit_predict(L)
        soft_vector.extend(grp)
        # labels_vector.extend(y.detach().cpu().numpy())
        labels_vector.extend(y)

        labels_vector = np.array(labels_vector).reshape(self.data_size)
        total_pred = np.array(soft_vector)

        return total_pred, labels_vector


    def cluster_acc(self, y_true, y_pred):
        y_true = y_true.astype(np.int64)
        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        u = linear_sum_assignment(w.max() - w)
        ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
        return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

    def purity(self, y_true, y_pred):
        y_voted_labels = np.zeros(y_true.shape)
        labels = np.unique(y_true)
        ordered_labels = np.arange(labels.shape[0])
        for k in range(labels.shape[0]):
            y_true[y_true == labels[k]] = ordered_labels[k]
        labels = np.unique(y_true)
        bins = np.concatenate((labels, [np.max(labels) + 1]), axis=0)

        for cluster in np.unique(y_pred):
            hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
            winner = np.argmax(hist)
            y_voted_labels[y_pred == cluster] = winner

        return accuracy_score(y_true, y_voted_labels)

    def evaluate(self, label, pred):
        nmi = v_measure_score(label, pred)
        ari = adjusted_rand_score(label, pred)
        acc = self.cluster_acc(label, pred)
        pur = self.purity(label, pred)
        return nmi, ari, acc, pur

    def valid(self):

        temp = []
        y = []
        generator = torch.Generator().manual_seed(10)

        self.users[0].data_loader = DataLoader(self.users[0].train_data,
                                               batch_size=self.batch_size,
                                      shuffle=self.users[0].shuffle, drop_last=True,
                                      generator=generator)
        for batch_idx, (_, ys) in enumerate(self.users[0].data_loader):
            y.append(ys)
        y = np.concatenate(y)

        for i in range(len(self.G_Cs)):
            t = torch.cat(self.G_Cs[i], dim=0)
            temp.append(t)

        temp = sum(temp) / self.num_users

        # 很慢
        total_pred, labels_vector = self.inference_graph(temp, y)

        print("Clustering results on semantic labels: " + str(labels_vector.shape[0]))
        print('labels_vector, total_pred', labels_vector.shape, total_pred.shape)
        nmi, ari, acc, pur = self.evaluate(labels_vector, total_pred)
        print('G_Cs')
        print('ACC = {:.4f} NMI = {:.4f} ARI = {:.4f} PUR={:.4f}'.format(acc, nmi, ari, pur))

        return acc, nmi, ari, pur

