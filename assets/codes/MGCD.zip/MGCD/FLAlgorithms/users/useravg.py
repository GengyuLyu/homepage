import gc

import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json

from sklearn.cluster import KMeans
from sklearn.preprocessing import *
from sklearn import manifold
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
import sklearn
import numpy as np
from scipy import spatial

from FLAlgorithms.trainmodel import trainmodels
from FLAlgorithms.users.userbase import User

class UserAVG(User):
    def __init__(self, batch_size, device, id, dim,
                    feature_dim_ae, train_data,
                    data_size, learning_rate, local_epochs, class_num,
                                  clients_lamda1):
        super().__init__(batch_size, device, id, dim,
                    feature_dim_ae, train_data,
                    data_size, learning_rate, local_epochs, class_num,
                                  clients_lamda1)


    def train_ae(self, epoch):
        criterion = torch.nn.MSELoss()
        loss = 0
        self.Z_list = []

        generator = torch.Generator().manual_seed(10)

        self.data_loader = DataLoader(self.train_data, batch_size=self.batch_size,
                                      shuffle=self.shuffle, drop_last=True,
                                      generator=generator)

        for batch_idx, (xs, _) in enumerate(self.data_loader):
            xs = xs.to(self.device)
            self.optimizer.zero_grad()
            Z, X_Pre, _, _ = self.model(xs)  # xrs recostruction xv
            self.Z_list.append(torch.tensor(Z.cpu().detach().numpy()))
            loss_list = []

            loss_list.append(criterion(xs, X_Pre))
            loss = sum(loss_list)
            loss.backward()
            self.optimizer.step()
        if epoch % 10 == 0:
            print('Epoch {}'.format(epoch), 'Loss:{:.6f}'.format(loss))

    def train(self, glob_iter, num_glob_iters):
        Lc_loss = 0
        epoch = 1
        print('user{}:'.format(self.id))
        for epoch in range(1, self.local_epochs + 1):

            Lc_loss = 0
            self.Z_tensor = torch.cat(self.Z_list, dim=0).to(self.device)
            self.G_C = []
            self.G_E = []

            for epoch_n in range(len(self.data_loader)):
                generator = torch.Generator().manual_seed(10)

                self.data_loader = DataLoader(self.train_data, batch_size=self.batch_size,
                                              shuffle=self.shuffle, drop_last=True,
                                              generator=generator)

                self.optimizer.zero_grad()
                criterion = torch.nn.MSELoss()
                loss_list = []
                X, y = self.get_next_train_batch()

                Z, X_Pre, G_C, G_E = self.model(X)
                self.Z_list[epoch_n] = torch.tensor(Z.cpu().detach().numpy())

                loss_list.append(1.0 * criterion(X, X_Pre))

                if glob_iter == 0:
                    G_C_Glo = G_C
                else:
                    G_C_Glo = self.G_C_Glo[epoch_n].to(self.device)

                S = G_C_Glo + G_E
                S = torch.diagonal_scatter(S, torch.zeros(len(G_C)), epoch_n * self.batch_size)

                self.G_C.append(G_C_Glo.cpu().detach())
                self.G_E.append(G_E.cpu().detach())

                loss_list.append(self.clients_lamda1 * criterion(
                    torch.matmul(self.Z_tensor.T, S.T), Z.T)) #

                loss = sum(loss_list)
                # print(loss.item())
                # print(loss_list)
                # print(1)
                Lc_loss = Lc_loss + loss

                loss.backward()
                self.optimizer.step()
                self.optimizer.zero_grad()

            print(Lc_loss.item())

            if epoch == self.local_epochs:
                self.Z_tensor = []
                # print(Lc_loss.item() / len(self.data_loader))


        return Lc_loss / epoch




