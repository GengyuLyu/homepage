import random

import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans
from sklearn import cluster
from sklearn.preprocessing import normalize
from scipy.optimize import linear_sum_assignment
from scipy.sparse.linalg import svds
from sklearn.metrics import accuracy_score, v_measure_score, adjusted_rand_score
from torch.utils.data import DataLoader, Dataset
import numpy as np
import copy
from sklearn import manifold

from FLAlgorithms.trainmodel import trainmodels


class User:

    def __init__(self, batch_size, device, id, dim,
                    feature_dim_ae, train_data,
                    data_size, learning_rate, local_epochs, class_num,
                                  clients_lamda1):
        self.batch_size = batch_size
        self.device = device
        self.id = id  # integer
        self.dim = dim
        self.feature_dim_ae = feature_dim_ae
        self.train_data = train_data
        self.data_size = data_size
        self.learning_rate = learning_rate
        self.local_epochs = local_epochs
        self.class_num = class_num
        self.clients_lamda1 = clients_lamda1


        self.G_C = []
        self.G_E = []
        self.G_C_Glo = []
        self.G_E_Glo = []
        self.Z_list = []
        self.Z_tensor = []

        # self.data_loader = DataLoader(train_data, self.data_size)
        self.generator = torch.Generator().manual_seed(10)
        self.shuffle = False
        self.data_loader = DataLoader(train_data, batch_size=batch_size,
                                      shuffle=self.shuffle, drop_last=True,
                                      generator=self.generator)
        self.iter_data_loader = iter(self.data_loader)

        self.model = trainmodels.MyLocalModel(dim, feature_dim_ae, data_size).to(device)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate,
                                             weight_decay=0)


        # self.train_samples = len(train_data[1])
        self.max_sum = 0
        self.acc = 0
        self.nmi = 0
        self.ari = 0
        self.max_sum2 = 0
        self.acc2 = 0
        self.nmi2 = 0
        self.ari2 = 0

    def get_next_train_batch(self):
        try:
            #
            (X, y) = next(self.iter_data_loader)
        except StopIteration:
            #
            self.iter_data_loader = iter(self.data_loader)
            (X, y) = next(self.iter_data_loader)
        return (X.to(self.device), y.to(self.device))


    def cluster_acc(self, y_true, y_pred):
        y_true = y_true.astype(np.int64)
        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        u = linear_sum_assignment(w.max() - w)
        ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
        return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

    def purity(self, y_true, y_pred):
        y_voted_labels = np.zeros(y_true.shape)
        labels = np.unique(y_true)
        ordered_labels = np.arange(labels.shape[0])
        for k in range(labels.shape[0]):
            y_true[y_true == labels[k]] = ordered_labels[k]
        labels = np.unique(y_true)
        bins = np.concatenate((labels, [np.max(labels) + 1]), axis=0)

        for cluster in np.unique(y_pred):
            hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
            winner = np.argmax(hist)
            y_voted_labels[y_pred == cluster] = winner

        return accuracy_score(y_true, y_voted_labels)

    def evaluate(self, label, pred):
        nmi = v_measure_score(label, pred)
        ari = adjusted_rand_score(label, pred)
        acc = self.cluster_acc(label, pred)
        pur = self.purity(label, pred)
        return nmi, ari, acc, pur


    def test(self):

        # 谱聚类
        y = self.train_data[1]
        S = self.G_C + self.G_E
        total_pred, labels_vector = self.inference_graph(S, y)
        print("Clustering results on semantic labels: " + str(labels_vector.shape[0]))
        print('labels_vector, total_pred', labels_vector.shape, total_pred.shape)
        nmi, ari, acc, pur = self.evaluate(labels_vector, total_pred)
        print('ACC = {:.4f} NMI = {:.4f} ARI = {:.4f} PUR={:.4f}'.format(acc, nmi, ari, pur))
        if nmi + ari + acc > self.max_sum:
            self.max_sum = nmi + ari + acc
            self.acc = acc
            self.nmi = nmi
            self.ari = ari
        print('MAX ACC = {:.4f} NMI = {:.4f} ARI = {:.4f}'.format(
            self.acc, self.nmi, self.ari))

        return acc, nmi, ari, pur

    def thrC(self, C, ro):
        if ro < 1:
            N = C.shape[1]
            Cp = np.zeros((N, N))
            S = np.abs(np.sort(-np.abs(C), axis=0))
            Ind = np.argsort(-np.abs(C), axis=0)
            for i in range(N):
                cL1 = np.sum(S[:, i]).astype(float)
                stop = False
                csum = 0
                t = 0
                while (stop == False):
                    csum = csum + S[t, i]
                    if csum > ro * cL1:
                        stop = True
                        Cp[Ind[0:t + 1, i], i] = C[Ind[0:t + 1, i], i]
                    t = t + 1
        else:
            Cp = C

        return Cp



    def inference_graph(self, graph, y):
        soft_vector = []
        d = 10
        beta = 3.5
        labels_vector = []
        alpha = max(0.4 - (self.class_num - 1) / 10 * 0.1, 0.1)

        Cp = graph
        Cp = Cp.cpu().detach().numpy()
        C = self.thrC(Cp, alpha)
        C = 0.5 * (C + C.T)
        r = d * self.class_num + 1
        U, S, _ = svds(C, r, v0=np.ones(C.shape[0]))
        U = U[:, ::-1]
        S = np.sqrt(S[::-1])
        S = np.diag(S)
        U = U.dot(S)
        U = normalize(U, norm='l2', axis=1)
        Z = U.dot(U.T)
        Z = Z * (Z > 0)
        L = np.abs(Z ** beta)
        L = L / L.max()
        L = 0.5 * (L + L.T)
        spectral = cluster.SpectralClustering(n_clusters=self.class_num, eigen_solver='arpack', affinity='precomputed',
                                              assign_labels='discretize')
        spectral.fit(L)
        grp = spectral.fit_predict(L)
        soft_vector.extend(grp)
        labels_vector.extend(y.detach().cpu().numpy())

        labels_vector = np.array(labels_vector).reshape(self.data_size)
        total_pred = np.array(soft_vector)

        return total_pred, labels_vector

