import gc

import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import MinMaxScaler
from torch.nn.functional import normalize
import torch
from torch.nn import Linear
# from torch_geometric.nn import GCNConv
from torch_geometric.nn import SAGEConv
# import networkx as nx
import matplotlib.pyplot as plt
from torch_geometric.datasets import KarateClub
from torch_geometric.utils import to_networkx
from sklearn.cluster import KMeans, SpectralClustering
import numpy as np
from sklearn.neighbors import NearestNeighbors


class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            # nn.BatchNorm1d(2000),
            nn.Linear(2000, feature_dim),
            # nn.BatchNorm1d(feature_dim),
        )

    def forward(self, x):
        return self.encoder(x)


class Decoder(nn.Module):
    def __init__(self, feature_dim, output_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, output_dim)
        )

    def forward(self, x):
        return self.decoder(x)

class MyLocalModel(nn.Module):
    def __init__(self, feature_in, feature_dim_ae, data_size):
        super(MyLocalModel, self).__init__()
        self.encoder1 = Encoder(feature_in, feature_dim_ae)
        self.encoder2 = Encoder(feature_in, feature_dim_ae)
        self.decoder = Decoder(feature_dim_ae, feature_in)
        self.g_c = nn.Sequential(
            nn.Linear(feature_dim_ae, data_size)
        )
        self.g_e = nn.Sequential(
            nn.Linear(feature_dim_ae, data_size)
        )


    def forward(self, data):
        X = data
        Z_c = self.encoder1(X)
        Z_e = self.encoder2(X)
        Z = Z_c + Z_e
        X_Pre = self.decoder(Z)
        G_C = self.g_c(Z_c)
        G_E = self.g_e(Z_e)

        return Z, X_Pre, G_C, G_E

class MyServerModel(nn.Module):
    def __init__(self, data_size):
        super(MyServerModel, self).__init__()
        self.g_c = nn.Sequential(
            nn.Linear(data_size, 512),
            # nn.ReLU(),
            nn.Linear(512, data_size)
        )
        self.g_e = nn.Sequential(
            nn.Linear(data_size, 512),
            # nn.ReLU(),
            nn.Linear(512, data_size)
        )

    def forward(self, graphs_c, graphs_e):
        G_Cs = []
        G_CfEs = []


        for i in range(len(graphs_e)):
            temp = self.g_e(graphs_e[i])
            G_CfEs.append(temp)

        for i in range(len(graphs_c)):
            Gc_mid = graphs_c[i] + G_CfEs[i]
            temp = self.g_c(Gc_mid)
            G_Cs.append(temp)

        return G_CfEs, G_Cs




