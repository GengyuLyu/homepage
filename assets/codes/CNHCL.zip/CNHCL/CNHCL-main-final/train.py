import argparse
import random
from CNHCL.training import model_train
import yaml
from tqdm import tqdm
import numpy as np
import torch
from CNHCL.loader import DatasetLoader, load_train
from CNHCL.generator import MLPgenerator
from CNHCL.models import HyperEncoder, CNHCL
from CNHCL.utils import gen_size_dist
from CNHCL.evaluation import linear_evaluation
from CNHCL.aggregator import MeanAggregator


def fix_seed(seed):
    """
    固定随机种子，保证实验可重复性。
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


def node_classification_eval(num_splits=10):
    model.eval()
    n, _ = model(data.features, data.hyperedge_index)

    if data.name == 'pubmed':
        lr = 0.005
        max_epoch = 300
    elif data.name == 'cora' or data.name == 'citeseer':
        lr = 0.005
        max_epoch = 100
    elif data.name == 'Mushroom':
        lr = 0.01
        max_epoch = 200
    else:
        lr = 0.01
        max_epoch = 100

    accs = []
    accs = []
    for i in range(num_splits):
        masks = data.generate_random_split(seed=i)
        accs.append(linear_evaluation(n, data.labels, masks, lr=lr, max_epoch=max_epoch))
    return accs 


def compute_edge_ranges(hyperedge_index):
    """
    计算每个超边的节点索引范围。
    """
    unique_edges, counts = torch.unique(hyperedge_index[1], return_counts=True)
    start_indices = torch.cumsum(torch.cat([torch.tensor([0], device=hyperedge_index.device), counts[:-1]]), dim=0)
    end_indices = start_indices + counts
    return [(start.item(), end.item()) for start, end in zip(start_indices, end_indices)]


if __name__ == '__main__':
    parser = argparse.ArgumentParser('CNHCL')
    #运行时需要修改使用params文件里的路径
    parser.add_argument('--dataset', type=str, default='cora', 
        choices=['cora', 'citeseer', 'pubmed', 'cora_coauthor', 'dblp_coauthor', 
                'ModelNet40'])
    parser.add_argument('--num_seeds', type=int, default=1)
    parser.add_argument('--device', type=int, default=0)
    args = parser.parse_args()

    data = DatasetLoader().load(args.dataset).to(args.device)
    accs = []

    fix_seed(42)
    params = yaml.safe_load(open('CNHCL-main-final/config.yaml'))[args.dataset]

    # 初始化模型、判别器和生成器
    encoder = HyperEncoder(data.features.shape[1], params['hid_dim'], params['hid_dim'], params['num_layers'])
    model = CNHCL(encoder, params['proj_dim']).to(args.device)

    cls_layers = [params['hid_dim'], 1024, 128,8, 1]
    if args.dataset == "citeseer":
        cls_layers = [params['hid_dim'], 64, 8, 1]
    elif args.dataset == "cora_coauthor":
        cls_layers = [params['hid_dim'], 256, 8, 1]
    elif args.dataset == "cora":
        cls_layers = [params['hid_dim'], 256, 8, 1]
    Aggregator = MeanAggregator(params['hid_dim'], cls_layers).to(args.device)

    size_dist = gen_size_dist(data.hypergraph)
    dim = [128, 256, 256, data.num_nodes]
    if args.dataset == "citeseer":
        dim = [64, 128, 128, data.num_nodes]
    elif args.dataset == "cora_coauthor":
        dim = [64, 256, 512, data.num_nodes]
    elif args.dataset == "cora":
        dim = [16, 256, 256, data.num_nodes]
    elif args.dataset == "pubmed":
        dim = [128, 512, 512, data.num_nodes]
    elif "dblp" in args.dataset:
        dim = [256, 1024, 2048, data.num_nodes]
    print(f"{args.dataset} generator dimension: "+str(dim))
    Generator =  MLPgenerator(dim, data.num_nodes, args.device, size_dist).to(args.device)
    # 定义优化器
    optim_D = torch.optim.AdamW(Aggregator.parameters(), lr=params['D_lr'])
    optim_M = torch.optim.AdamW(model.parameters(), lr=params['lr'], weight_decay=params['weight_decay'])
    optim_G = torch.optim.AdamW(Generator.parameters(), lr=params['G_lr'])

    # 初始化掩码和其他辅助变量
    N = data.hyperedge_index.size(1)  # 超边节点对总长
    device = data.hyperedge_index.device  # 获取 hyperedge_index 所在设备
    key_mask = torch.zeros(N, dtype=torch.int, device=device)  # 标记关键节点
    candidate_mask = torch.zeros(N, dtype=torch.int, device=device)  # 标记候选关键节点


    # 计算超边索引范围
    edge_ranges = compute_edge_ranges(data.hyperedge_index)
    aggr_mask = torch.zeros(N, dtype=torch.int, device=device)

    edge_mapping = {}
    for i in range(len(data.hyperedge_index[0])):
        edge_id = int(data.hyperedge_index[1][i])
        if edge_id not in edge_mapping:
            edge_mapping[edge_id] = []
        edge_mapping[edge_id].append(i)

    hid_dim, num_classes = params['hid_dim'], int(data.labels.max()) + 1

    # 训练循环
    best_val_acc = 0.0
    best_val_std = 0.0
    final_test_acc = 0.0
    final_test_std = 0.0
    best_epoch = 0
    prev_low_score_edges = []
    prev_trial_nodes = {}
    for epoch in tqdm(range(params['epochs']), leave=False):
        train_batchloader = load_train(data.num_edges, params['bs'], 0)

        while True:
            pos_hedges, pos_labels, is_last = train_batchloader.next()

            # 调用训练函数
            prev_low_score_edges, prev_trial_nodes = model_train(
        data, args, model, Aggregator, Generator, optim_D, optim_G, optim_M,
        pos_hedges, epoch, aggr_mask, key_mask, candidate_mask, edge_ranges, 
        is_last, prev_low_score_edges, prev_trial_nodes
    )
            if is_last:
                break
        if epoch >= params['test_epoch']:
                acc = node_classification_eval()
                accs.append(acc)
                acc_mean, acc_std = np.mean(acc, axis=0), np.std(acc, axis=0)
                print(f'seed: {0}, train_acc: {acc_mean[0]:.2f}+-{acc_std[0]:.2f}, '
                    f'valid_acc: {acc_mean[1]:.2f}+-{acc_std[1]:.2f}, test_acc: {acc_mean[2]:.2f}+-{acc_std[2]:.2f}')

                if acc_mean[1] > best_val_acc:
                    best_val_acc = acc_mean[1]
                    best_val_std = acc_std[1]
                    final_test_acc=acc_mean[2]
                    final_test_std=acc_std[2]




