from typing import Optional, Callable

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch_scatter import scatter_add
import numpy as np
import yaml
import random
from CNHCL.layers import ProposedConv
from CNHCL.utils import drop_features, drop_incidence, valid_node_edge_mask, hyperedge_index_masking,gen_size_dist

class HyperEncoder(nn.Module):
    def __init__(self, in_dim, edge_dim, node_dim, num_layers=2, act: Callable = nn.PReLU()):
        super(HyperEncoder, self).__init__()
        self.in_dim = in_dim
        self.edge_dim = edge_dim
        self.node_dim = node_dim
        self.num_layers = num_layers
        self.act = act

        self.convs = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(ProposedConv(self.in_dim, self.edge_dim, self.node_dim, cached=False, act=act))
        else:
            self.convs.append(ProposedConv(self.in_dim, self.edge_dim, self.node_dim, cached=False, act=act))
            for _ in range(self.num_layers - 2):
                self.convs.append(ProposedConv(self.node_dim, self.edge_dim, self.node_dim, cached=False, act=act))
            self.convs.append(ProposedConv(self.node_dim, self.edge_dim, self.node_dim, cached=False, act=act))
        self.reset_parameters()

    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()

    def forward(self, x: Tensor, hyperedge_index: Tensor, num_nodes: int, num_edges: int):
        for i in range(self.num_layers):
            x, e = self.convs[i](x, hyperedge_index, num_nodes, num_edges)
            x = self.act(x)
        return x, e # act, act



class CNHCL(nn.Module):
    def __init__(self, encoder: HyperEncoder, proj_dim: int):
        super(CNHCL, self).__init__()
        self.encoder = encoder

        self.node_dim = self.encoder.node_dim
        self.edge_dim = self.encoder.edge_dim

        # 节点投影头 (共享)
        self.fc1_n = nn.Linear(self.node_dim, proj_dim)
        self.fc2_n = nn.Linear(proj_dim, self.node_dim)

        # 超边投影头 (共享)
        self.fc1_e = nn.Linear(self.edge_dim, proj_dim)
        self.fc2_e = nn.Linear(proj_dim, self.edge_dim)

        # 移除 nn.Bilinear 层，因为节点-超边级别的相似度也将使用余弦相似度
        # self.disc = nn.Bilinear(self.node_dim, self.edge_dim, 1) # 移除此行

        self.reset_parameters()
    
    def reset_parameters(self):
        self.encoder.reset_parameters()
        self.fc1_n.reset_parameters()
        self.fc2_n.reset_parameters()
        self.fc1_e.reset_parameters()
        self.fc2_e.reset_parameters()
        # self.disc.reset_parameters() # 移除此行
        
    def forward(self, x: Tensor, hyperedge_index: Tensor,
                  num_nodes: Optional[int] = None, num_edges: Optional[int] = None):
        if num_nodes is None:
            num_nodes = int(hyperedge_index[0].max()) + 1
        if num_edges is None:
            num_edges = int(hyperedge_index[1].max()) + 1

        node_idx = torch.arange(0, num_nodes, device=x.device)
        # 为每个节点创建自环超边。
        # 注意这里的 edge_idx 范围是从 num_edges 开始，保证与实际超边不重叠。
        edge_idx = torch.arange(num_edges, num_edges + num_nodes, device=x.device)
        self_loop = torch.stack([node_idx, edge_idx])
        self_loop_hyperedge_index = torch.cat([hyperedge_index, self_loop], 1)
        
        # 编码器输出的节点和超边嵌入
        n, e = self.encoder(x, self_loop_hyperedge_index, num_nodes, num_edges + num_nodes)
        
        # 返回原始的节点嵌入和真实的超边嵌入 (去除自环的超边部分)
        return n, e[:num_edges]

    def f(self, x, tau):
        # 这是一个用于 InfoNCE 损失的辅助函数，将相似度转换为指数形式
        return torch.exp(x / tau)
    
    def node_projection(self, z: Tensor):
        # 节点投影头：z -> fc1_n -> ELU -> fc2_n
        return self.fc2_n(F.elu(self.fc1_n(z)))
    
    def edge_projection(self, z: Tensor):
        # 超边投影头：z -> fc1_e -> ELU -> fc2_e
        return self.fc2_e(F.elu(self.fc1_e(z)))
    
    def cosine_similarity(self, z1: Tensor, z2: Tensor):
        # 计算两组向量之间的余弦相似度矩阵
        # F.normalize 默认 dim=1, p=2
        z1 = F.normalize(z1) 
        z2 = F.normalize(z2)
        return torch.mm(z1, z2.t())

    # disc_similarity 更改为使用余弦相似度，以符合论文中 L_m 的定义
    def disc_similarity(self, z1: Tensor, z2: Tensor):
        # 计算两组相同大小向量之间的逐元素余弦相似度
        # F.cosine_similarity 默认 dim=1，即在特征维度上计算
        return F.cosine_similarity(z1, z2, dim=1)


    def __semi_loss(self, h1: Tensor, h2: Tensor, tau: float, num_negs: Optional[int]):
        # InfoNCE 半损失计算
        if num_negs is None: # 如果没有指定负样本数量，则使用批次内的所有其他样本作为负样本
            # between_sim = self.f(self.cosine_similarity(h1, h2), tau)
            # return -torch.log(between_sim.diag() / between_sim.sum(1))
                # if num_negs is None:
        # 计算所有样本对相似度（包括正样本和负样本）
            between_sim = self.f(self.cosine_similarity(h1, h2), tau)  # (N, N)
            # # 去掉分母中的正样本：分母 = 所有非对角线元素的和（即仅负样本）
            denominator = between_sim.sum(1) - between_sim.diag()  # 减去对角线（正样本）
            # # 分子仍为正样本的相似度（对角线）
            loss = -torch.log(between_sim.diag() / (denominator + 1e-8))
            return loss
        else: # 如果指定了负样本数量，则进行显式负采样
            pos_sim = self.f(F.cosine_similarity(h1, h2, dim=1), tau) # 正样本对的相似度 (N,)
            
            neg_sim_components = []
            for _ in range(num_negs):
                # 随机打乱 h2 作为负样本
                h2_perm = h2[torch.randperm(h2.size(0), device=h2.device)] 
                # 计算 h1 与打乱后的 h2 之间的余弦相似度
                neg_sim_components.append(self.f(F.cosine_similarity(h1, h2_perm, dim=1), tau))
            
            neg_sim = torch.stack(neg_sim_components, dim=1) # (N, num_negs)

            # 确保分母不会为0，避免 log(0)
            denominator = pos_sim + neg_sim.sum(1)
            # 使用 clip 避免除以非常接近0的值导致NaN
            loss = -torch.log(pos_sim / (denominator + 1e-8)) 
            return loss
        
    def __semi_loss_batch(self, h1: Tensor, h2: Tensor, tau: float, batch_size: int):
        # 批处理 InfoNCE 半损失计算
        device = h1.device
        num_samples = h1.size(0)
        num_batches = (num_samples - 1) // batch_size + 1
        indices = torch.arange(0, num_samples, device=device)
        losses = []

        for i in range(num_batches):
            mask = indices[i * batch_size: (i + 1) * batch_size]
            # 计算当前批次 h1[mask] 与所有 h2 之间的相似度矩阵
            between_sim = self.f(self.cosine_similarity(h1[mask], h2), tau)

            # 获取当前批次正样本的相似度
            # h1[mask][k] 对应 h2[mask][k] 的相似度
            pos_batch_sim = self.f(F.cosine_similarity(h1[mask], h2[mask], dim=1), tau) 
            
            # InfoNCE 的分母是 h1[mask] 与所有 h2 的相似度之和
            # between_sim 是 (current_batch_size, num_samples)
            # 确保分母不会为0
            denominator = between_sim.sum(1)
            loss = -torch.log(pos_batch_sim / (denominator + 1e-8))
            losses.append(loss)
        return torch.cat(losses)

    def __loss(self, z1: Tensor, z2: Tensor, tau: float, batch_size: Optional[int], 
                 num_negs: Optional[int], mean: bool):
        # 通用对比损失计算逻辑
        if batch_size is None or num_negs is not None:
            l1 = self.__semi_loss(z1, z2, tau, num_negs)
            l2 = self.__semi_loss(z2, z1, tau, num_negs)
        else:
            l1 = self.__semi_loss_batch(z1, z2, tau, batch_size)
            l2 = self.__semi_loss_batch(z2, z1, tau, batch_size)

        loss = (l1 + l2) * 0.5
        # 过滤掉 NaN 值
        loss = loss[~torch.isnan(loss)]
        if loss.numel() == 0: # 如果过滤后没有有效损失，返回0
            return torch.tensor(0.0, device=z1.device)
        loss = loss.mean() if mean else loss.sum()
        return loss

    def node_level_loss(self, n1: Tensor, n2: Tensor, node_tau: float, 
                          batch_size: Optional[int] = None, num_negs: Optional[int] = None, 
                          mean: bool = True):
        # 节点级别对比损失
        loss = self.__loss(n1, n2, node_tau, batch_size, num_negs, mean)
        return loss

    def group_level_loss(self, e1: Tensor, e2: Tensor, edge_tau: float, 
                           batch_size: Optional[int] = None, num_negs: Optional[int] = None, 
                           mean: bool = True):
        # 超边级别对比损失
        loss = self.__loss(e1, e2, edge_tau, batch_size, num_negs, mean)
        return loss

    def membership_level_loss(self, n: Tensor, e: Tensor, hyperedge_index: Tensor, tau: float, 
                                 batch_size: Optional[int] = None, mean: bool = True):
        # 获取与超边关联的节点和超边嵌入
        node_indices = hyperedge_index[0]
        edge_indices = hyperedge_index[1]

        nodes_in_hyperedges = n[node_indices]
        edges_connected_to_nodes = e[edge_indices]

        # 随机打乱超边和节点嵌入，用于构造负样本
        e_perm = e[torch.randperm(e.size(0), device=e.device)]
        n_perm = n[torch.randperm(n.size(0), device=n.device)]

        if batch_size is None:
            # 正样本相似度：连接的节点-超边对
            pos = self.f(self.disc_similarity(nodes_in_hyperedges, edges_connected_to_nodes), tau)
            
            # 负样本相似度 1：节点不变，超边随机替换
            neg_n = self.f(self.disc_similarity(nodes_in_hyperedges, e_perm[edge_indices]), tau)
            # 负样本相似度 2：超边不变，节点随机替换
            neg_e = self.f(self.disc_similarity(n_perm[node_indices], edges_connected_to_nodes), tau)

            # 计算损失：InfoNCE 形式
            # 确保分母不会为0
            loss_n = -torch.log(pos / (pos + neg_n + 1e-8))
            loss_e = -torch.log(pos / (pos + neg_e + 1e-8))
        else:
            num_samples = hyperedge_index.shape[1]
            num_batches = (num_samples - 1) // batch_size + 1
            indices = torch.arange(0, num_samples, device=n.device)
            
            aggr_pos = []
            aggr_neg_n = []
            aggr_neg_e = []
            for i in range(num_batches):
                mask = indices[i * batch_size: (i + 1) * batch_size]
                
                # 获取当前批次的节点和超边嵌入索引
                batch_node_indices = hyperedge_index[0, mask]
                batch_edge_indices = hyperedge_index[1, mask]

                # 获取对应的嵌入
                batch_nodes = n[batch_node_indices]
                batch_edges = e[batch_edge_indices]

                # 正样本相似度
                pos = self.f(self.disc_similarity(batch_nodes, batch_edges), tau)
                
                # 负样本相似度 1：节点不变，超边随机替换
                neg_n = self.f(self.disc_similarity(batch_nodes, e_perm[batch_edge_indices]), tau)
                # 负样本相似度 2：超边不变，节点随机替换
                neg_e = self.f(self.disc_similarity(n_perm[batch_node_indices], batch_edges), tau)

                aggr_pos.append(pos)
                aggr_neg_n.append(neg_n)
                aggr_neg_e.append(neg_e)
            
            # 拼接所有批次的损失
            aggr_pos = torch.cat(aggr_pos)
            aggr_neg_n = torch.cat(aggr_neg_n)
            aggr_neg_e = torch.cat(aggr_neg_e)

            # 确保分母不会为0
            loss_n = -torch.log(aggr_pos / (aggr_pos + aggr_neg_n + 1e-8))
            loss_e = -torch.log(aggr_pos / (aggr_pos + aggr_neg_e + 1e-8))

        # 过滤掉 NaN 值（可能由 exp(x/tau) 接近 0 导致 log(0) 或除以 0 引起）
        loss_n = loss_n[~torch.isnan(loss_n)]
        loss_e = loss_e[~torch.isnan(loss_e)]
        
        # 如果过滤后没有任何有效损失，可以返回 0
        if loss_n.numel() == 0 and loss_e.numel() == 0:
            return torch.tensor(0.0, device=n.device)

        loss = loss_n + loss_e
        loss = loss.mean() if mean else loss.sum()
        return loss