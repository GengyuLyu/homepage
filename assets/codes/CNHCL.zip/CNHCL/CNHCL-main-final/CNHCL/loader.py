import numpy as np
import torch

from .dataset import (
    CoraCocitationDataset,
    CiteseerCocitationDataset,
    PubmedCocitationDataset,   
    CoraCoauthorshipDataset,
    DBLPCoauthorshipDataset,
    ZooDataset,
    NewsDataset,
    MushroomDataset,
    NTU2012Dataset,
    ModelNet40Dataset,
)
def load_train(num_edges, bs, device):
    train_batchloader = HyperedgeIndexBatchGenerator(num_edges, bs, device)
    return train_batchloader
class HyperedgeIndexBatchGenerator(object):
    def __init__(self, num_hyperedges, batch_size, device, test_generator=False):

        self.num_hyperedges = num_hyperedges
        self.batch_size = batch_size
        self.device = device
        self._cursor = 0
        self.test_generator = test_generator
        self.hyperedge_indices = list(range(0, num_hyperedges))  
        self.labels = [1] * num_hyperedges  
        self.shuffle()  #

    def eval(self):
        self.test_generator = True

    def train(self):
        self.test_generator = False

    def shuffle(self):
        """Shuffle hyperedge indices."""
        np.random.shuffle(self.hyperedge_indices)

    def __iter__(self):
        self._cursor = 0
        return self

    def next(self):
        return self.__next__()

    def __next__(self):
        if self.test_generator:
            return self.next_test_batch()
        else:
            return self.next_train_batch()

    def next_train_batch(self):
        """Generate the next training batch."""
        ncursor = self._cursor + self.batch_size
        if ncursor >= self.num_hyperedges:  
           
            indices = self.hyperedge_indices[self._cursor:] + self.hyperedge_indices[:ncursor - self.num_hyperedges]
            labels = self.labels[self._cursor:] + self.labels[:ncursor - self.num_hyperedges]
            self._cursor = ncursor - self.num_hyperedges
            self.shuffle()  
            return (
                torch.tensor(indices, dtype=torch.long, device=self.device),
                torch.tensor(labels, dtype=torch.float, device=self.device),
                True  # 
            )

        indices = self.hyperedge_indices[self._cursor:ncursor]
        labels = self.labels[self._cursor:ncursor]
        self._cursor = ncursor % self.num_hyperedges
        return (
            torch.tensor(indices, dtype=torch.long, device=self.device),
            torch.tensor(labels, dtype=torch.float, device=self.device),
            False  # 
        )

    def next_test_batch(self):
        """Generate the next test batch."""
        ncursor = self._cursor + self.batch_size
        if ncursor >= self.num_hyperedges:  # 
            indices = self.hyperedge_indices[self._cursor:]
            labels = self.labels[self._cursor:]
            self._cursor = 0
            return (
                torch.tensor(indices, dtype=torch.long, device=self.device),
                torch.tensor(labels, dtype=torch.float, device=self.device),
                True  # 
            )

        indices = self.hyperedge_indices[self._cursor:ncursor]
        labels = self.labels[self._cursor:ncursor]
        self._cursor = ncursor
        return (
            torch.tensor(indices, dtype=torch.long, device=self.device),
            torch.tensor(labels, dtype=torch.float, device=self.device),
            False  # 
        )

class DatasetLoader(object):
    def __init__(self):
        pass

    def load(self, dataset_name: str = 'cora'):
        if dataset_name == 'cora':
            return CoraCocitationDataset() 
        elif dataset_name == 'citeseer':
            return CiteseerCocitationDataset()
        elif dataset_name == 'pubmed':
            return PubmedCocitationDataset()
        elif dataset_name == 'cora_coauthor':
            return CoraCoauthorshipDataset()
        elif dataset_name == 'dblp_coauthor':
            return DBLPCoauthorshipDataset()
        elif dataset_name == 'zoo':
            return ZooDataset()
        elif dataset_name == '20newsW100':
            return NewsDataset()
        elif dataset_name == 'Mushroom':
            return MushroomDataset()
        elif dataset_name == 'NTU2012':
            return NTU2012Dataset()
        elif dataset_name == 'ModelNet40':
            return ModelNet40Dataset()
        else:
            assert False
