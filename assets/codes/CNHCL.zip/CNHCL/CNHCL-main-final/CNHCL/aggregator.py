import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F

seed=42
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
torch.backends.cudnn.deterministic=True
torch.backends.cudnn.benchmark=False

class MeanAggregator(nn.Module):
    def __init__(self, dim_vertex, layers):
        super(MeanAggregator, self).__init__()
        # 构建分类器网络
        Layers = []
        for i in range(len(layers) - 1):
            Layers.append(nn.Linear(layers[i], layers[i + 1]))
            if i != len(layers) - 2:  # 不在最后一层添加 ReLU
                Layers.append(nn.ReLU(True))
        Layers.append(nn.Sigmoid())  # 确保输出范围在 [0, 1]
        self.cls = nn.Sequential(*Layers)

    def classify(self, embeddings):
        """
        分类操作：输入为多个超边嵌入，输出每个超边的独立评分。
        """
        # L2 范数归一化，确保输出的维度是 [batch_size, embedding_dim]
        normalized_embedding = F.normalize(embeddings, p=2, dim=-1)  # [batch_size, embedding_dim]

        # 输入分类器，输出每个超边的独立评分
        scores = self.cls(normalized_embedding).squeeze(-1)  # 确保输出为 [batch_size]
        return scores

    def forward(self, embeddings):
        """
        执行分类操作。
        embeddings: [batch_size, embedding_dim]
        返回: 每个超边的独立评分 [batch_size]
        """
        pred = self.classify(embeddings)  # [batch_size]
        return pred


    

    
# class MaxminAggregator(nn.Module):
#     def __init__(self, dim_vertex, layers):
#         super(MaxminAggregator, self).__init__()
#         Layers = []
#         for i in range(len(layers)-1):
#             Layers.append(nn.Linear(layers[i], layers[i+1]))
#             if i != len(layers)-2:
#                 Layers.append(nn.ReLU(True))
#         self.cls = nn.Sequential(*Layers)
    
#     def aggregate(self, embeddings):
#         max_val, _ = torch.max(embeddings, dim=0)
#         min_val, _ = torch.min(embeddings, dim=0)
#         return max_val - min_val
    
#     def classify(self, embedding):
#         return F.sigmoid(self.cls(embedding))
    
#     def forward(self, embeddings):
#         if embeddings.dim()>1:
#             embedding = self.aggregate(embeddings)
#             pred = self.classify(embedding)
#             return pred
#         else:
#             pred = self.classify(embeddings)
#             return pred
    

    