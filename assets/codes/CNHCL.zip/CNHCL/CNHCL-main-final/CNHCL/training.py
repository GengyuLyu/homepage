import torch
from .utils import drop_features, drop_incidence, valid_node_edge_mask
import yaml
import torch.nn as nn

def model_part(data, model, args, key_mask, candidate_mask):
    """
    模型训练部分，使用 key_mask 和 candidate_mask 进行增强。
    """
    params = yaml.safe_load(open('CNHCL-main-final/config.yaml'))[args.dataset]
    num_nodes = data.num_nodes
    num_edges = data.num_edges
    hyperedge_index = data.hyperedge_index
    v_feat = data.features

    # 调用 drop_incidence 对超边进行增强
    hyperedge_index1 = drop_incidence(hyperedge_index, params['drop_incidence_rate'], key_mask, candidate_mask)
    hyperedge_index2 = drop_incidence(hyperedge_index, params['drop_incidence_rate'], key_mask, candidate_mask)
    # 随机丢弃节点特征
    x1 = drop_features(v_feat, params['drop_feature_rate'])
    x2 = drop_features(v_feat, params['drop_feature_rate'])

    # 获取有效节点和超边的掩码
    node_mask1, edge_mask1 = valid_node_edge_mask(hyperedge_index1, num_nodes, num_edges)
    node_mask2, edge_mask2 = valid_node_edge_mask(hyperedge_index2, num_nodes, num_edges)
    edge_mask = edge_mask1 & edge_mask2
    node_mask = node_mask1 & node_mask2

    # 模型前向传播
    n1, e1 = model(x1, hyperedge_index1, num_nodes, num_edges)
    n2, e2 = model(x2, hyperedge_index2, num_nodes, num_edges)

    # 节点和超边投影
    n1, n2 = model.node_projection(n1), model.node_projection(n2)
    e1, e2 = model.edge_projection(e1), model.edge_projection(e2)

    # 损失计算
    num_negs = None
    loss_g = model.group_level_loss(e1[edge_mask], e2[edge_mask], params['tau_g'], params['batch_size_1'], num_negs)
    loss_n = model.node_level_loss(n1, n2, params['tau_n'], params['batch_size_1'], num_negs)
    loss_m1 = model.membership_level_loss(n1, e2, hyperedge_index, params['tau_m'], batch_size=params['batch_size_2'])
    loss_m2 = model.membership_level_loss(n2, e1, hyperedge_index, params['tau_m'], batch_size=params['batch_size_2'])
    loss_m = (loss_m1 + loss_m2) * 0.5

    loss = loss_n + params['w_g'] * loss_g + params['w_m'] * loss_m

    return loss


def generator_part(Generator, batch_size, args, Aggregator, v):
    neg_samples_onehot, neg_indices = Generator(batch_size)
    neg_preds = []
    for onehots in neg_samples_onehot:
        counts = torch.sum(onehots, dim=0, keepdim=True)
        inv_freq = torch.where(counts > 0, 1 / counts, torch.zeros_like(counts))
        weighted_onehots = onehots * inv_freq
        embeddings = torch.matmul(weighted_onehots, v)
        pooled_embedding = embeddings.mean(dim=0)
        pred = Aggregator(pooled_embedding.unsqueeze(0)).squeeze(-1)
        neg_preds.append(pred)
    neg_preds = torch.stack(neg_preds, dim=0)
    return neg_preds

def compute_edge_ranges(hyperedge_index):
    unique_edges, counts = torch.unique(hyperedge_index[1], return_counts=True)
    start_indices = torch.cumsum(torch.cat([torch.tensor([0], device=hyperedge_index.device), counts[:-1]]), dim=0)
    end_indices = start_indices + counts
    return [(start.item(), end.item()) for start, end in zip(start_indices, end_indices)]

def update_aggr_mask(hyperedge_index, edge_ranges, low_score_edges, key_mask, aggr_mask):
    """
    更新 aggr_mask（本轮新节点中转站），并返回本轮被试探性选中的节点在 hyperedge_index 中的索引。
    """
    current_trial_nodes = {}
    for edge_id in low_score_edges:
        start, end = edge_ranges[edge_id]
        available_indices = torch.arange(start, end, device=hyperedge_index.device)
        if len(available_indices) == 0:
            continue
            
        non_key_indices = torch.where(key_mask[available_indices] == 0)[0]
        if len(non_key_indices) > 0:
            trial_index = torch.multinomial(torch.ones(len(non_key_indices)), 1, replacement=False)
            selected_node_index_in_hyperedge_index = available_indices[non_key_indices[trial_index]]
            aggr_mask[selected_node_index_in_hyperedge_index] = 1
            current_trial_nodes[edge_id] = selected_node_index_in_hyperedge_index.item()
    return aggr_mask, current_trial_nodes

def update_candidate_mapping(candidate_mask, aggr_mask, restrict_len, change_len):
    """
    根据 aggr_mask 中的新节点，更新 candidate_mask，并控制其容量。
    """
    new_candidate_indices = torch.where(aggr_mask == 1)[0]
    num_new_candidates = len(new_candidate_indices)
    
    if num_new_candidates == 0:
        return candidate_mask
        
    current_aggr_indices = torch.where(candidate_mask == 1)[0]
    num_current_aggr = len(current_aggr_indices)
    
    # 如果总数会超过上限，则随机删除旧节点
    if num_current_aggr + num_new_candidates > restrict_len:
        num_to_remove = num_current_aggr + num_new_candidates - restrict_len
        if num_to_remove > 0 and num_current_aggr > 0:
            remove_indices = current_aggr_indices[torch.multinomial(torch.ones(num_current_aggr), min(num_to_remove, num_current_aggr), replacement=False)]
            candidate_mask[remove_indices] = 0
          
    
    # 添加新的候选节点到 candidate_mask
    candidate_mask[new_candidate_indices] = 1
    
    return candidate_mask

def update_key_mask_from_candidates(data, key_mask, prev_low_score_edges, prev_trial_nodes, current_low_score_edges):
    """
    只有当上一轮的低分超边在本轮不再是低分超边时，才将其试探节点提升为关键节点。
    """
    current_low_score_set = set(current_low_score_edges)
    
    for edge_id in prev_low_score_edges:
        if edge_id in prev_trial_nodes:
            # 检查超边是否脱离了本轮的低分名单
            if edge_id not in current_low_score_set: 
                trial_node_index_in_hyperedge_index = prev_trial_nodes[edge_id]
                key_mask[trial_node_index_in_hyperedge_index] = 1
                
    return key_mask

def aggr_part(pos_hedges, Aggregator, e, args):
    pos_hedges = pos_hedges.clone().detach().to(args.device)
    embeddings = e[pos_hedges]
    pos_preds = Aggregator(embeddings)
    pos_preds = pos_preds.squeeze()
    return pos_preds

def loss_renew(args, pos_preds, neg_preds):
    bce_loss = nn.BCELoss()
    neg_labels = torch.zeros(len(neg_preds), dtype=torch.float, device=args.device)
    pos_labels = torch.ones(len(pos_preds), dtype=torch.float, device=args.device)
    d_real_loss = bce_loss(pos_preds, pos_labels)
    d_fake_loss = bce_loss(neg_preds, neg_labels)
    d_loss = (d_real_loss + d_fake_loss) / 2
    g_loss = bce_loss(neg_preds, torch.ones(len(neg_preds), device=args.device))
    return d_loss, g_loss

def model_train(data, args, model, Aggregator, Generator, optim_D, optim_G, optim_M, pos_hedges, epoch, aggr_mask, key_mask, candidate_mask, edge_ranges, is_last, prev_low_score_edges, prev_trial_nodes):
    params = yaml.safe_load(open('CNHCL-main-final/config.yaml'))[args.dataset]
    
    trainG = epoch <= params['change_epoch'] and epoch % 2 != 0
    trainD = not trainG

    model.train()
    optim_M.zero_grad(set_to_none=True)
    # 调用 model_part 时，传入 key_mask 和 candidate_mask
    loss = model_part(data, model, args, key_mask, candidate_mask)
    loss.backward()
    optim_M.step()
    model.eval()
    v_feat = data.features
    v, e = model(v_feat, data.hyperedge_index, data.num_nodes, data.num_edges)

    if trainG:
        Generator.train()
        optim_G.zero_grad(set_to_none=True)
        Aggregator.eval()
    elif trainD:
        Generator.eval()
        Aggregator.train()
        optim_D.zero_grad(set_to_none=True)

    if trainD:
        neg_preds = generator_part(Generator, params['neg_num_rate'], args, Aggregator, v)
        pos_preds = aggr_part(pos_hedges, Aggregator, e, args)
        d_loss, g_loss = loss_renew(args, pos_preds, neg_preds)
    elif trainG:
        neg_preds = generator_part(Generator, params['neg_num_rate'], args, Aggregator, v)
        bce_loss = nn.BCELoss()
        g_loss = bce_loss(neg_preds, torch.ones(len(neg_preds), device=args.device))

    if trainD:
        d_loss.backward()
        optim_D.step()
    elif trainG:
        g_loss.backward()
        optim_G.step()
    Aggregator.eval()
    Generator.eval()
    
    if is_last:
        current_low_score_edges, current_trial_nodes = exchange_part(
            args, Aggregator, e, data, aggr_mask, key_mask, candidate_mask, edge_ranges,
            prev_low_score_edges, prev_trial_nodes
        )
        return current_low_score_edges, current_trial_nodes
    else:
        return prev_low_score_edges, prev_trial_nodes
        
def exchange_part(
    args, 
    Aggregator, 
    e, 
    data, 
    aggr_mask, 
    key_mask, 
    candidate_mask, 
    edge_ranges, 
    prev_low_score_edges, 
    prev_trial_nodes
):
    """
    动态替换低分超边，更新关键掩码和候选掩码。
    """
    params = yaml.safe_load(open('CNHCL-main-final/config.yaml'))[args.dataset]
    restrict_len = int(params['res_rate'] * len(data.hyperedge_index[1]))
    change_len = params['change_len']

    # 1. 批量计算正例分数
    e_batch = e[:data.num_edges]
    pos_scores = Aggregator(e_batch).squeeze(-1)
    
    # 2. 选择本轮前 `change_len` 个最低分超边
    current_low_score_edges = torch.topk(-pos_scores, change_len, largest=False).indices.tolist()

    # 3. 更新关键掩码：根据上一轮的表现来判断
    key_mask = update_key_mask_from_candidates(
        data, key_mask, prev_low_score_edges, prev_trial_nodes, current_low_score_edges
    )

    # 4. 重置 aggr_mask（本轮新节点中转站）
    aggr_mask.fill_(0)

    # 5. 更新 aggr_mask 并追踪本轮试探节点
    aggr_mask, current_trial_nodes = update_aggr_mask(
        data.hyperedge_index, edge_ranges, current_low_score_edges, key_mask, aggr_mask
    )
    
    # 6. 更新 candidate_mask（动态候选池）
    candidate_mask = update_candidate_mapping(candidate_mask, aggr_mask, restrict_len, change_len)

    # 返回本次的低分超边和试探节点，供下一轮使用
    return current_low_score_edges, current_trial_nodes