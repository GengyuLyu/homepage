function [output_args,Theta_vec] = our_Clas( X,Y,train_index,para )
%DSML_MODEL Summary of this function goes here
%   Detailed explanation goes here
% input: X m*1 cell, each cell is a matrix of size n*dv
% Y: label indicator of l labeled instance l+u
% train_index: index of train samples
% para
%   alpha default is
%   beta default is
%   dim  the reduced dimention
%   maxIter
%   p exponential parameter controlling the sparity of weight vector
%此处显示此函数的DSML_MODEL摘要
%此处有详细说明
%输入：X m*1个单元格，每个单元格都是大小为n*dv的矩阵
%Y：l标记实例l+u的标签指示器
%train_index：训练样本索引
%段落
%alpha默认值为
%beta默认值为
%缩小尺寸
%最大Iter
%控制权向量稀疏性的p指数参数


m=length(X); %m=2
Train_index=zeros(size(Y));
Train_index(train_index,:)=1; %将Train_index第train_index行全变成1
alpha=para.alpha;
beta=para.beta;
gama=para.gama;

[n,q]=size(Y); %取行列n，c

M_set=cell(m,1);
W_set=cell(m,1);
H_set=cell(m,1);
k=para.dim;  %k的值
maxIter=para.maxIter;
for xx=1:m
    % clo = sum(X{xx},1);
    % del_clo = clo == 0;
    % X{xx}(:,del_clo) = [];
    % 
    % 
    % [~,score,~] = pca(X{xx});
    % X{xx} = score(:,1 : 8);
    % X{xx} = Normalize_row(X{xx});
    temp=abs(X{xx});
    temp=(temp-repmat(min(temp),size(temp,1),1))./repmat(max(temp)-min(temp),size(temp,1),1);
    X{xx}=temp;
    %X{xx} = normalization(X{xx}, 'l2', 1);
    H_set{xx}=rand(k,size(X{xx},2));%size(A,2)返回列，U_set是dv*k
    W_set{xx}=rand(size(X{xx},2),q);%W_set是dv*c
    S{xx} = L2_distance_1(X{xx}',X{xx}');
end
% A = rand(n, n);
A= diag(ones(1,q));
for xx=1:m
    
   % M_set{xx}=orth(A);
    M_set{xx} = eye(n, n);
end    
W=rand(k,q);%W0是k*c
P=rand(n,k);%V是n*k
Theta_vec=ones(m,1)/m;%最终式子
A=eye(q,q);%标签相关矩阵c*c

Convergence=zeros(maxIter,1);
iter=1;
Dv1=zeros(m,1);
    Wv_norm=0;
    Dv2=0;
    for vv=1:m
        Dv1(vv)=norm(M_set{vv}*X{vv}-P*H_set{vv},'fro')^2+alpha*norm(Train_index.*((P*W+P*H_set{vv}*W_set{vv})*A-Y),'fro')^2;
        Wv_norm=Wv_norm+norm(W_set{vv},'fro')^2;
    end
    for i = 1 :m
         for j = i: m
            if i ~= j
                Dv2 =Dv2+beta*norm(M_set{i}'*M_set{j}*S{i}*M_set{j}'*M_set{i}-S{j},'fro')^2;
            end
         end
    end
    
   Convergence(iter,1)=sum(Dv1)+Dv2+gama*(norm(W,'fro')^2+Wv_norm);%norm是范数
while iter<=maxIter
    %%    update Wv
    for vv=1:m
        Wv_up=alpha*H_set{vv}'*P'*Y*A';
        Wv_down=alpha*H_set{vv}'*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A')+gama*W_set{vv};
        W_set{vv}=W_set{vv}.*(Wv_up./Wv_down);
        W_set{vv}(isnan(W_set{vv}))=0;
        M_norms=sum(abs(W_set{vv}),2);
        M_norms=max(M_norms,1e-30);
        W_set{vv}=abs(W_set{vv})./repmat(M_norms,1,size(W_set{vv},2));
        W_set{vv}(isnan(W_set{vv}))=0;
    end
    %% update W
    W_up=zeros(k,q);
    W_down=zeros(k,q);
    for vv=1:m
        W_up=W_up+alpha*P'*Y*A';
        W_down=W_down+alpha*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A');
    end
    W_down=W_down+gama*W;
    W=W.*(W_up./W_down);
    W(isnan(W))=0;
    %%    update Mv
    for vv=1:m
        T1{vv}=zeros(n,n);
    end
    for vv=1:m
        T2{vv}=zeros(n,n);
    end
    for vv=1:m
        M_set{vv}=M_set{vv}+0.2;
    end
    % for i = 1 :m
    %      for j = i: m
    %         if i ~= j
    %             T1{i} =T1{i}+beta*M_set{j}*S{i}'*M_set{j}'*M_set{i}*S{j}+beta*M_set{j}*S{i}*M_set{j}'*M_set{i}*S{j}';
    %             T2{i} =T2{i}+beta*M_set{j}*S{i}'*M_set{j}'*M_set{i}*M_set{i}'*M_set{j}*S{i}*M_set{j}'*M_set{i}+beta*M_set{j}*S{i}*M_set{j}'*M_set{i}*M_set{i}'*M_set{j}*S{i}'*M_set{j}'*M_set{i};
    %         end
    %      end
    % end
    for vv=1:m
        for j = 1: m
            if vv ~= j
                T1{vv} =T1{vv}+beta*M_set{j}*S{vv}'*M_set{j}'*M_set{vv}*S{j}+beta*M_set{j}*S{vv}*M_set{j}'*M_set{vv}*S{j}';
                %T2{vv} =T2{vv}+beta*M_set{j}*S{vv}'*M_set{j}'*M_set{vv}*M_set{vv}'*M_set{j}*S{vv}*M_set{j}'*M_set{vv}+beta*M_set{j}*S{vv}*M_set{j}'*M_set{vv}*M_set{vv}'*M_set{j}*S{vv}'*M_set{j}'*M_set{vv};
            end
         end
        Mv_up=P*H_set{vv}*X{vv}'+T1{vv};
        % Mv_down=M_set{vv}*M_set{vv}'*P*H_set{vv}*X{vv}'+M_set{vv}*M_set{vv}'*T1{vv}-M_set{vv}*M_set{vv}'*T2{vv}+T2{vv};
        Mv_down=M_set{vv}*M_set{vv}'*P*H_set{vv}*X{vv}'+M_set{vv}*M_set{vv}'*T1{vv};
        %Mv_down=M_set{vv}*X{vv}*X{vv}'+T2{vv};
        M_set{vv}=M_set{vv}.*(Mv_up./Mv_down);
        M_set{vv}(isnan(M_set{vv}))=0;
        M_norms=sum(abs(M_set{vv}),2);
        M_norms=max(M_norms,1e-30);
        M_set{vv}=abs(M_set{vv})./repmat(M_norms,1,size(M_set{vv},2));
        M_set{vv}(isnan(M_set{vv}))=0;
        
    end
    %% update P
    P_up=zeros(n,k);
    P_down=zeros(k,k);
    for vv=1:m
        P_up=P_up+(M_set{vv}*X{vv}*H_set{vv}')+alpha*Y*A'*W_set{vv}'*H_set{vv}'+alpha*Y*A'*W';
        P_down=P_down+H_set{vv}*H_set{vv}'+alpha*(W+H_set{vv}*W_set{vv})*(A*A')*W'+alpha*(W+H_set{vv}*W_set{vv})*(A*A')*W_set{vv}'*H_set{vv}';
    end
    %P=P_up/P_down;
    P=P.*(P_up./(P*P_down));
    P(isnan(P))=0; %将NaN的置零
    
    norms = sum(abs(P),2);%每列合并
    norms = max(norms,1e-30);
    P=abs(P)./repmat(norms,1,size(P,2));%repmat将矩阵堆叠一行，一列变四列
    P(isnan(P))=0;

    
    %% update Hv
    for vv=1:m
        Hv_up=P'*M_set{vv}*X{vv}+alpha*P'*Y*A'*W_set{vv}';
        Hv_down=P'*P*H_set{vv}+alpha*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A')*W_set{vv}';
        H_set{vv}=H_set{vv}.*(Hv_up./Hv_down);
        H_norms=sum(abs(H_set{vv}),2);
        H_norms=max(H_norms,1e-30);
        H_set{vv}=abs(H_set{vv})./repmat(H_norms,1,size(H_set{vv},2));
        H_set{vv}(isnan(H_set{vv}))=0;
    end
    
    %% update A
    A_up=zeros(q,q);
    A_down=zeros(q,q);
    for ii=1:m
        A_up=A_up+(P*W+P*H_set{ii}*W_set{ii})'*Y;
        A_down=A_down+(P*W+P*H_set{ii}*W_set{ii})'*(P*W+P*H_set{ii}*W_set{ii});
    end
    %A=(A_up)/A_down;
    S_b_len = size(A_up);
    A=A_down\(A_up+eye(S_b_len(1)));
    
    %A=A.*(A_up./(A_down*A));
    A(A<0)=0;
    s_norms=sum(abs(A),1);%每行合并
    norms = max(s_norms,1e-30);
    A=abs(A)./repmat(norms,size(A,1),1);%一行堆叠变六行
    A(isnan(A))=0;
    A=A-diag(diag(A))+diag(ones(size(A,1),1));%先减去A的对角阵再加上对角1矩阵
    %% update Theta_vec
    Dv1=zeros(m,1);
    Wv_norm=0;
    Dv2=0;
    for vv=1:m
        Dv1(vv)=norm(M_set{vv}*X{vv}-P*H_set{vv},'fro')^2+alpha*norm(Train_index.*((P*W+P*H_set{vv}*W_set{vv})*A-Y),'fro')^2;
        Wv_norm=Wv_norm+norm(W_set{vv},'fro')^2;
    end
    for i = 1 :m
         for j = i: m
            if i ~= j
                Dv2 =Dv2+beta*norm(M_set{i}'*M_set{j}*S{i}*M_set{j}'*M_set{i}-S{j},'fro')^2;
            end
         end
    end
    %%
    Convergence(iter,1)=sum(Dv1)+Dv2+gama*(norm(W,'fro')^2+Wv_norm);%norm是范数
    if iter>1
        if abs(Convergence(iter,1)-Convergence(iter-1,1))<(1e-5)*Convergence(iter-1,1)%比前一次迭代更新少于1e-5时停止
            fprintf('\n ');
            disp(strcat('end at the ',31,num2str(iter),'th iteration'));
            break;
        end
    end
    iter=iter+1;
end
%% output求得y帽
W_output=zeros(size(W));
for vv=1:m
    W_output=W_output+H_set{vv}*W_set{vv};
end
output_args=P*(W_output/m+W)*A;

end

