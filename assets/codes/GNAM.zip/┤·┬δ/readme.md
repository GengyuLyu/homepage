# GNAM
Codes of Align while Fusion: A Generalized Non-Aligned Multi-View Multi-Label Classification Method

Run the 'demo_gnam.m' file for the final results. 

