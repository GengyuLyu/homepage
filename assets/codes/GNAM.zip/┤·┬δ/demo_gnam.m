% This is the demo for ganm
% there are two trade-off parameters \alpha and \beta
% we set half of the original dimensionality as the size of output
% representation ----- dim_ratio
% %% emotions para.alpha=0.000001;para.beta=0.7;para.gama=0.7;
data='emotions';
%1.5,0.7,0.7

para.dim_ratio=0.5;
para.alpha=10^(0);
para.beta=10^(0);
para.gama=10^(-1);
para.maxIter=100;%最大迭代次数
max_val=0;
% Training
 for i = -4:1:0
        for jj = -4:1:0
            for j = -4:1:0
                para.alpha=10^(i);
                para.beta=10^(jj);
                para.gama=10^(j);
                result=our_main(data,para);
                % fprintf('alpha：%d\n,beta:%d\n,gamma:%d\n', i,jj,j);
                if result(1,1) > max_val
                        max_val = result(1,1);
                        record = [i,jj,j];
                        record_result = result(:,:);
                        
                end
            end
        end
 end
 tags{1,1} = 'ours';
PrintResultsAll(record_result,tags);
% Training
% results=our_main(data,para);
% fprintf('平均结果为Accuracy=%-10.4f,1-RankingLoss=%-10.4f, AveragePrecision=%-10.4f, AUC=%-10.4f\n',...
%         results(1),results(2),results(3),results(4));
% fprintf('Finished!\n');

