% This is the demo for ganm
% there are two trade-off parameters \alpha and \beta
% we set half of the original dimensionality as the size of output
% representation ----- dim_ratio
% %% emotions para.alpha=0.000001;para.beta=0.7;para.gama=0.7;
data='Yeast';
%1.5,0.7,0.7

para.dim_ratio=0.5;
para.alpha=1.5;
para.beta=0.7;
para.gama=0.7;
para.maxIter=100;%最大迭代次数

% Training
results=our_main(data,para);
fprintf('平均结果为Accuracy=%-10.4f,1-RankingLoss=%-10.4f, AveragePrecision=%-10.4f, AUC=%-10.4f\n',...
        results(1),results(2),results(3),results(4));
fprintf('Finished!\n');

%i = randperm(8000,8000);
%A = data{3,1};
%A = A(i,:);
%data{2,1} = A;