function [tpr1,fpr1] = mlr_roc(f, y_test)


K=size(y_test,2);

for i=1:K
     [match(:,i),fpp(:,i),fnn(:,i)] = performance(y_test,f,i);
    tp1(i)=sum(match(:,i));
    fn1(i)=sum(fnn(:,i));
    fp1(i)=sum(fpp(:,i));
    tn1(i)=K*size(f,1)-(tp1(i)+fp1(i)+fn1(i));
    tpr1(i)=tp1(i)/(tp1(i)+fn1(i)); % Samples are considered all-together
    fpr1(i)=fp1(i)/(fp1(i)+tn1(i));
end

