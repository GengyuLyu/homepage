% This is the demo for ganm
% there are two trade-off parameters \alpha and \beta
% we set half of the original dimensionality as the size of output
% representation ----- dim_ratio
% %% emotions para.alpha=0.000001;para.beta=0.7;para.gama=0.7;
data='emotions';


para.dim_ratio=0.5;
para.alpha=10^(0);
para.beta=10^(0);
para.gama=10^(-1);
para.maxIter=100;
max_val=0;
% Training
 for i = -4:1:0
        for jj = -4:1:0
            for j = -4:1:0
                para.alpha=10^(i);
                para.beta=10^(jj);
                para.gama=10^(j);
                result=our_main(data,para);

                if result(1,1) > max_val
                        max_val = result(1,1);
                        record = [i,jj,j];
                        record_result = result(:,:);
                        
                end
            end
        end
 end
 tags{1,1} = 'ours';
PrintResultsAll(record_result,tags);


