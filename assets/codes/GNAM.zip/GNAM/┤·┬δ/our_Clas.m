function [output_args,Theta_vec] = our_Clas( X,Y,train_index,para )
m=length(X); %m=2
Train_index=zeros(size(Y));
Train_index(train_index,:)=1;
alpha=para.alpha;
beta=para.beta;
gama=para.gama;

[n,q]=size(Y);

M_set=cell(m,1);
W_set=cell(m,1);
H_set=cell(m,1);
k=para.dim;  
maxIter=para.maxIter;
for xx=1:m

    temp=abs(X{xx});
    temp=(temp-repmat(min(temp),size(temp,1),1))./repmat(max(temp)-min(temp),size(temp,1),1);
    X{xx}=temp;

    H_set{xx}=rand(k,size(X{xx},2));
    W_set{xx}=rand(size(X{xx},2),q);
    S{xx} = L2_distance_1(X{xx}',X{xx}');
end

A= diag(ones(1,q));
for xx=1:m

    M_set{xx} = eye(n, n);
end    
W=rand(k,q);
P=rand(n,k);
Theta_vec=ones(m,1)/m;
A=eye(q,q);

Convergence=zeros(maxIter,1);
iter=1;
Dv1=zeros(m,1);
    Wv_norm=0;
    Dv2=0;
    for vv=1:m
        Dv1(vv)=norm(M_set{vv}*X{vv}-P*H_set{vv},'fro')^2+alpha*norm(Train_index.*((P*W+P*H_set{vv}*W_set{vv})*A-Y),'fro')^2;
        Wv_norm=Wv_norm+norm(W_set{vv},'fro')^2;
    end
    for i = 1 :m
         for j = i: m
            if i ~= j
                Dv2 =Dv2+beta*norm(M_set{i}'*M_set{j}*S{i}*M_set{j}'*M_set{i}-S{j},'fro')^2;
            end
         end
    end
    
   Convergence(iter,1)=sum(Dv1)+Dv2+gama*(norm(W,'fro')^2+Wv_norm);%norm是范数
while iter<=maxIter
    %%    update Wv
    for vv=1:m
        Wv_up=alpha*H_set{vv}'*P'*Y*A';
        Wv_down=alpha*H_set{vv}'*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A')+gama*W_set{vv};
        W_set{vv}=W_set{vv}.*(Wv_up./Wv_down);
        W_set{vv}(isnan(W_set{vv}))=0;
        M_norms=sum(abs(W_set{vv}),2);
        M_norms=max(M_norms,1e-30);
        W_set{vv}=abs(W_set{vv})./repmat(M_norms,1,size(W_set{vv},2));
        W_set{vv}(isnan(W_set{vv}))=0;
    end
    %% update W
    W_up=zeros(k,q);
    W_down=zeros(k,q);
    for vv=1:m
        W_up=W_up+alpha*P'*Y*A';
        W_down=W_down+alpha*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A');
    end
    W_down=W_down+gama*W;
    W=W.*(W_up./W_down);
    W(isnan(W))=0;
    %%    update Mv
    for vv=1:m
        T1{vv}=zeros(n,n);
    end
    for vv=1:m
        T2{vv}=zeros(n,n);
    end
    for vv=1:m
        M_set{vv}=M_set{vv}+0.2;
    end

    for vv=1:m
        for j = 1: m
            if vv ~= j
                T1{vv} =T1{vv}+beta*M_set{j}*S{vv}'*M_set{j}'*M_set{vv}*S{j}+beta*M_set{j}*S{vv}*M_set{j}'*M_set{vv}*S{j}';
                %T2{vv} =T2{vv}+beta*M_set{j}*S{vv}'*M_set{j}'*M_set{vv}*M_set{vv}'*M_set{j}*S{vv}*M_set{j}'*M_set{vv}+beta*M_set{j}*S{vv}*M_set{j}'*M_set{vv}*M_set{vv}'*M_set{j}*S{vv}'*M_set{j}'*M_set{vv};
            end
         end
        Mv_up=P*H_set{vv}*X{vv}'+T1{vv};

        Mv_down=M_set{vv}*M_set{vv}'*P*H_set{vv}*X{vv}'+M_set{vv}*M_set{vv}'*T1{vv};

        M_set{vv}=M_set{vv}.*(Mv_up./Mv_down);
        M_set{vv}(isnan(M_set{vv}))=0;
        M_norms=sum(abs(M_set{vv}),2);
        M_norms=max(M_norms,1e-30);
        M_set{vv}=abs(M_set{vv})./repmat(M_norms,1,size(M_set{vv},2));
        M_set{vv}(isnan(M_set{vv}))=0;
        
    end
    %% update P
    P_up=zeros(n,k);
    P_down=zeros(k,k);
    for vv=1:m
        P_up=P_up+(M_set{vv}*X{vv}*H_set{vv}')+alpha*Y*A'*W_set{vv}'*H_set{vv}'+alpha*Y*A'*W';
        P_down=P_down+H_set{vv}*H_set{vv}'+alpha*(W+H_set{vv}*W_set{vv})*(A*A')*W'+alpha*(W+H_set{vv}*W_set{vv})*(A*A')*W_set{vv}'*H_set{vv}';
    end
    %P=P_up/P_down;
    P=P.*(P_up./(P*P_down));
    P(isnan(P))=0; 
    
    norms = sum(abs(P),2);%每列合并
    norms = max(norms,1e-30);
    P=abs(P)./repmat(norms,1,size(P,2));
    P(isnan(P))=0;

    
    %% update Hv
    for vv=1:m
        Hv_up=P'*M_set{vv}*X{vv}+alpha*P'*Y*A'*W_set{vv}';
        Hv_down=P'*P*H_set{vv}+alpha*P'*(P*W+P*H_set{vv}*W_set{vv})*(A*A')*W_set{vv}';
        H_set{vv}=H_set{vv}.*(Hv_up./Hv_down);
        H_norms=sum(abs(H_set{vv}),2);
        H_norms=max(H_norms,1e-30);
        H_set{vv}=abs(H_set{vv})./repmat(H_norms,1,size(H_set{vv},2));
        H_set{vv}(isnan(H_set{vv}))=0;
    end
    
    %% update A
    A_up=zeros(q,q);
    A_down=zeros(q,q);
    for ii=1:m
        A_up=A_up+(P*W+P*H_set{ii}*W_set{ii})'*Y;
        A_down=A_down+(P*W+P*H_set{ii}*W_set{ii})'*(P*W+P*H_set{ii}*W_set{ii});
    end

    S_b_len = size(A_up);
    A=A_down\(A_up+eye(S_b_len(1)));
 
    A(A<0)=0;
    s_norms=sum(abs(A),1);
    norms = max(s_norms,1e-30);
    A=abs(A)./repmat(norms,size(A,1),1);
    A(isnan(A))=0;
    A=A-diag(diag(A))+diag(ones(size(A,1),1));
    %% update Theta_vec
    Dv1=zeros(m,1);
    Wv_norm=0;
    Dv2=0;
    for vv=1:m
        Dv1(vv)=norm(M_set{vv}*X{vv}-P*H_set{vv},'fro')^2+alpha*norm(Train_index.*((P*W+P*H_set{vv}*W_set{vv})*A-Y),'fro')^2;
        Wv_norm=Wv_norm+norm(W_set{vv},'fro')^2;
    end
    for i = 1 :m
         for j = i: m
            if i ~= j
                Dv2 =Dv2+beta*norm(M_set{i}'*M_set{j}*S{i}*M_set{j}'*M_set{i}-S{j},'fro')^2;
            end
         end
    end
    %%
    Convergence(iter,1)=sum(Dv1)+Dv2+gama*(norm(W,'fro')^2+Wv_norm);
    if iter>1
        if abs(Convergence(iter,1)-Convergence(iter-1,1))<(1e-5)*Convergence(iter-1,1)
            fprintf('\n ');
            disp(strcat('end at the ',31,num2str(iter),'th iteration'));
            break;
        end
    end
    iter=iter+1;
end

W_output=zeros(size(W));
for vv=1:m
    W_output=W_output+H_set{vv}*W_set{vv};
end
output_args=P*(W_output/m+W)*A;

end

