function [newZ]=Top_K_Partition(Z,topK)

Z=Z';
[Ndata,Nfun]=size(Z);

newZ=full(-ones(Ndata,Nfun));
for ii=1:Ndata
    Zii=full(Z(ii,:));
    [sorted, index] = sort(Zii,'descend');
    newZ(ii,index(1:topK))=1;
end

newZ=newZ';