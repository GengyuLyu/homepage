# AF-UMC
AF-UMC: An Alignment-Free Fusion Framework for Unaligned Multi-View Clustering

run train.py to train and valid the performance of AF-UMC
