Code for the HyperAHSF

Run the 'train.py' file for the final results