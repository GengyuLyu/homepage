python train_batch.py --dataset Pascal.mat --batch_size 20 --end_epochs 20 --at 0.8 --k 2 --seed 10 --t 0.85
python train_batch.py --dataset Iaprtc12.mat --batch_size 40 --end_epochs 15 --at 0.8 --k 2 --seed 10 --t 0.85
python train_batch.py --dataset Espgame.mat --batch_size 40 --end_epochs 15 --at 0.8 --k 2 --seed 10 --t 0.85
python train_batch.py --dataset Mirflickr.mat --batch_size 50 --end_epochs 15 --at 0.8 --k 2 --seed 10 --t 0.85