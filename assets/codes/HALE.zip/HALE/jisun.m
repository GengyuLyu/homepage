function jisun(x, matches, target)

filtered = zeros(size(target));
for i = 1 : length(x)
        filtered(matches(i,1), matches(i,2)) = x(i);
end

for i = 1 : size(target,2)
    [m,n] = max(filtered(:,i));
    filtered(n,i) = 1;
end
filtered(filtered~=1)=0;


num = sum(filtered(:) .* target(:));
accuracy = num / size(target, 2);

fprintf(' train accuracy: %f\n', full(accuracy));

end