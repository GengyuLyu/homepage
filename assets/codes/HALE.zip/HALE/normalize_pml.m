function [ p ] = normalize_pml( q, group )

[~, group_id] = find(group);
nGroups = max(group_id);
for gid = 1 : nGroups
    [match_id, ~] = find(group(:,gid));
    norm_q = max(q(match_id)) + eps;
    q(match_id) = q(match_id) / norm_q;
end
p = q;


end

