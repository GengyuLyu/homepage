function X = PSM(K, group1, iter)
    
    mm = size(K, 1);
    ro = 1e-6;
    if nargin < 4 || iter <= 0
        iter = 1000;
    end
    
    p = ones(mm, 1);
    if issparse(K)
        p = sparse(p);
    end
    p = normalize_pml(p, group1);
    AA = K;
    
    for i = 1 : iter
        p_ = p;
        q = AA * p;
        
       p = normalize_pml(q, group1);

        p_ = p_ + eps;
        
        if issparse(K)
            AA = AA';
            for col = 1:size(AA,1)
                AA(:,col) = AA(:,col) *(p(col) / p_(col));
            end
            AA = AA';
        else
            AA = AA .* ((p./ p_) * (ones(1, mm)));
        end
        
        if sqrt(sum((p - p_).^2))/(mm) < ro
            break;   
        end 
        

    end
    X = p;         
end
