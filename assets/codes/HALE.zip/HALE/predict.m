function [ Outputs ] = predict( test_data, train_data, train_target )

% prediction

data = [train_data; test_data];
data = normr(data);
train_data = normr(train_data);
test_data = normr(test_data);

kdtree = KDTreeSearcher(train_data);
model.kdtree = kdtree;
[testNeighbor,testDist] = knnsearch(model.kdtree,test_data,'k',10);


neighbor_label = [];
for i = 1 : size(test_data,1)
    neighborIns = data(testNeighbor(i,:),:)';
    w = lsqnonneg(neighborIns,test_data(i,:)');
    
    neighbor_target = train_target(:,testNeighbor(i,:));
    w = w';
    w = repmat(w,size(neighbor_target,1),1);
    neighbor_label = [neighbor_label, sum((w .* neighbor_target),2)];
end

Outputs = neighbor_label;

end

