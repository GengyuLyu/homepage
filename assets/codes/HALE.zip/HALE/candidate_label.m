function [ partial_target ] = candidate_label( target, cand_label_num )

partial_target = target;
ins_num = size(target,1);
label_num = size(target,2);

for i = 1 : ins_num
    if (sum(partial_target(i,:),2) < cand_label_num)
        index = find(partial_target(i,:) == 0);
        m = randperm(cand_label_num - label_num + size(index,2));
        partial_target(i,index(1,m)) = 1;
    end
end


end

