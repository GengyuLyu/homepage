function [ label_similarity_matrix ] = ConstructLabelSimilarityMatrix( partial_labels )


label_num  = size(partial_labels,1);
ins_num = size(partial_labels,2);

label_similarity_matrix = zeros();

for i = 1 : label_num
    for j = 1 : label_num
        index = find(partial_labels(i,:) == 1);
        if (size(index,2) ~= 0)
            label_similarity_matrix(i,j) = (sum(partial_labels(j,index)))/size(index,2);
        end
    end  
end


end

