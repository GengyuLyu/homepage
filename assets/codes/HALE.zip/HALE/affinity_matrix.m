function [ affinity, instance_group, label_group, matches ] = affinity_matrix( train_data, partial_label )


 S = ConstructSimilarityMatrix(train_data,10); 
 L = ConstructLabelSimilarityMatrix(partial_label);
 
 [labels, instances, ~] = find(partial_label);
 
 matches = [labels, instances];
 
 affinity_row = length(labels);
 affinity_col = length(labels);
 
 instance_group = zeros(affinity_row, size(partial_label, 2));
 label_group = zeros(affinity_row, size(partial_label,1));
 
 for i = 1 : affinity_row
     instance_group(i, instances(i)) = 1;
     label_group(i, labels(i)) = 1;
 end
 
 affinity = zeros(affinity_row, affinity_col);

 
 for i = 1 : affinity_row
    for j = 1 : affinity_col
        if (labels(i) == labels(j))
            affinity(i,j) = S(instances(i), instances(j)) * L(labels(i),labels(j));
        end
    end
 end

end

