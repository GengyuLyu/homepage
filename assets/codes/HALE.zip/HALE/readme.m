load('Image2.mat');

[row,col]=size(data);
%data = zscore(data);

nfold = 10;

encode=crossvalind('Kfold',data(1:row,col),nfold);
for i = 1 : nfold
    test = (encode == i);
    train_data = data(~test, :);
    test_data = data(test, :);
    train_p_target = partial_target(:, ~test);
    test_GT = target(:, test);
    train_GT = target(:, ~test);
    % affinity matrix
    [affinity, instance_group, label_group, matches] = affinity_matrix(train_data, train_p_target);
    % PSM
    x = PSM(affinity, instance_group, 1000);   

    train_target = zeros(size(train_p_target));
    for k = 1 : length(x)
        train_target(matches(k,1), matches(k,2)) = x(k);
    end
    % prediction
    Outputs = predict(test_data, train_data, train_target);
    % normalize the outputs
    for iter = 1 : size(test_data,1)
        max_value = max(Outputs(:,iter));
        Outputs(:,iter) = Outputs(:,iter)/max_value;
    end
end
    