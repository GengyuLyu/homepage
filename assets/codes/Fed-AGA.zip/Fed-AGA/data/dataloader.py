from sklearn.preprocessing import MinMaxScaler, MaxAbsScaler
import numpy as np
from torch.utils.data import Dataset
import scipy.io
import torch
import h5py
from scipy.sparse import load_npz

class BDGP(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
       # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X'][0][0].astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X'][0][1].astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X'][0][2].astype(np.float32).transpose())
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)

        self.labels = scipy.io.loadmat(path)['gt']



    def __len__(self):
        return 4485

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
           self.view2[idx]), torch.from_numpy(self.view3[idx])], torch.from_numpy(self.labels[idx]), torch.from_numpy(np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]


class BDGP_100Leaves(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['data'][0][0].astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['data'][0][1].astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['data'][0][2].astype(np.float32).transpose())
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)

        self.labels = scipy.io.loadmat(path)['truth']

    def __len__(self):
        return 1600

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx])], torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Aloi(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['data'][0][0].astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['data'][0][1].astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['data'][0][2].astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['data'][0][3].astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)

        self.labels = scipy.io.loadmat(path)['truelabel'][0][0]

    def __len__(self):
        return 10800

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view3[idx])], \
               torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Animal(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X'][0][0].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X'][0][1].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X'][0][2].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X'][0][3].T.astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)

        self.labels = scipy.io.loadmat(path)['Y']

    def __len__(self):
        return 11673

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx])
                   , torch.from_numpy(self.view4[idx])],\
               torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]
class BDGP_Caltech(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X1'].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X2'].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X3'].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X4'].T.astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(data['X5'].T.astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = scipy.io.loadmat(path)['Y'].T

    def __len__(self):
        return 1400

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx])
                ,torch.from_numpy(self.view4[idx]), torch.from_numpy(
            self.view5[idx])],\
               torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Caltech7(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X1'].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X2'].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X3'].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X4'].T.astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(data['X5'].T.astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = scipy.io.loadmat(path)['Y'].T

    def __len__(self):
        return 1400

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx])
                ,torch.from_numpy(self.view4[idx]), torch.from_numpy(
            self.view5[idx])],\
               torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Mfeat(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X'][0][0].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X'][1][0].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X'][2][0].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X'][3][0].T.astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(data['X'][4][0].T.astype(np.float32).transpose())
        self.view6 = scaler.fit_transform(data['X'][5][0].T.astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)
        self.views.append(self.view6)

        self.labels = scipy.io.loadmat(path)['Y']

    def __len__(self):
        return 2000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx]), torch.from_numpy(self.view3[idx])
               ,torch.from_numpy(self.view4[idx]), torch.from_numpy(
            self.view5[idx]), torch.from_numpy(self.view6[idx])],\
               torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]
class BDGP_NoisyMNIST_30000(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # print('data',data)
        # data = h5py.File(path)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X1'].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X2'].T.astype(np.float32).transpose())
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)


        self.labels = scipy.io.loadmat(path)['Y'].T

    def __len__(self):
        return 30000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]), torch.from_numpy(
            self.view2[idx])], torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_bbcsport(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)

        # print('data',data)

        scaler = MinMaxScaler()
        # scaler = MaxAbsScaler()

        self.view1 = scaler.fit_transform(data['X'][0][0].toarray().T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X'][0][1].toarray().T.astype(np.float32).transpose())
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)

        self.labels = scipy.io.loadmat(path)['Y']
    def __len__(self):
        return 544

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]



class BDGP_Caltech101_7(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)
        print(data.keys())
        print(data['X'])
        print(data['X'][0])
        print(data[data['X'][0][0]])
        print(data[data['X'][1][0]])
        print(data[data['X'][2][0]])
        print(data[data['X'][3][0]])
        print(data[data['X'][4][0]])
        print(data[data['X'][5][0]])

        print(data['Y'])
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())
        self.view6 = scaler.fit_transform(np.array(data[data['X'][5][0]]).astype(np.float32).transpose())

        print(1)
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)
        self.views.append(self.view6)

        self.labels = np.array(data['Y']).T
        print(1)
    def __len__(self):
        return 1474

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx]),
                torch.from_numpy(self.view6[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Caltech101_all(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 9144

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_CCV(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 6773

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_cifar10(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 50000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_handwritten(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())
        self.view6 = scaler.fit_transform(np.array(data[data['X'][5][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)
        self.views.append(self.view6)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 2000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx]),
                torch.from_numpy(self.view6[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_MSRCv1(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)


        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 210

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_NGs(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)


        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 500

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_NoisyMNIST(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)



        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 50000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_NUSWIDEOBJ(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        # data = h5py.File(path)
        # print('data',data)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X'][0][0].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X'][0][1].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X'][0][2].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X'][0][3].T.astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(data['X'][0][4].T.astype(np.float32).transpose())


        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = data['Y']

    def __len__(self):
        return 30000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_YoutubeFace(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = h5py.File(path)

        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 101499

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_Hdigit(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        # data = h5py.File(path)

        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['data'][0][0].astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['data'][0][1].astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)


        self.labels = np.array(data['truelabel'][0][1]).T

    def __len__(self):
        return 10000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_REU(Dataset):
    def __init__(self, path):
        data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        # data = h5py.File(path)

        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(data['X1'].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['X2'].T.astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(data['X3'].T.astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(data['X4'].T.astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(data['X5'].T.astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)

        self.labels = data['Y'].T

    def __len__(self):
        return 1200

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]

class BDGP_voc(Dataset):
    def __init__(self, path):
        # data = scipy.io.loadmat(path)
        # data = mat73.loadmat(path)
        data = np.load(path)
        # data = h5py.File(path)

        scaler = MinMaxScaler()
        self.view1 = scaler.fit_transform(data['view_0'].T.astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(data['view_1'].T.astype(np.float32).transpose())
        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)

        self.labels = data['labels']
        self.labels = np.expand_dims(self.labels, axis=1)
    def __len__(self):
        return 5649

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]



def load_data(dataset):
    if dataset == "Scene":
        dataset = BDGP('./data/scene15.mat')
        dims = [20, 59, 40]
        view = 3
        data_size = 4485
        class_num = 15
    elif dataset == "100Leaves":
        dataset = BDGP_100Leaves('./data/100Leaves.mat')
        dims = [64, 64, 64]
        view = 3
        data_size = 1600
        class_num = 100
    elif dataset == "Aloi":
        dataset = BDGP_Aloi('./data/Aloi-100.mat')
        dims = [77, 13, 64, 125]
        view = 4
        data_size = 10800
        class_num = 100
    elif dataset == "Animal":
        dataset = BDGP_Animal('./data/Animal.mat')
        dims = [2689, 2000, 2001, 2000]
        view = 4
        data_size = 11673
        class_num = 20
    elif dataset == "Caltech":
        dataset = BDGP_Caltech('./data/Caltech-5V.mat')
        dims = [40, 254, 1984, 512, 928]
        view = 5
        data_size = 1400
        class_num = 6
    elif dataset == "Caltech7":
        dataset = BDGP_Caltech7('./data/Caltech-5V-7.mat')
        dims = [40, 254, 1984, 512, 928]
        view = 5
        data_size = 1400
        class_num = 7
    elif dataset == "Mfeat":
        dataset = BDGP_Mfeat('./data/Mfeat.mat')
        dims = [216, 76, 64, 6, 240, 47]
        view = 6
        data_size = 2000
        class_num = 10
    elif dataset == "NoisyMNIST-30000":
        dataset = BDGP_NoisyMNIST_30000('./data/NoisyMNIST-30000.mat')
        dims = [784, 784]
        view = 2
        data_size = 30000
        class_num = 10
    elif dataset == "bbcsport":
        dataset = BDGP_bbcsport('./data/bbcsport.mat')
        dims = [3183, 3203]
        view = 2
        data_size = 544
        class_num = 5
    elif dataset == "Caltech101-7":
        dataset = BDGP_Caltech101_7('./data/Caltech101-7.mat')
        dims = [48, 40, 254, 1984, 512, 928]
        view = 6
        data_size = 1474
        class_num = 7
    elif dataset == "Caltech101-all":
        dataset = BDGP_Caltech101_all('./data/Caltech101-all.mat')
        dims = [48, 40, 254, 512, 928]
        view = 5
        data_size = 9144
        class_num = 102
    elif dataset == "CCV":
        dataset = BDGP_CCV('./data/CCV.mat')
        dims = [20, 20, 20]
        view = 3
        data_size = 6773
        class_num = 20
    elif dataset == "cifar10":
        dataset = BDGP_cifar10('./data/cifar10.mat')
        dims = [512, 2048, 1024]
        view = 3
        data_size = 50000
        class_num = 10
    elif dataset == "handwritten":
        dataset = BDGP_handwritten('./data/handwritten.mat')
        dims = [240, 76, 216, 47, 64, 6]
        view = 6
        data_size = 2000
        class_num = 10
    elif dataset == "MSRCv1":
        dataset = BDGP_MSRCv1('./data/MSRCv1.mat')
        dims = [24, 576, 512, 256, 254]
        view = 5
        data_size = 210
        class_num = 7
    elif dataset == "NGs":
        dataset = BDGP_NGs('./data/NGs.mat')
        dims = [2000, 2000, 2000]
        view = 3
        data_size = 500
        class_num = 5
    elif dataset == "NoisyMNIST":
        dataset = BDGP_NoisyMNIST('./data/NoisyMNIST.mat')
        dims = [784, 784]
        view = 2
        data_size = 50000
        class_num = 10
    elif dataset == "NUSWIDEOBJ":
        dataset = BDGP_NUSWIDEOBJ('./data/NUSWIDEOBJ.mat')
        dims = [65, 226, 145, 74, 129]
        view = 5
        data_size = 30000
        class_num = 31
    elif dataset == "YoutubeFace":
        dataset = BDGP_YoutubeFace('./data/YoutubeFace.mat')
        dims = [64, 512, 64, 647, 838]
        view = 5
        data_size = 101499
        class_num = 31
    elif dataset == "Hdigit":
        dataset = BDGP_Hdigit('./data/Hdigit.mat')
        dims = [784, 256]
        view = 2
        data_size = 10000
        class_num = 10
    elif dataset == "REU":
        dataset = BDGP_REU('./data/REU.mat')
        dims = [2000, 2000, 2000, 2000, 2000]
        view = 5
        data_size = 1200
        class_num = 6
    elif dataset == "voc":
        dataset = BDGP_voc('./data/voc.npz')
        dims = [512, 399]
        view = 2
        data_size = 5649
        class_num = 20
    else:
        raise NotImplementedError
    dataset = Form_Unaligned_Data(dataset, view, class_num)
    return dataset, dims, view, data_size, class_num

import random
def Form_Unaligned_Data(dataset, view, class_num):
    # np.random.seed(0)

    X = []
    Y = []
    for i in range(view):
        X.append(dataset.get_view(i))
        Y.append(dataset.get_view(-1))

    size = len(Y[0])
    t = np.linspace(0, size - 1, size, dtype=int)

    random.shuffle(t)
    Xtmp = []
    Ytmp = []
    for i in range(view):
        xtmp = np.copy(X[i])
        Xtmp.append(xtmp)
        ytmp = np.copy(Y[i])
        Ytmp.append(ytmp)

    for v in range(view):

        random.shuffle(t)
        Xtmp[v][:] = X[v][t]
        Ytmp[v][:] = Y[v][t]


    view_datasets = []
    for v in range(view):
        view_datasets.append(GN_Dataset(Xtmp[v], Ytmp[v]))
    return view_datasets


class GN_Dataset(Dataset):
    def __init__(self, dataset, y):
        self.dataset = dataset
        self.labels = y

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        data_tensor = torch.from_numpy(self.dataset[index].astype(np.float32).transpose())
        label_tensor = torch.tensor(self.labels[index])
        return data_tensor, label_tensor, index
    
