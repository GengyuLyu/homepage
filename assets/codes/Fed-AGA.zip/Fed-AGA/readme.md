# Fed-AGA
Fed-AGA:  An Anchor Graph Alignment Framework for Federated Unaligned Multi-view Clustering

Install the necessary dependencies using pip:
```bash
pip install -r requirements.txt
```
Run main.py to train and valid the performance of Fed-AGA
