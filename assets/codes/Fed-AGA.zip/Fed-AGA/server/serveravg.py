import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import copy
import time
import os
from model.models import MyServerModel
from server.serverbase import Server
from users.usersavg import UsersAvg
from torch.utils.data import DataLoader, TensorDataset
 


class ServerAvg(Server):
    def __init__(self, device, sample_dim, data, data_size, iterations, top_p,
                 class_num, anchor_dim, num_views, sv_lr, pre_epochs, top_k, attention_temperature, cluster_bias,
                 sv_epochs, temperature, cl_epochs, cl_lr, d, cl_batch_size, lamda1, pre_lr):

        super().__init__( device, sample_dim, data, data_size, iterations, top_p,
                 class_num, anchor_dim, num_views, sv_lr, pre_epochs, top_k, attention_temperature, cluster_bias,
                 sv_epochs, temperature, cl_epochs, cl_lr, d, cl_batch_size, lamda1, pre_lr)
        
        self.S = {v: {} for v in range(self.num_users)}
        self.base_seed = 10
        self.G_aligned_avg = None
        self.G_foruser = [None] * self.num_users
        self.users = []
        for id in range(self.num_users):
            train_data = data[id]
            user = UsersAvg(id, device, anchor_dim, train_data, sample_dim[id], temperature, num_views, 
                            data_size, class_num, pre_epochs, cl_epochs, cl_lr, d, cl_batch_size, lamda1,
                            pre_lr)
            self.users.append(user)

    def train(self):

        
        ii = 0
        G_list_pre = []
        pre_lr = [self.pre_lr] * self.num_users
        pretrain_epochs = [self.pre_epochs] * self.num_users
        if self.enable_pretrain:
            for user in self.users:
                ii += 1
                user.pretrain(pretrain_epochs[ii-1], pre_lr[ii-1])

        for user in self.users:
            G_list_pre.append(user.forserver())

        self.ref, scores = self.chose_best(G_list_pre)
        label = self.get_label(self.ref)
        self.aligners.ref = self.ref


        for it in range(self.iterations):

            G_list = []
            A_sim_list = []
            cluster_assignments_list = []
            v = 0
            for user in self.users:
                G_get = user.train(
                    it, v,
                    self.R_list[v], self.mu_ref[v], self.chosen[v]
                )
                G_list.append(G_get)
                v += 1

            G_sum = sum(G_list) / self.num_users

            self.get_centers(G_list)
            if it % 1 == 0:

                out = self.server_align_with_lsd(G_list, top_p=self.top_p)

                self.mu_ref = [out['views'][v]['mu_ref_ordered'].to(self.device) for v in range(self.num_users)]
                self.chosen = [out['views'][v]['chosen'] for v in range(self.num_users)]
                if it >= 1:
                    for v in range(self.num_users):
                        if v != self.ref:
                            self.R_list[v] = self.update_rotation(self.R_list[v], out['views'][v]['R'], beta=0.05)
                                
                else:
                    self.R_list = [out['views'][v]['R'] for v in range(self.num_users)]



            G_list = [g.to(self.device) for g in G_list]

            stacked_G = torch.stack(G_list, dim=0).permute(1, 0, 2)
            stacked_clusters = torch.stack(self.label_assignments, dim=1)
            original_indices = torch.arange(self.data_size, device=self.device)
            server_dataset = TensorDataset(stacked_G, stacked_clusters, original_indices)
            server_loader = DataLoader(server_dataset, batch_size=self.cl_batch_size,
                                       shuffle=False) 
            

            G_aligned_full = [torch.zeros_like(g, device=self.device) for g in G_list]


            S_dict = {v_idx: {} for v_idx in range(self.num_users)}
            

            last_epoch_loss = 0
            if it >= 1:

                for epochsv in range(1, self.sv_epochs + 1):
                    total_epoch_loss = 0
                    for batch_idx, (G_batch_stacked, clusters_batch, batch_indices) in enumerate(server_loader):

                        G_batch_stacked = G_batch_stacked.permute(1, 0, 2)
                        ref_G_batch = G_batch_stacked[self.ref]
                        key_list_batch = list(G_batch_stacked)
                        value_list_batch = list(G_batch_stacked)

                        cluster_assignments_batch = {v_idx: clusters_batch[:, v_idx] for v_idx in range(self.num_users)}
                        
                        self.optimizers_aligners.zero_grad()
                        G_aligned_list_batch = self.aligners(
                            query=ref_G_batch,
                            key=key_list_batch,
                            value=value_list_batch,
                            cluster_assignments=cluster_assignments_batch,
                            allow=True
                        )

                        loss = 0
                        for i in filter(lambda x: x != self.ref, range(0, self.num_users)):
                            loss += self.contrastive_loss(G_aligned_list_batch[self.ref], G_aligned_list_batch[i])

                        if self.num_users > 1:
                            loss = loss / (self.num_users - 1)

                        loss.backward()
                        self.optimizers_aligners.step()
                        total_epoch_loss += loss.item()


                        for v_idx, g_aligned_batch in enumerate(G_aligned_list_batch):
                            G_aligned_full[v_idx][batch_indices] = g_aligned_batch.detach()



                    avg_epoch_loss = total_epoch_loss / len(server_loader) if len(server_loader) > 0 else 0

                    last_epoch_loss = avg_epoch_loss


                    temp_G_aligned_avg = sum(G_aligned_full) / self.num_users
                    

                    if epochsv == self.sv_epochs and it == self.iterations -1:
                        nmi, ari, accc, pur = self.evaluate_clustering(epoch=epochsv, true_labels=label, iteration=it, G_avg=temp_G_aligned_avg)
                        print(f"--- Iteration {it+1}  ACC: {accc:.4f}, NMI: {nmi:.4f}, ARI: {ari:.4f}, PUR: {pur:.4f} ---")

                self.scheduler.step()
                labell = []
                for i in range(self.num_users):
                    labell.append(label)

                self.G_aligned_avg = sum(G_aligned_full) / self.num_users


        #return accc, nmi, ari, pur