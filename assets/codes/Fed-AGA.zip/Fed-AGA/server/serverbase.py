import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import accuracy_score, v_measure_score, adjusted_rand_score
from model.models import MyServerModel, MLP
from sklearn.cluster import KMeans
from users.usersbase import User
from torch.utils.data import DataLoader
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import netlsd as lsd
import networkx as nx
from sklearn.metrics import pairwise_distances
from scipy import stats
from sklearn.neighbors import NearestNeighbors
from torch.optim.lr_scheduler import StepLR, CosineAnnealingLR, ExponentialLR
class Server:
    def __init__(self, device, sample_dim, data, data_size, iterations, top_p,
                 class_num, anchor_dim, num_views, sv_lr, pre_epochs, top_k, attention_temperature, cluster_bias,
                 sv_epochs, temperature, cl_epochs, cl_lr, d, cl_batch_size, lamda1, pre_lr):
        self.device = device
        self.sample_dim = sample_dim
        self.data = data
        self.data_size = data_size
        self.iterations = iterations
        self.class_num = class_num
        self.anchor_dim = anchor_dim
        self.num_users = num_views
        self.sv_lr = sv_lr
        self.pre_epochs = pre_epochs
        self.top_k = top_k
        self.attention_temperature = attention_temperature
        self.top_p = top_p
        self.sv_epochs = sv_epochs
        self.temperature = temperature
        self.cluster_bias = cluster_bias
        self.cl_epochs = cl_epochs
        self.cl_lr = cl_lr
        self.d = d
        self.sv_lr = sv_lr
        self.cl_batch_size = cl_batch_size
        self.lamda1 = lamda1
        self.pre_lr = pre_lr
        self.enable_pretrain = True
        self.X_full = []
        self.ref = 0
        self.testlabel = self.label_fortest()
        self.C_list = [None for _ in range(self.num_users)]
        self.R_list = [torch.eye(self.anchor_dim).to(self.device) for _ in range(self.num_users)]
        self.mu_ref = [torch.zeros(self.class_num, self.anchor_dim).to(self.device) for _ in range(self.num_users)]
        self.chosen = [None for _ in range(self.num_users)]
        self.cluster_idx = [None for _ in range(self.num_users)]
        self.label_assignments = [None for _ in range(self.num_users)]
        self.centers_prev = [None for _ in range(self.num_users)]
        self.criterion = nn.MSELoss()
        self.aligners =  MyServerModel(
            device=self.device,
            ref = self.ref,
            num_users=self.num_users,
            embed_dim=self.anchor_dim,
            top_k=self.top_k,
            temperature=self.attention_temperature,
            cluster_bias=self.cluster_bias
        ).to(self.device)


        self.optimizers_aligners = torch.optim.Adam(self.aligners.parameters(), lr=self.sv_lr)

        self.scheduler = StepLR(self.optimizers_aligners, step_size=self.sv_epochs, gamma=0.2)


    def get_full_X(self):
        for id in range(self.num_users):
            train_data_1 = self.data[id]
            dataloader_G_full = DataLoader(train_data_1, batch_size=self.data_size)
            X, y, _ = next(iter(dataloader_G_full))
            self.X_full.append(X.to(self.device))
    
    def contrastive_loss(self, reference_G, aligned_G):

        similarity_matrix_sample = torch.mm(reference_G, aligned_G.T) / self.temperature

        labels_sample = torch.arange(reference_G.size(0)).to(self.device)

        loss = F.cross_entropy(similarity_matrix_sample, labels_sample)

        loss = loss
        
        return loss
    def zscore(self, sig, eps=1e-8):
        mu = sig.mean(-1, keepdims=True)
        sd = sig.std(-1, keepdims=True) + eps
        return (sig - mu) / sd

    def _orthogonal_procrustes(self, X, Y):
        M = X.t() @ Y                        
        U, _, Vt = torch.linalg.svd(M, full_matrices=False)
        R = U @ Vt
        if torch.det(R) < 0:
            U[:, -1] = -U[:, -1]
            R = U @ Vt
        return R

    def _spherical_kmeans(self, G, id):
        Gn = F.normalize(G, dim=1).detach().cpu().numpy()
        if self.centers_prev[id] is not None:
            init_centers = self.centers_prev[id].cpu().numpy()  
            kmeans = KMeans(n_clusters=self.class_num, init=init_centers, n_init=1, random_state=10)
            labels = kmeans.fit_predict(Gn)
            centers = torch.from_numpy(kmeans.cluster_centers_).to(G.device, G.dtype)
            centers = F.normalize(centers, dim=1)

            return labels, centers
        kmeans = KMeans(n_clusters=self.class_num, random_state=10, n_init=10)
        labels = kmeans.fit_predict(Gn)
        centers = torch.from_numpy(kmeans.cluster_centers_).to(G.device, G.dtype)
        centers = F.normalize(centers, dim=1)

        return labels, centers


    def _cluster_confidence(self, G_norm, centers, labels):

        S = G_norm @ centers.t()
        max_sim = S[torch.arange(S.size(0)), torch.as_tensor(labels, device=S.device)]
        S2 = S.clone()
        S2[torch.arange(S.size(0)), torch.as_tensor(labels, device=S.device)] = -1e9
        second_sim = S2.max(dim=1).values
        return max_sim - second_sim
    
    def _pick_cluster_samples(self, G_norm, labels, centers, K, id, top_p=0.9, cap=1024):

        picked = []
        tag = []
        chosen = []
        chosen_selected = []
        truelabel = self.testlabel[id]
        conf = None
        if top_p < 1.0:
            conf = self._cluster_conf_cache = self._cluster_confidence(G_norm, centers, labels)
        for k in range(K):
            labels_tensor = torch.as_tensor(labels, device=G_norm.device)
            idx = torch.nonzero(labels_tensor == k, as_tuple=False).view(-1)

            chosen.append(idx)
            
            if idx.numel() == 0:
                picked.append(G_norm.new_zeros(0, G_norm.size(1)))
                continue
            if conf is not None:
                cvals = conf[idx]
                th = torch.quantile(cvals, 1.0 - top_p)
                mask = cvals >= th
                idx = idx[mask]
                if idx.numel() == 0:
                    idx = torch.nonzero(torch.as_tensor(labels)==k, as_tuple=False).view(-1)
            chosen_selected.append(idx)
            selected_sample = G_norm.index_select(0, idx)
            selected_label = truelabel[chosen[k].cpu().numpy()]
            tag.append(self.get_clusters_labels(selected_label))

            picked.append(selected_sample)

        self.cluster_idx[id] = chosen_selected
        return tag, picked, chosen
    def get_centers(self, G_list):
        if self.cluster_idx[0] is not None:

            for id in range(self.num_users):
                if id != -1:
                    G = G_list[id]
                    ctrs = []
                    for k in range(self.class_num):
                        idx = self.cluster_idx[id][k]
                        selected = G.index_select(0, idx)
                        mean = selected.mean(dim=0, keepdim=True)
                        ctrs.append(F.normalize(mean, dim=1))
                    self.centers_prev[id] = torch.cat(ctrs, dim=0)
            
    def get_clusters_labels(self, labels_in_cluster):
        majority_vote = stats.mode(labels_in_cluster, keepdims=False)[0]

        return majority_vote

    def compute_netlsd_from_features(self, Z, k=10, T=128):
        dist = pairwise_distances(Z)
        sigma = np.median(dist)

        W = np.exp(-(dist ** 2) / (2 * sigma ** 2))
        np.fill_diagonal(W, 0)
        idx = np.argsort(dist, axis=1)[:, 1:k+1]
        W_knn = np.zeros_like(W)
        for i in range(W.shape[0]):
            W_knn[i, idx[i]] = W[i, idx[i]]
        W = (W_knn + W_knn.T) / 2.0

        t_list = np.logspace(-3, 3, T)
        G = nx.from_numpy_array(W)
        sig = lsd.netlsd(G, timescales=t_list)
        return sig

    
    @torch.no_grad()
    def server_align_with_lsd(self, G_list, ref_idx=None,
                            cap_per_cluster=1024, top_p=0.8):

        K = self.class_num
        if ref_idx is None:
            ref_idx = int(self.ref)

        V = len(G_list)
        device = G_list[0].device
        dtype = G_list[0].dtype
        d = G_list[0].size(1)
        reftag = []
        testtag = []
        ref_s = [None for _ in range(K)]

        Gn_list = [F.normalize(G, dim=1) for G in G_list]


        labels_list, centers_list = [], []
        ii=0
        for G in Gn_list:    
            lbl, ctr = self._spherical_kmeans(G, ii)
            labels_list.append(lbl)
            self.label_assignments[ii] = torch.as_tensor(lbl, device=device)
            ii += 1
            centers_list.append(ctr)

        ref_centers = centers_list[ref_idx]

        ref_labels = labels_list[ref_idx]
        ref_G = Gn_list[ref_idx]
        reftag, ref_sets, _ = self._pick_cluster_samples(ref_G, ref_labels, ref_centers, K, self.ref,
                                        top_p=top_p, cap=cap_per_cluster)   
        lenbl = []
        for l in range(K):
            Bl = ref_sets[l]
            sl = self.compute_netlsd_from_features(Bl.detach().cpu().numpy(), k=10, T=250) 
            sl = self.zscore(torch.from_numpy(sl)).to(device, dtype)
            ref_s[l] = sl
            lenbl.append(Bl.size(0))
        
        out = {'views': {}, 'ref_idx': ref_idx}


        for v in range(V):
            if v == self.ref:
                out['views'][v] = {
                'labels': ref_labels,
                'centers': ref_centers,
                'pi': None,
                'R': None,
                'mu_ref_ordered': ref_centers,
                'cost_matrix': None,
                'chosen': None
                }
                continue
            centers_v = centers_list[v]
            labels_v = labels_list[v]
            Gv = Gn_list[v]
            testtag, sets_v, chosen = self._pick_cluster_samples(Gv, labels_v, centers_v, K, v,
                                        top_p=top_p, cap=cap_per_cluster)


            C = torch.zeros(K, K, device=device, dtype=dtype)
  
            for k in range(K):
                Ak = sets_v[k]
                sk = self.compute_netlsd_from_features(Ak.detach().cpu().numpy(), k=10, T=250)
                sk = self.zscore(torch.from_numpy(sk)).to(device, dtype)
                
                for l in range(K):

                    diff = sk - ref_s[l]
                    C[k, l] = torch.linalg.vector_norm(diff, ord=2)

            if self.C_list[v] is None:
                self.C_list[v] = C

            else:
                alpha = 0.001

                self.C_list[v] = (1-alpha) * self.C_list[v] + alpha * C

            C_np = self.C_list[v].detach().cpu().numpy()
            row_ind, col_ind = linear_sum_assignment(C_np)
            

            pi = torch.empty(K, dtype=torch.long, device=device)
            pi[row_ind] = torch.as_tensor(col_ind, dtype=torch.long, device=device)
            reftag_t = torch.as_tensor(reftag, device=device)

            testtag_t = torch.as_tensor(testtag, device=device)

            testreftag_t = reftag_t[pi]

            X = centers_v
            Y = ref_centers.index_select(0, pi)


            R = self._orthogonal_procrustes(X, Y)

            mu_ref_ordered = ref_centers.index_select(0, pi)
            out['views'][v] = {
                'labels': labels_v,
                'centers': centers_v,
                'pi': pi,
                'R': R,
                'mu_ref_ordered': mu_ref_ordered,
                'cost_matrix': C.detach().cpu().numpy(),
                'chosen': chosen
            }

        return out


    def update_rotation(self, R_prev, R_delta, beta=1):

        R_target = R_delta @ R_prev

        R_mix = (1 - beta) * R_prev + beta * R_target
        U, _, Vt = torch.linalg.svd(R_mix, full_matrices=False)
        R_new = U @ Vt

        if torch.det(R_new) < 0:
            U[:, -1] *= -1
            R_new = U @ Vt

        return R_new
    

    def chose_best(self, G_list):
        silhouette_scores = []
        for G in G_list:
            G_np = G.detach().cpu().numpy()
            kmeans = KMeans(n_clusters=self.class_num, random_state=10, n_init=10)
            pred_labels = kmeans.fit_predict(G_np)
            try:
                score = silhouette_score(G_np, pred_labels)
            except Exception:
                score = -1e9
            silhouette_scores.append(score)
        best_idx = int(np.argmax(silhouette_scores))
        return best_idx, silhouette_scores
    


    
    def get_label(self, reference_id): 
        temp = self.data[reference_id]
        dataloader_G_full = DataLoader(temp, batch_size=self.data_size)
        _, label, _ = next(iter(dataloader_G_full))
        label = label.cpu().numpy().squeeze()
        return label
    
    def label_fortest(self): 
        label = []
        for i in range(self.num_users):
            temp = self.data[i]
            dataloader_full = DataLoader(temp, batch_size=self.data_size)
            _, label_p, _ = next(iter(dataloader_full))
            label_p = label_p.cpu().numpy().squeeze()
            label.append(label_p)  
        return label

    def cluster_acc(self, y_true, y_pred):
        y_true = y_true.astype(np.int64)
        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        u = linear_sum_assignment(w.max() - w)
        ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
        return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size

    def purity(self, y_true, y_pred):
        y_voted_labels = np.zeros(y_true.shape)
        labels = np.unique(y_true)
        ordered_labels = np.arange(labels.shape[0])
        for k in range(labels.shape[0]):
            y_true[y_true == labels[k]] = ordered_labels[k]
        labels = np.unique(y_true)
        bins = np.concatenate((labels, [np.max(labels) + 1]), axis=0)

        for cluster in np.unique(y_pred):
            hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
            winner = np.argmax(hist)
            y_voted_labels[y_pred == cluster] = winner

        return accuracy_score(y_true, y_voted_labels)

    def evaluate(self, label, pred):
        nmi = v_measure_score(label, pred)
        ari = adjusted_rand_score(label, pred)
        acc = self.cluster_acc(label, pred)
        pur = self.purity(label, pred)
        return nmi, ari, acc, pur  
    def evaluate_clustering_test(self, epoch, true_labels, iteration=None, G_avg=None):


        G_avg_np = G_avg.detach().cpu().numpy()
        
        kmeans = KMeans(n_clusters=self.class_num, random_state=10, n_init=10)
        predicted_labels = kmeans.fit_predict(G_avg_np)


        nmi, ari, acc, pur = self.evaluate(true_labels, predicted_labels)
        


        return nmi, ari, acc, pur   
    def evaluate_clustering(self, epoch, true_labels, iteration=None, G_avg=None):

        G_avg_np = G_avg.detach().cpu().numpy()
        
        kmeans = KMeans(n_clusters=self.class_num, random_state=10, n_init=10)
        predicted_labels = kmeans.fit_predict(G_avg_np)

        nmi, ari, acc, pur = self.evaluate(true_labels, predicted_labels)

        #print(f" ACC: {acc:.4f}, NMI: {nmi:.4f}, ARI: {ari:.4f}, PUR: {pur:.4f}")

        return nmi, ari, acc, pur   
