import torch
import os
import numpy as np
from sklearn import cluster
import torch.nn as nn
from torch.utils.data import DataLoader
from model.models import MyLocalModel 
from users.usersbase import User
from torch.optim.lr_scheduler import CosineAnnealingLR
import torch.nn.functional as F

class UsersAvg(User):
    def __init__(self, id, device, anchor_num, train_data, dims, temperature,
                        view, data_size, class_num, pre_epochs, cl_epochs, cl_lr, d, cl_batch_size, lamda1, 
                        pre_lr):

        super().__init__(id, device, anchor_num, train_data, dims, temperature,
                        view, data_size, class_num, pre_epochs, cl_epochs, cl_lr, d, cl_batch_size, lamda1, 
                        pre_lr)


        self.G_final = None 

    def pretrain(self, pre_epochs , pre_lr):

        for param_group in self.optimizers.param_groups:
            param_group['lr'] = pre_lr
        for epoch in range(1, pre_epochs + 1):
            total_loss = 0.0
            
            for epoch_n in range(len(self.data_loader)):
                X, y, _ = self.get_next_train_batch()
                self.optimizers.zero_grad()
                xs_batch = X.to(self.device)
                X_recon, _, _, _= self.models(xs_batch)
                loss1_recon = self.criterion(X_recon, xs_batch)
                loss = loss1_recon

                loss.backward()
                
                self.optimizers.step()
                total_loss += loss.item()
        


            self.scheduler.step()

    def forserver(self):
        with torch.no_grad():
            full_data, _ = self.get_all_g()
            _, G, _, _ = self.models(full_data)

        return G
    

    def train(self, it, v, R, mu, chosen):


        if it != 0 and chosen is not None:
            assign_table = self.build_assign_table(chosen, self.data_size)
        model = self.models
        if it == 0:
            self.get_full_X()
            for param_group in self.optimizers.param_groups:
                param_group['lr'] = self.cl_lr



        loss_total = []


        optimizer = self.optimizers
        for epoch in range(1, self.cl_epochs + 1):
            
            
            total_epoch_loss = 0.0
            epoch_loss1 = 0.0
            epoch_loss2 = 0.0
            for epoch_n in range(len(self.data_loader)):
                optimizer.zero_grad()
                X, y, indices = self.get_next_train_batch()


                xs_batch = X.to(self.device)
                X_recon, G, _, Z = model(xs_batch)
                loss1_recon = self.criterion(X_recon, xs_batch)
                epoch_loss1 += loss1_recon.item()

                if it == 0 or R is None:

                    loss2_p = 0.0
                    epoch_loss2 = 0.0
                else:
                    G_c = G @ R
                    G_c = F.normalize(G_c, dim=1)
                    assign_table_batch = assign_table[indices.cpu()]
                    mu_target = mu[assign_table_batch]
                    loss2_p = F.mse_loss(G_c, mu_target)
 
                    epoch_loss2 += loss2_p.item()
 
                loss = loss1_recon  + self.lamda1 * loss2_p 
                
                loss.backward()
            
                optimizer.step()

         
            avg_loss1 = epoch_loss1 / len(self.data_loader)
            avg_loss2 = epoch_loss2 / len(self.data_loader)


            total_loss = avg_loss1 + self.lamda1 * avg_loss2 

            loss_total.append(total_loss)

            print(f"Epoch [{epoch}/{self.cl_epochs}], Loss: {total_loss:.6f}")
            
        
        with torch.no_grad():
            _, G_full, _, _ = model(self.X_full)

        if R is not None:
            G_full = G_full @ R
            G_full = F.normalize(G_full, dim=1)

        return G_full

