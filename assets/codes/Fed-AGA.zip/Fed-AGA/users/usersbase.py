import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import accuracy_score, silhouette_score, v_measure_score, adjusted_rand_score
from torch.utils.data import DataLoader
from model.models import MyLocalModel,  MLP
from sklearn import cluster
from torch.optim.lr_scheduler import CosineAnnealingLR
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

class User:
    def __init__(self, id, device, anchor_num, train_data, dims, temperature,
                    view, data_size, class_num, pre_epochs, cl_epochs, cl_lr, d, cl_batch_size, lamda1,
                    pre_lr):
        self.id = id
        self.device = device
        self.train_data = train_data
        self.anchor_num = anchor_num
        self.class_num = class_num
        self.dims = dims
        self.temperature = temperature
        self.view = view
        self.cl_epochs = cl_epochs
        self.data_size = data_size
        self.cl_lr = cl_lr
        self.d = d
        self.cl_batch_size = cl_batch_size
        self.pre_epochs = pre_epochs
        self.lamda1 = lamda1
        self.pre_lr = pre_lr
        self.acc = 0
        self.nmi = 0
        self.ari = 0
        self.pur = 0
        self.true_labels = None
        self.G_aligned = None
        self.neighbor = None 
        self.nu = 10
        self.ema = {}
        self.X_full = None
        self.criterion = nn.MSELoss()

        self.generator = torch.Generator().manual_seed(10)

        self.data_loader = DataLoader(train_data, batch_size=cl_batch_size)
        self.data_loader_g = DataLoader(train_data, batch_size=self.data_size)

        self.iter_data_loader = iter(self.data_loader)
        self.iter_data_loader_g = iter(self.data_loader_g)

        self.models = MyLocalModel(
                input_dim=self.dims, 
                anchor_num = self.anchor_num,
                d = d,
                output_dim=self.dims
            ).to(device) 


        self.optimizers = torch.optim.Adam(     
                self.models.parameters(), 
                lr=cl_lr,
                weight_decay=0
            )
        self.scheduler = CosineAnnealingLR(self.optimizers, T_max=self.pre_epochs, eta_min=self.pre_lr)
        
        

    def get_full_X(self):
        X, y, _ = next(iter(self.data_loader_g))
        self.X_full = X.to(self.device)
        self.X_full.detach()

    def chose_best(self, G):
        silhouette_scores = []
     
        G_np = G.detach().cpu().numpy()
        kmeans = cluster.KMeans(n_clusters=self.class_num, random_state=10, n_init=10)
        pred_labels = kmeans.fit_predict(G_np)
        try:
            score = silhouette_score(G_np, pred_labels)
        except Exception:
            score = -1e9
        silhouette_scores.append(score)
        return silhouette_scores
    
    def get_next_train_batch(self):
        try:
            
            (X, y, indices) = next(self.iter_data_loader)
        except StopIteration:
            
            self.iter_data_loader = iter(self.data_loader)
            (X, y, indices) = next(self.iter_data_loader)
        return (X.to(self.device), y.to(self.device), indices.to(self.device))
    
    def get_all_g(self):
        try:

            (X, y, _) = next(self.iter_data_loader_g)
        except StopIteration:

            self.iter_data_loader_g = iter(self.data_loader_g)
            (X, y, _) = next(self.iter_data_loader_g)
        return (X.to(self.device), y.to(self.device))
    
    def build_assign_table(self, chosen, N):
        assign_table = torch.full((N,), -1, dtype=torch.long)
        for k, indices in enumerate(chosen):
            assign_table[indices] = k
        return assign_table



    def cluster_acc(self, y_true, y_pred):
        y_true = y_true.astype(np.int64)
        assert y_pred.size == y_true.size
        D = max(y_pred.max(), y_true.max()) + 1
        w = np.zeros((D, D), dtype=np.int64)
        for i in range(y_pred.size):
            w[y_pred[i], y_true[i]] += 1
        u = linear_sum_assignment(w.max() - w)
        ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
        return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size


    def purity(self, y_true, y_pred):
        y_voted_labels = np.zeros(y_true.shape)
        labels = np.unique(y_true)
        ordered_labels = np.arange(labels.shape[0])
        for k in range(labels.shape[0]):
            y_true[y_true == labels[k]] = ordered_labels[k]
        labels = np.unique(y_true)
        bins = np.concatenate((labels, [np.max(labels) + 1]), axis=0)

        for cluster in np.unique(y_pred):
            hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
            winner = np.argmax(hist)
            y_voted_labels[y_pred == cluster] = winner

        return accuracy_score(y_true, y_voted_labels)

    def evaluate(self, label, pred):
        nmi = v_measure_score(label, pred)
        ari = adjusted_rand_score(label, pred)
        acc = self.cluster_acc(label, pred)
        pur = self.purity(label, pred)
        return nmi, ari, acc, pur  
    
    
    def evaluate_clustering(self, id, epoch, R=None, iteration=None):

        self.models.eval()
        
        with torch.no_grad():

            for _ in range(len(self.data_loader_g)):
                x, label = self.get_all_g()
                label = label.cpu().numpy().squeeze()
                x = x.to(self.device)
                _, G, _, _ = self.models(x)
            if R is not None:
                G = G @ R
                G = F.normalize(G, dim=1)
            G_eval = G.cpu().numpy()

            kmeans = cluster.KMeans(n_clusters=self.class_num, n_init=10, random_state=10)
            predicted_labels = kmeans.fit_predict(G_eval)

            nmi, ari, acc, pur = self.evaluate(label, predicted_labels)
            print(f"    [User{id}] Epoch {epoch} Evaluate - ACC: {acc:.4f}, NMI: {nmi:.4f}, ARI: {ari:.4f}, PUR: {pur:.4f}")

        self.models.train()

        #return acc, nmi, ari, pur
