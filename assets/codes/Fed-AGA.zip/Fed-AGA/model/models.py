import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.cluster import KMeans
import numpy as np

class Encoder(nn.Module):
    def __init__(self, input_dim, anchor_num):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, anchor_num),
        )

    def forward(self, x):   
        return self.encoder(x)


class Decoder(nn.Module):
    def __init__(self, d, output_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(d, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, output_dim)
        )

    def forward(self, x):
        return self.decoder(x)

import os
class MyLocalModel(nn.Module):
    def __init__(self, input_dim, anchor_num, output_dim, d):
        super(MyLocalModel, self).__init__()

        self.encoder = Encoder(input_dim, anchor_num)

        self.A = nn.Parameter(torch.randn(anchor_num, d))


        self.decoder = Decoder(d, output_dim)

    def forward(self, data):
        
        X = data
        G = self.encoder(X)
        G = F.normalize(G, p=2, dim=1)


        A = self.A
        Z = torch.matmul(G, A)
        X_recon = self.decoder(Z)
        
        return X_recon, G, A, Z
    


class MLP(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(MLP, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, 2000),
            nn.BatchNorm1d(2000),
            nn.ReLU(),
            nn.Linear(2000, output_dim)
        )

    def forward(self, x):
        return self.mlp(x)


class MyServerModel(nn.Module):
    def __init__(self, device, ref, num_users, embed_dim, num_heads=1, top_k=16, temperature=1, cluster_bias=1.0):
        super().__init__()
        self.device = device
        self.ref = ref
        self.num_users = num_users
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // max(1, num_heads)
        self.top_k = top_k
        self.temperature = temperature
        self.cluster_bias = cluster_bias
        self.to_q = nn.Linear(embed_dim, embed_dim)
        nn.init.eye_(self.to_q.weight)
        nn.init.zeros_(self.to_q.bias)
        self.to_kv = nn.ModuleList([MLP(embed_dim, embed_dim) for _ in range(num_users)])
        self.to_out = nn.ModuleList([MLP(embed_dim, embed_dim) for _ in range(num_users)])


    def forward(self, query, key, value, cluster_assignments=None, allow=False):
        device = self.device
        B = query.size(0)
        C = self.embed_dim
        output = [None] * self.num_users
        S_sparse = [None] * self.num_users
        output[self.ref] = self.to_out[self.ref](self.to_q(query))

        sqrt_C = C ** 0.5
        for i in range(self.num_users):
            if i == self.ref:
                continue
            q = self.to_q(query)
            k = self.to_kv[i](key[i])
            v = self.to_kv[i](value[i])
           
            qn = F.normalize(q, p=2, dim=1)
            kn = F.normalize(k, p=2, dim=1)

            sim = (qn @ kn.t()) / sqrt_C

            if cluster_assignments is not None and allow:
                q_clusters = cluster_assignments[self.ref]
                k_clusters = cluster_assignments[i]

                mask = (q_clusters.unsqueeze(1) == k_clusters.unsqueeze(0))

                sim = sim + self.cluster_bias * mask.float()

            k_eff = min(self.top_k, B)
            topv, topi = sim.topk(k_eff, dim=1)


            weights = F.softmax(topv / self.temperature, dim=1)

            row_idx = torch.arange(B, device=device).unsqueeze(1).expand(-1, k_eff).reshape(-1)
            col_idx = topi.reshape(-1)
            vals = weights.reshape(-1)
            S = torch.sparse_coo_tensor(
                torch.stack([row_idx, col_idx], dim=0),
                vals,
                size=(B, B),
                device=device
            ).coalesce()


            S_d = S.to_dense()
            aligned = torch.matmul(S_d, v)
            output[i] = self.to_out[i](aligned)

            S_sparse[i] = None

        return output

