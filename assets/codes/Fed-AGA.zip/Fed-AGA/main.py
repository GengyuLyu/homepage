import os
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
import torch
import numpy as np
from argparse import Namespace
import random
from data import dataloader
from users.usersavg import UsersAvg
from server.serveravg import ServerAvg
import inspect
import argparse
import gc
import logging
logger = logging.getLogger(__name__)
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
parser = argparse.ArgumentParser()

parser.add_argument('--iterations', type=int, default=10, help='Number of iterations for the optimization process')
parser.add_argument('--cl_epochs', type=int, default=4, help='Number of communication rounds')
parser.add_argument('--cl_batch_size', type=int, default=256, help='Batch size for local training')
parser.add_argument('--cl_lr', type=float, default=2e-4, help='Learning rate for local training')
parser.add_argument('--sv_epochs', type=int, default=5, help='Number of server epochs')
parser.add_argument('--sv_lr', type=float, default=1e-4, help='Learning rate for sever training')
parser.add_argument('--temperature', type=float, default=0.1, help='Temperature for contrastive loss')   
parser.add_argument('--pre_lr', type=float, default=3e-4, help='Learning rate for pre-training')
parser.add_argument('--pre_epochs', type=int, default=100, help='Number of pre-training epochs')
parser.add_argument('--k_anchor', type=int, default=2)
parser.add_argument('--d', type=int, default=20)
parser.add_argument('--lamda1', type=float, default=0.1)
parser.add_argument('--top_k', type=int, default=8, help='Top K for attention mechanism')
parser.add_argument('--attention_temperature', type=float, default=0.07, help='Temperature for attention mechanism')
parser.add_argument('--top_p', type=float, default=0.35, help='Top p for samples in graph') 
parser.add_argument('--cluster_bias', type=float, default=0.05, help='Bias for cluster in attention mechanism')
parser.add_argument('--dataset', type=str, default='Caltech7', choices=[
    "Scene", "Aloi","Hdigit","cifar10","Caltech7"], help='Dataset to use')
parser.add_argument('--gpu', type=int, default=0, help='GPU index to use')

args = parser.parse_args()
 

def main():

    print('ARGS:', ', '.join(f'{k}={v}' for k, v in vars(args).items()))
    seed = 10
    setup_seed(seed)

    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    #device = torch.device("cpu")
    data, dims, view, data_size, class_num = dataloader.load_data(args.dataset)

    anchor_num = args.k_anchor * class_num
    args.anchor_num = anchor_num


    for i in range(1):

        setup_seed(seed)
        server = ServerAvg( device=device, sample_dim=dims, data=data, data_size=data_size, iterations=args.iterations,
                        class_num=class_num, anchor_dim=anchor_num, num_views=view, pre_epochs=args.pre_epochs, top_k=args.top_k, attention_temperature=args.attention_temperature, top_p = args.top_p,
                        sv_lr=args.sv_lr, sv_epochs=args.sv_epochs, temperature=args.temperature, cluster_bias=args.cluster_bias,
                        cl_epochs=args.cl_epochs, cl_lr=args.cl_lr, d=args.d, cl_batch_size=args.cl_batch_size, lamda1=args.lamda1,
                        pre_lr=args.pre_lr)

        server.train()




if __name__ == "__main__":
    main()
