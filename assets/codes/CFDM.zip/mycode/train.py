import argparse
import os
import random
import shutil
import time
import warnings
import torch
import torch.nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torch.utils.data.distributed
import tensorboard_logger as tb_logger
import numpy as np

from network_goal_edit import Network
from model import CFDM
from utils.utils_algo import *
from loss_edit import partial_loss, MultiViewInterConLoss,MultiViewIntraConLoss,MultiViewConProtLoss
from bbcsport_partial import load_bbcsport_partial,load_data



parser = argparse.ArgumentParser(description='train')
parser.add_argument('--dataset', default='bbcsport')
parser.add_argument('--batch_size', default=128, type=int)

parser.add_argument('-j', '--workers', default=0, type=int,
                    help='number of data loading workers (default: 32)')
parser.add_argument('--epochs', default=100, type=int,
                    help='number of total epochs to run')

parser.add_argument("--feature_dim", default=512, type=int)
parser.add_argument("--high_feature_dim", default=256, type=int)
parser.add_argument('--start-epoch', default=0, type=int,
                    help='manual epoch number (useful on restarts)')
parser.add_argument('--lr', '--learning-rate', default=0.0005, type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('-lr_decay_epochs', type=str, default='80,90',
                    help='where to decay lr, can be a list')
parser.add_argument('-lr_decay_rate', type=float, default=0.1,
                    help='decay rate for learning rate')

parser.add_argument('--cosine', action='store_true', default=False,
                    help='use cosine lr schedule')

parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum of SGD solver')
parser.add_argument('--wd', '--weight-decay', default=1e-5, type=float,
                    metavar='W', help='weight decay (default: 1e-5)',
                    dest='weight_decay')

parser.add_argument('-p', '--print-freq', default=200, type=int,
                    help='print frequency (default: 200)')

parser.add_argument('--resume', default='', type=str,
                    help='path to latest checkpoint (default: none)')
parser.add_argument('--seed', default=42, type=int,
                    help='seed for initializing training. ')
parser.add_argument('--gpu', default='cuda:7', type=str,
                    help='GPU id to use.')
parser.add_argument('--proto_m', default=0.99, type=float,
                    help='momentum for computing the momving average of prototypes')

parser.add_argument('--loss_weight', default=0.01, type=float,
                    help='reconstruction loss weight')
parser.add_argument('--loss_weight1', default=0.1, type=float,
                    help='inter-view contrastive loss weight')
parser.add_argument('--loss_weight2', default=0.5, type=float,
                    help='intra-view contrastive loss weight')
parser.add_argument('--loss_weight3', default=0.5, type=float,
                    help='Prototype contrastive loss weight')

parser.add_argument('--conf_ema_range', default='0.95,0.8', type=str,
                    help='pseudo target updating coefficient (phi)')


# Mfeat.mat
parser.add_argument('--num_class', default=10, type=int,
                    help='number of class')
parser.add_argument('--num_views', default=6, type=int,
                    help='number of view')
parser.add_argument('--input_sizes', default=[216,76,64,6,240,47], type=int,
                    help='number of view')

args = parser.parse_args()
device = torch.device("cuda:7" if torch.cuda.is_available() else "cpu")
args.gpu = device


def main():
    args = parser.parse_args()
    args.conf_ema_range = [float(item) for item in args.conf_ema_range.split(',')] # '--conf_ema_range', default='0.95,0.8'
    iterations = args.lr_decay_epochs.split(',')
    args.lr_decay_epochs = list([])
    for it in iterations:
        args.lr_decay_epochs.append(int(it))
    print(args)

    if args.seed is not None:
        warnings.warn('You have chosen to seed training. '
                      'This will turn on the CUDNN deterministic setting, '
                      'which can slow down your training considerably! '
                      'You may see unexpected behavior when restarting '
                      'from checkpoints.')

    if args.gpu is not None:
        warnings.warn('You have chosen a specific GPU. This will completely '
                      'disable data parallelism.')

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print('device', device)

    ngpus_per_node = torch.cuda.device_count()
    main_worker(args.gpu, ngpus_per_node, args)


def main_worker(gpu, ngpus_per_node, args):
    cudnn.benchmark = True
    args.gpu = gpu
    if args.seed is not None:
        random.seed(args.seed)
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        cudnn.deterministic = True
    if args.gpu is not None:
        print("Use GPU: {} for training".format(args.gpu))


    if args.dataset == 'bbcsport':
        loaders, train_givenY = load_bbcsport_partial(batch_size=args.batch_size)
    else:
        raise NotImplementedError("You have chosen an unsupported dataset. Please check and try again.")
    # this train loader is the partial label training loader

    best_acc = 0
    mmc = 0 #mean max confidence
    fold_results = [] # Store the accuracy of each fold
    for fold, (train_loader, test_loader) in enumerate(loaders):
        print(f"Testing on fold {fold + 1}")

        # Reset model and optimizer at the beginning of each fold
        model = CFDM(args, Network).to(args.gpu)
        # optimizer = torch.optim.SGD(model.parameters(), args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
        optimizer = torch.optim.Adam(model.parameters(), args.lr,
                                     # momentum=args.momentum,
                                     weight_decay=args.weight_decay)
        best_acc_fold = 0  # Initialize the best accuracy of the current fold

        if not isinstance(train_givenY, torch.Tensor):
            train_givenY = torch.from_numpy(train_givenY)
        tempY = train_givenY.sum(dim=1).unsqueeze(1).repeat(1, train_givenY.shape[1])

        confidence = train_givenY.float() / tempY  # Calculate label confidence for each instance
        confidence = confidence.to(device)

        recon_criterion = torch.nn.MSELoss()

        loss_fn = partial_loss(confidence)
        loss_cont_inter = MultiViewInterConLoss()
        loss_cont_intra = MultiViewIntraConLoss()

        loss_cont_prot_fn = MultiViewConProtLoss()

        if args.gpu == 0:  # 检查当前 GPU 是否为主 GPU

            logger = tb_logger.Logger(logdir=os.path.join(args.exp_dir, 'tensorboard'), flush_secs=2)
        else:
            logger = None


        for epoch in range(args.start_epoch, args.epochs):
            is_best = False
            adjust_learning_rate(args, optimizer, epoch)

            # Training model
            train(train_loader, model, recon_criterion, loss_fn, loss_cont_inter, loss_cont_intra, loss_cont_prot_fn, optimizer, epoch, args, logger)
            loss_fn.set_conf_ema_m(epoch, args)

            # test model
            acc_test = test(model, test_loader, args, epoch, logger)
            mmc = loss_fn.confidence.max(dim=1)[0].mean()
            if acc_test > best_acc_fold:
                best_acc_fold = acc_test
        # Record the accuracy of each fold
        fold_results.append(best_acc_fold)
        print(f"Accuracy for fold {fold + 1}: {best_acc_fold}")

    average_accuracy = sum(fold_results) / len(fold_results)
    variance = sum((x - average_accuracy) ** 2 for x in fold_results) / (len(fold_results) - 1)
    std_dev_accuracy = variance ** 0.5
    print(f"Average Performance over 5 folds: {average_accuracy} + {std_dev_accuracy}" )


def train(train_loader, model, recon_criterion, loss_fn, loss_cont_fn, loss_cont_fn1, loss_cont_prot_fn, optimizer, epoch, args, tb_logger,
          ):
    batch_time = AverageMeter('Time', ':1.4f')
    data_time = AverageMeter('Data', ':1.4f')
    acc_cls = AverageMeter('Acc@Cls', ':2.4f')
    acc_proto = AverageMeter('Acc@Proto', ':2.4f')
    loss_cls_log = AverageMeter('Loss@Cls', ':2.4f')
    loss_cont_log = AverageMeter('Loss@Cont', ':2.4f')
    loss_cont1_log = AverageMeter('Loss@Cont', ':2.4f')
    loss_prot_log = AverageMeter('Loss@ContProt', ':2.4f')

    progress = ProgressMeter(
        len(train_loader),
        [batch_time, data_time, acc_cls, acc_proto, loss_cls_log, loss_cont_log, loss_prot_log],
        prefix="Epoch: [{}]".format(epoch))

    model.train()
    model.to(args.gpu)

    end = time.time()
    for i, (views, labels, true_labels, index) in enumerate(train_loader):
        # measure data loading time
        data_time.update(time.time() - end)
        views = [view.to(device) for view in views]

        Y, index = labels.to(device), index.to(device)
        Y_true = true_labels.long().detach().to(device)
        cls_out, features_cont, pseudo_target_cont, score_prot, avg_scores, prototypes_out, recon_list = model(views, Y, args)
        recon_loss = sum(
            recon_criterion(recon_view.float(), view.float()) for recon_view, view in zip(recon_list, views))

        batch_size = cls_out[0].shape[0]
        pseudo_target_cont = torch.cat(pseudo_target_cont, dim=0)

        loss_fn.confidence_update(temp_un_conf=avg_scores, batch_index=index, batchY=Y)
        loss_cls = loss_fn(cls_out, index)
        loss_cont = loss_cont_fn(features_cont=features_cont, pseudo_target_cont=pseudo_target_cont,
                                 batch_size=batch_size)

        loss_cont1 = loss_cont_fn1(features_cont=features_cont, pseudo_target_cont=pseudo_target_cont,
                                 batch_size=batch_size)

        loss_prot = loss_cont_prot_fn(prototypes_out=prototypes_out, batch_size=batch_size)
        loss =  loss_cls + args.loss_weight * recon_loss+ args.loss_weight1 * loss_cont + args.loss_weight2 * loss_cont1 + args.loss_weight3 * loss_prot
        loss_cls_log.update(loss_cls.item())
        loss_cont_log.update(loss_cont.item())
        loss_cont1_log.update(loss_cont.item())
        loss_prot_log.update(loss_prot.item())

        Y_true = torch.argmax(Y_true, dim=1)
        acc1 = accuracy(cls_out, Y_true)
        acc_cls.update(acc1)

        acc2 = accuracy(score_prot, Y_true)
        acc_proto.update(acc2)

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # measure elapsed time

        batch_time.update(time.time() - end)
        end = time.time()
        if i % args.print_freq == 0:
            progress.display(i)

    if args.gpu == 0:
        tb_logger.log_value('Train Acc', acc_cls.avg, epoch)
        tb_logger.log_value('Prototype Acc', acc_proto.avg, epoch)
        tb_logger.log_value('Classification Loss', loss_cls_log.avg, epoch)
        tb_logger.log_value('Contrastive Loss', loss_cont_log.avg, epoch)
        tb_logger.log_value('Contrastive Prototypes Loss', loss_prot_log.avg, epoch)

def test(model, test_loader, args, epoch, tb_logger):
    with torch.no_grad():
        print('==> Evaluation...')
        model.eval()
        model.to(args.gpu)
        top1_acc = AverageMeter("Top1")
        total_samples = 0

        for batch_idx, data in enumerate(test_loader):
            if len(data) != 4:
                raise ValueError(f"Expected a tuple of length 3, but got {len(data)}")
            views, _, labels , _ = data
            # print(labels)
            views = [view.to(device) for view in views]
            labels = labels.to(device)
            outputs = model(views, partial_Y=None, args=args, eval_only=True)
            labels = torch.argmax(labels, dim=1)
            acc1 = accuracy(outputs, labels)
            top1_acc.update(acc1, views[0].size(0))

        overall_accuracy = top1_acc.avg
        print(f'Overall Accuracy is {overall_accuracy:.4} (Top1)')
        if args.gpu == 0:
            tb_logger.log_value('Overall Top1 Acc', overall_accuracy, epoch)

    return overall_accuracy


def save_checkpoint(state, is_best, filename='checkpoint.pth.tar', best_file_name='model_best.pth.tar'):
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, best_file_name)

if __name__ == '__main__':
    main()