import torch.nn as nn
from torch.nn.functional import normalize
import torch
import numpy as np
import torch.nn.functional as F


class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )

    def forward(self, x):
        y = self.encoder(x)
        return y


class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )
    def forward(self, x):
        return self.decoder(x)


class Network(nn.Module):
    def __init__(self, batch_size, num_views, input_size, feature_dim, high_feature_dim, num_class, device):
        super(Network, self).__init__()
        self.encoders = []
        self.decoders = []
        self.batch_size = batch_size


        for v in range(num_views):
            self.encoders.append(Encoder(input_size[v], feature_dim).to(device))
            self.decoders.append(Decoder(input_size[v], feature_dim).to(device))


        self.encoders = nn.ModuleList(self.encoders)
        self.decoders = nn.ModuleList(self.decoders)

        #self.hs, self.tensors = Tensor(batch_size, view)
        # head == 'linear'
        # self.feature_contrastive_module = nn.Sequential(
        #     nn.Linear(feature_dim, high_feature_dim),
        # )
        # # head == 'mlp'
        self.feature_contrastive_module = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.ReLU(inplace=True),
            nn.Linear(feature_dim, high_feature_dim)
        )
        self.fc = nn.ModuleList([nn.Linear(feature_dim, num_class) for _ in range(num_views)])
        # Register a buffer to store class prototypes. This is initialized to a zero matrix
        self.register_buffer("prototypes", torch.zeros(num_class, high_feature_dim))
        self.num_views = num_views

    def forward(self, xs):
        outputs = []
        qs = []
        ds = []

        for v in range(self.num_views):
            x = xs[v]
            feat = self.encoders[v](x.float())
            feat_d = self.decoders[v](feat)
            feat_c = self.feature_contrastive_module(feat)
            logits = self.fc[v](feat)  # each view has a classifier
            feat_c = F.normalize(feat_c, dim=1)
            outputs.append(logits)
            qs.append(feat_c)
            ds.append(feat_d)
        return outputs, qs, ds

