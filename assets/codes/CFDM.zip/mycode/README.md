# CFDM
In this paper, we design a general MVPLL framework and propose a novel learning approach named CFDM, 
which explores the consistency and complementarity of multi-view data by multi-view contrastive fusion 
and reduces label ambiguity by multi-class contrastive prototype disambiguation.


This is a [PyTorch](http://pytorch.org) implementation of CFDM
run 'train.py' to train and valid the performance of CFDM
