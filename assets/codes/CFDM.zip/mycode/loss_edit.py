import torch
import torch.nn as nn
import math
import numpy as np
import torch.nn.functional as F

class partial_loss(nn.Module):
    def __init__(self, confidence, conf_ema_m=0.95):
        super().__init__()
        self.confidence = confidence
        self.init_conf = confidence.detach()
        self.conf_ema_m = conf_ema_m

    def set_conf_ema_m(self, epoch, args):
        start = args.conf_ema_range[0]
        end = args.conf_ema_range[1]
        self.conf_ema_m = 1. * epoch / args.epochs * (end - start) + start

    def forward(self, outputs_list, index):
        sum_logsm_outputs = 0
        for outputs in outputs_list:
            logsm_outputs = F.log_softmax(outputs, dim=1)
            sum_logsm_outputs += logsm_outputs
        mean_logsm_outputs = sum_logsm_outputs / len(outputs_list)  # Calculate average
        final_outputs = mean_logsm_outputs * self.confidence[index, :].to(mean_logsm_outputs.device)
        average_loss = -((final_outputs).sum(dim=1)).mean()

        return average_loss

    def confidence_update(self, temp_un_conf, batch_index, batchY):  # Update the confidence value based on the predicted pseudo-label
        with torch.no_grad():
            _, prot_pred = (temp_un_conf * batchY).max(dim=1)
            pseudo_label = F.one_hot(prot_pred, batchY.shape[1]).float().to(batchY.device).detach()
            self.confidence = self.confidence.to(batchY.device)
            self.confidence[batch_index, :] = self.conf_ema_m * self.confidence[batch_index, :] + (1 - self.conf_ema_m) * pseudo_label

class MultiViewInterConLoss(nn.Module):
    """Inter-view Contrastive Learning"""

    def __init__(self, temperature=0.07, base_temperature=0.07):
        super(MultiViewInterConLoss, self).__init__()
        self.temperature = temperature
        self.base_temperature = base_temperature

    def forward(self, features_cont, pseudo_target_cont, batch_size):
        device = features_cont[0].device
        num_views = len(features_cont)
        batch_size = features_cont[0].shape[0]
        loss = 0.0
        for v in range(num_views):
            for m in range(num_views):
                if v == m:
                    continue

                # Extract the features for view v and view m
                anchor_view = features_cont[v]  # Shape [M, feature_dim]
                contrast_view = features_cont[m]  # Shape [M, feature_dim]

                # Normalize features for cosine similarity calculation
                anchor_norm = F.normalize(anchor_view, p=2, dim=1)
                contrast_norm = F.normalize(contrast_view, p=2, dim=1)

                # Compute cosine similarity between same instances across views (positive pairs)
                positive_sim = torch.sum(anchor_norm * contrast_norm, dim=1)

                # Compute cosine similarity between different instances (negative pairs)
                all_sim = torch.mm(anchor_norm, contrast_norm.t())

                # Mask out positive pairs from all_sim matrix to only keep negative pairs
                indices = torch.arange(batch_size)
                all_sim[indices, indices] = float('-inf')

                # Compute softmax loss
                logits = torch.cat((positive_sim.unsqueeze(1), all_sim), dim=1) / self.temperature
                labels = torch.zeros(batch_size, dtype=torch.long).to(features_cont[0].device)

                # Contrastive loss
                view_loss = F.cross_entropy(logits, labels)
                loss += view_loss

        # Average the loss over all pairs of views
        loss /= (num_views * (num_views - 1))
        return loss

    def cosine_similarity(x, y):
        x = F.normalize(x, dim=-1)
        y = F.normalize(y, dim=-1)
        return torch.mm(x, y.T)

class MultiViewIntraConLoss(nn.Module):
    """Intra-view Contrastive Learning"""

    def __init__(self, temperature=0.07, base_temperature=0.07):
        super(MultiViewIntraConLoss, self).__init__()
        self.temperature = temperature
        self.base_temperature = base_temperature

    def forward(self, features_cont, pseudo_target_cont, batch_size):
        device = features_cont[0].device
        num_views = len(features_cont)
        batch_size = features_cont[0].shape[0]
        loss = 0.0
        for i in range(num_views):
            features_i = features_cont[i]
            pseudo_target_i = pseudo_target_cont[i].contiguous().view(-1, 1)

            features_i_normalized = F.normalize(features_i, dim=1)
            anchor_dot_contrast = torch.div(
                torch.matmul(features_i_normalized, features_i_normalized.T),
                self.temperature
            )

            logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
            logits = anchor_dot_contrast - logits_max.detach()
            logits_mask = torch.eye(batch_size).to(device)
            mask = pseudo_target_i == pseudo_target_i.T
            mask = mask * (1 - logits_mask)
            mask = mask.float().detach()

            exp_logits = torch.exp(logits) * mask
            log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True) + 1e-12)

            mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)

            loss_i = - mean_log_prob_pos
            loss_i = loss_i.mean()

            loss += loss_i
        loss /= num_views
        return loss

    def cosine_similarity(x, y):
        x = F.normalize(x, dim=-1)
        y = F.normalize(y, dim=-1)
        return torch.mm(x, y.T)




class MultiViewConProtLoss(nn.Module):
    """Prototype Contrastive Learning"""

    def __init__(self, temperature=0.07, base_temperature=0.07):
        super(MultiViewConProtLoss, self).__init__()
        self.temperature = temperature
        self.base_temperature = base_temperature

    def forward(self, prototypes_out,batch_size):
        """
        prototypes_out: List of prototype tensors for each view, each with shape [num_classes, feature_dim]
        """
        num_views = len(prototypes_out)
        num_classes = prototypes_out[0].size(0)
        loss = 0.0
        for v in range(num_views):
            for m in range(num_views):
                if v == m:
                    continue
                norm_prototypes_v = F.normalize(prototypes_out[v], p=2, dim=1)
                norm_prototypes_m = F.normalize(prototypes_out[m], p=2, dim=1)

                sim_matrix = torch.mm(norm_prototypes_v, norm_prototypes_m.t())

                sim_matrix /= self.temperature
                positive_samples = torch.diag(sim_matrix)
                mask = torch.ones_like(sim_matrix).fill_diagonal_(0)
                numerator = torch.exp(positive_samples)

                # Calculate the denominator: all negative samples from the current view and all samples from the other view
                denominator = (torch.sum(torch.exp(sim_matrix) * mask, dim=1) + torch.sum(torch.exp(sim_matrix),                                                                                         dim=1)) - numerator

                loss_vm = -torch.log(numerator / denominator).mean()
                loss += loss_vm
        loss /= (num_views * (num_views - 1))

        return loss




