import torch
import torch.nn as nn
import torch.nn.functional as F

class CFDM(nn.Module):

    def __init__(self, args, base_encoder):
        super().__init__()
        self.input_sizes = [args.input_sizes[v] for v in range(args.num_views)]
        self.device = args.gpu
        self.encoder_q = base_encoder(
            batch_size=args.batch_size,
            num_views=args.num_views,
            input_size=self.input_sizes,
            feature_dim=args.feature_dim,
            high_feature_dim=args.high_feature_dim,
            num_class=args.num_class,
            device=self.device
        )

        self.prototypes_list = nn.ParameterList([
            nn.Parameter(torch.zeros(args.num_class, args.high_feature_dim).to(self.device), requires_grad=False)
            for _ in range(args.num_views)
        ])

    def forward(self, xs, partial_Y=None, args=None, eval_only=False):
        device = self.device
        xs = [x.to(device) for x in xs]
        if partial_Y is not None:
            partial_Y = partial_Y.to(device)

        outputs_list, features_list, pseudo_labels_list, scores_prot_list, prototypes_list, recon_list = [], [], [], [], [], []
        outputs, qs, ds = self.encoder_q(xs)  # qs is a list of tensors

        if eval_only:
            return outputs

        for v, output in enumerate(outputs):  # Iterate over views
            output = output.to(device)
            outputs_list.append(output)
            q = qs[v].to(device)  # Get the corresponding q for the current view
            d = ds[v].to(device)

            if partial_Y is not None:
                predicted_scores = torch.softmax(output, dim=1) * partial_Y

                max_scores, pseudo_labels_b = torch.max(predicted_scores, dim=1)
                prototypes = self.prototypes_list[v].clone().detach().to(device)  # Get prototype buffer for the current view

                logits_prot = torch.mm(q, prototypes.t())
                score_prot = torch.softmax(logits_prot, dim=1)

                for i, (feat, label) in enumerate(zip(q, pseudo_labels_b)):
                    normalized_feat = F.normalize(feat, p=2, dim=0)
                    if label == torch.argmax(predicted_scores[i]):
                        self.prototypes_list[v][label] = args.proto_m * self.prototypes_list[v][label] + (
                                1 - args.proto_m) * normalized_feat
                        self.prototypes_list[v][label] = F.normalize(self.prototypes_list[v][label], p=2, dim=0)

                scores_prot_list.append(score_prot)
                features_list.append(q)
                pseudo_labels_list.append(pseudo_labels_b)
                prototypes_list.append(prototypes)
                recon_list.append(d)

        if len(scores_prot_list) > 0:
            avg_scores_prot = torch.mean(torch.stack(scores_prot_list), dim=0)
        else:
            avg_scores_prot = None

        return outputs_list, features_list, pseudo_labels_list, scores_prot_list, avg_scores_prot, prototypes_list, recon_list
