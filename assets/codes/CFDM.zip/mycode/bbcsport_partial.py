import numpy as np
import random

import scipy
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import Dataset, Subset, DataLoader
import torch
import h5py

import scipy.io as sio
from scipy.sparse import csc_matrix
from skmultilearn.dataset import load_dataset


def generate_partial_labels(label, instance_num, add_num, add_ratio):

    # class_num = label.shape[1]
    label_copy = label.copy().transpose()
    label_num = label_copy.sum()
    print(label_copy.shape)

    permit_add_label = 1 - label_copy
    add_matrix = np.random.uniform(0, 1, label_copy.shape)
    select_add_matrix = permit_add_label * add_matrix  # Pick the location of the noise label
    select_label = np.argsort(select_add_matrix, axis=0)[-add_num:, :]
    select_label = select_label * instance_num + np.array(list(range(instance_num)))

    select_instance_num = int(instance_num * add_ratio)  # The number of instances that need to be added with noise labels
    random_select_instance = np.random.uniform(0, 1, instance_num)
    non_select_instance = np.argsort(random_select_instance)[: instance_num - select_instance_num]

    select_label_remove = select_label.copy()
    select_label_remove[:, non_select_instance] = select_label[:, non_select_instance] * (-1)
    select_label_remove_vec = select_label_remove.reshape(-1)

    select_label_vec = select_label.reshape(-1).copy()
    select_label_add_vec = select_label_vec[np.where(select_label_remove_vec > 0)]

    label_copy_vec = label_copy.reshape(-1)
    label_copy_vec[select_label_add_vec] = 1
    label_copy = label_copy_vec.reshape(label_copy.shape)
    print("label_copy:",label_copy.sum())
    print(label_copy.sum() == label.sum() + add_num * select_instance_num)

    return label_copy


def load_data(path, dataset):

    filepath = path + dataset
    print(f"Loading data from: {filepath}")

    if dataset == 'Animal.mat':
        filepath = path + dataset
        print(f"Loading data from: {filepath}")

        print(path + dataset)
        mat = sio.loadmat(path + dataset)
        print('loadmat end')

        view = []
        print("Keys in mat:", mat.keys())
        label = mat['Y']

        flattened_data = np.array(label).flatten()
        num_classes = label.max()
        transformed_data = np.eye(num_classes)[np.array(flattened_data) - 1]
        # print(transformed_data)
        label = transformed_data.transpose()
        print("1")
        print(label)

        if mat['X'].shape[0] == 1:
            for i in range(mat['X'].shape[1]):
                view.append(mat['X'][0][i].astype(np.float64))
        elif mat['X'].shape[1] == 1:
            for i in range(mat['X'].shape[0]):
                view.append(mat['X'][i][0].astype(np.float64))
        else:
            print('View data type error!')
        for i in range(len(view)):
            view[i] = csc_matrix(view[i])
            view[i] = view[i].toarray()
            view[i] = torch.from_numpy(view[i])
        print('len_view:', len(view))
        for i in range(len(view)):
            print('i:{} shape:{}'.format(i, view[i].shape))
    elif dataset == 'ALOI_100.mat':
        print(path + dataset)
        mat = sio.loadmat(path + dataset)
        print('loadmat end')

        view = []
        print("Keys in mat:", mat.keys())
        # label = mat['Y']
        label = mat['gt']
        flattened_data = np.array(label).flatten()
        num_classes = label.max()
        transformed_data = np.eye(num_classes)[np.array(flattened_data) - 1]
        label = transformed_data.transpose()
        print("1")
        print(label)

        if mat['fea'].shape[0] == 1:
            for i in range(mat['fea'].shape[1]):
                view.append(mat['fea'][0][i].astype(np.float64))
        elif mat['fea'].shape[1] == 1:
            for i in range(mat['fea'].shape[0]):
                view.append(mat['fea'][i][0].astype(np.float64))
        else:
            print('View data type error!')
        for i in range(len(view)):
            view[i] = csc_matrix(view[i])
            view[i] = view[i].toarray()
            view[i] = torch.from_numpy(view[i])
        print('len_view:', len(view))
        for i in range(len(view)):
            print('i:{} shape:{}'.format(i, view[i].shape))
    else:
        with h5py.File(filepath, 'r') as file:
            print("Keys in file:", list(file.keys()))
            label = file['Y'][:]
            label = np.array(label).flatten()  #                                                                                                                                                                                                                                                                    展平标签数组
            label = label.astype(int)
            label -= label.min()
            num_classes = label.max() + 1

            transformed_data = np.eye(num_classes)[label]
            label = transformed_data.transpose()
            print("Label shape:", label.shape)
            print(label)

            # Read view data
            view = []
            for ref in file['X']:
                # Dereference the HDF5 reference
                data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
                data_array = np.array(data_ref).astype(np.float64).T
                tensor_data = torch.from_numpy(data_array)
                view.append(tensor_data)
                print(f"View shape: {tensor_data.shape}")


    print('len_view:', len(view))
    return view, label

class MultiViewDataset(Dataset):
    def __init__(self, views, given_label_matrix, true_labels):
        self.views = views
        self.given_label_matrix = given_label_matrix
        # user-defined label (partial labels)
        self.true_labels = true_labels

    def __len__(self):
        # Assuming all lists have the same length
        return len(self.true_labels[0])

    def __getitem__(self, index):
        views = [views[index] for views in self.views]
        labels = self.given_label_matrix[index]
        true_labels = self.true_labels[index]

        return views, labels, true_labels, index

def load_bbcsport_partial(batch_size):
    seed = 42
    np.random.seed(seed)
    random.seed(seed)


    dataPath = './data/'
    dataset = 'Mfeat.mat'
    X, label = load_data(dataPath, dataset)
    instance_num = X[0].shape[0]
    label = label.transpose()
    label = np.array(label, 'float32')
    partialY = generate_partial_labels(label, instance_num, add_num=1, add_ratio=0.3)
    partialY = partialY.transpose()

    partial_matrix_dataset = MultiViewDataset(X, partialY.astype(float), label.astype(float))

    # five-fold cross validation
    kf = KFold(n_splits=5, shuffle=True, random_state=seed)
    loaders = []

    for train_indices, test_indices in kf.split(X[0]):
        # Create training and test datasets
        train_dataset = Subset(partial_matrix_dataset, train_indices)
        test_dataset = Subset(partial_matrix_dataset, test_indices)

        # Create DataLoader
        train_loader = DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        test_loader = DataLoader(dataset=test_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

        loaders.append((train_loader, test_loader))

    return loaders, partialY

if __name__ == "__main__":

    dataPath = './data/'
    dataset = 'Mfeat.mat'
    load_bbcsport_partial(batch_size=64)

