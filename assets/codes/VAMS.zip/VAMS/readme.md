# VAMS
Codes of VAMS: Multi-View Multi-Label Classification via View-Label Matching Selection

Run the 'demo.py' file for traning. 

