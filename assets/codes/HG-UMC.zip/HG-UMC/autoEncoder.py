import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset


class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, 512),
            nn.ReLU(),
            nn.Linear(512, feature_dim),
        )

    def forward(self, x):
        return self.encoder(x)


class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )

    def forward(self, x):
        return self.decoder(x)


class ViewAutoEncoder(nn.Module):
    def __init__(self, view_dims, feature_dim, shared_dim=128):
        super().__init__()
        self.view_num = len(view_dims)
        self.encoders = nn.ModuleList([
            Encoder(input_dim=dim, feature_dim=feature_dim) for dim in view_dims
        ])

        self.decoders = nn.ModuleList([
            Decoder(input_dim=dim, feature_dim=feature_dim) for dim in view_dims
        ])

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        all_z = []
        all_recon = []
        for v in range(self.view_num):
            x_view = x[v]
            z = self.encoders[v](x_view)
            recon = self.decoders[v](z)
            all_z.append(z)
            all_recon.append(recon)
        return all_z, all_recon