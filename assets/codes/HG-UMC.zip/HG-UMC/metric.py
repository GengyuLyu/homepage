from sklearn.cluster import KMeans
from scipy.sparse.linalg import svds
from sklearn import cluster
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score, accuracy_score
from sklearn.cluster import KMeans
from scipy.optimize import linear_sum_assignment
from sklearn.preprocessing import normalize
from torch.utils.data import DataLoader
import numpy as np
import torch


def cluster_acc(y_true, y_pred):
    y_true = y_true.astype(np.int64)
    assert y_pred.size == y_true.size
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    u = linear_sum_assignment(w.max() - w)
    ind = np.concatenate([u[0].reshape(u[0].shape[0], 1), u[1].reshape([u[0].shape[0], 1])], axis=1)
    return sum([w[i, j] for i, j in ind]) * 1.0 / y_pred.size


def purity(y_true, y_pred):
    y_voted_labels = np.zeros(y_true.shape)
    labels = np.unique(y_true)
    ordered_labels = np.arange(labels.shape[0])
    for k in range(labels.shape[0]):
        y_true[y_true == labels[k]] = ordered_labels[k]
    labels = np.unique(y_true)
    bins = np.concatenate((labels, [np.max(labels)+1]), axis=0)

    for cluster in np.unique(y_pred):
        hist, _ = np.histogram(y_true[y_pred == cluster], bins=bins)
        winner = np.argmax(hist)
        y_voted_labels[y_pred == cluster] = winner

    return accuracy_score(y_true, y_voted_labels)


def evaluate(label, pred):
    nmi = normalized_mutual_info_score(label, pred)
    ari = adjusted_rand_score(label, pred)
    acc = cluster_acc(label, pred)
    pur = purity(label, pred)
    return nmi, ari, acc, pur


def align_rate(model, loader, max_view, view, data_size):
    ps = model.get_ps()
    labels_vector = []
    for v in range(view):
        labels_vector.append([])
    for step, (xs, y, _) in enumerate(loader):
        for v in range(view):
            if v != max_view:
                max_indices = torch.argmax(ps[v][step], dim=1)
                y[v] = y[v][max_indices]
            labels_vector[v].extend(y[v].numpy())
    for v in range(view):
        labels_vector[v] = np.array(labels_vector[v]).reshape(data_size)
    for v in range(view):
        print(v, "-", max_view,
              sum(labels_vector[v] == labels_vector[max_view]) / data_size)


def align_rate2(model, loader, max_view, view, data_size,
                class_num, batch_size, device):
    ps = model.get_ps()
    labels_vector = []
    sum = []
    single_class_num = int(batch_size / class_num)
    boundary_num = int(batch_size / 2)
    for v in range(view):
        labels_vector.append([])
        sum.append([])
    for v in range(view):
        sum[v] = 0
    for step, (xs, y, _) in enumerate(loader):
        for v in range(view):
            if v != max_view:
                _, indices = torch.topk(ps[v][step], boundary_num, dim=1)
                C = torch.index_select(y[v].to(device),
                                       0, indices.view(-1).to(device))
                C = C.view(-1, boundary_num)
                values, counts = torch.mode(C, dim=1)
                values = values.view(256, 1)
                sum_t = torch.where(
                    values.to(device) == y[max_view].to(device), 1, 0)
                sum[v] = sum[v] + sum_t.sum()
    print("baseline:", 1 / class_num)
    for v in range(view):
        if v != max_view:
            print(v, "-", max_view,
                  sum[v] / data_size)
        else:
            print(v, "-", max_view,
                  1.0)


def activate_and_normalize(tensor):
    tensor = torch.clamp(tensor, min=0)
    row_sums = tensor.sum(dim=1, keepdim=True)
    row_sums = row_sums + (row_sums == 0).float()
    tensor = tensor / row_sums
    return tensor


def inference(loader, model, class_num, ref_view_idx=0):
    model.eval()
    device = next(model.parameters()).device  # 从模型自动获取设备

    all_features = []
    all_labels = []

    with torch.no_grad():
        for xs, labels, _ in loader:
            xs = [x.to(device) for x in xs]
            labels = [y.to(device).long() for y in labels]

            (all_final_features,
             fused_features,
             diversity_loss,
             latent_features,
             all_A_matrices,
             matched_loss,
             all_He,
             reconstructions) = model.forward(xs, ref_view=ref_view_idx)

            all_features.append(fused_features.cpu())
            all_labels.append(labels[ref_view_idx].cpu())

    all_features = torch.cat(all_features, dim=0).numpy()
    all_labels = torch.cat(all_labels, dim=0).numpy().flatten()
    print("Performing K-Means clustering...")
    kmeans = KMeans(n_clusters=class_num, n_init=5, random_state=42)
    predictions = kmeans.fit_predict(all_features)

    return predictions, all_labels


def valid(loader, model, class_num, ref_view=0):
    predictions, true_labels = inference(loader, model, class_num, ref_view)
    print(f"Clustering results on {len(true_labels)} samples.")
    nmi, ari, acc, pur = evaluate(true_labels, predictions)
    print('ACC = {:.4f} NMI = {:.4f} ARI = {:.4f} PUR={:.4f}'.format(acc, nmi, ari, pur))

    return acc, nmi, pur, ari
