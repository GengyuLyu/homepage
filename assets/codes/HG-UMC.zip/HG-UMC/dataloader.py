from sklearn.preprocessing import MinMaxScaler, MaxAbsScaler
import numpy as np
from torch.utils.data import Dataset
import scipy.io
import torch
import h5py

class BDGP_handwritten(Dataset):
    def __init__(self, path):
        data = h5py.File(path)
        scaler = MinMaxScaler()

        self.view1 = scaler.fit_transform(np.array(data[data['X'][0][0]]).astype(np.float32).transpose())
        self.view2 = scaler.fit_transform(np.array(data[data['X'][1][0]]).astype(np.float32).transpose())
        self.view3 = scaler.fit_transform(np.array(data[data['X'][2][0]]).astype(np.float32).transpose())
        self.view4 = scaler.fit_transform(np.array(data[data['X'][3][0]]).astype(np.float32).transpose())
        self.view5 = scaler.fit_transform(np.array(data[data['X'][4][0]]).astype(np.float32).transpose())
        self.view6 = scaler.fit_transform(np.array(data[data['X'][5][0]]).astype(np.float32).transpose())

        self.views = []
        self.views.append(self.view1)
        self.views.append(self.view2)
        self.views.append(self.view3)
        self.views.append(self.view4)
        self.views.append(self.view5)
        self.views.append(self.view6)

        self.labels = np.array(data['Y']).T

    def __len__(self):
        return 2000

    def __getitem__(self, idx):
        return [torch.from_numpy(self.view1[idx]),
                torch.from_numpy(self.view2[idx]),
                torch.from_numpy(self.view3[idx]),
                torch.from_numpy(self.view4[idx]),
                torch.from_numpy(self.view5[idx]),
                torch.from_numpy(self.view6[idx])], \
                torch.from_numpy(self.labels[idx]), torch.from_numpy(
            np.array(idx)).long()

    def get_view(self, idx):
        if idx == -1:
            return self.labels
        else:
            return self.views[idx]


def load_data(dataset):
    if dataset == "handwritten":
        dataset = BDGP_handwritten('./data/handwritten.mat')
        dims = [240, 76, 216, 47, 64, 6]
        view = 6
        data_size = 2000
        class_num = 10
    else:
        raise NotImplementedError
    dataset = Form_Unaligned_Data(dataset, view, class_num)
    return dataset, dims, view, data_size, class_num


import random
def Form_Unaligned_Data(dataset, view, class_num):
    X = []
    Y = []
    for i in range(view):
        X.append(dataset.get_view(i))
        Y.append(dataset.get_view(-1))

    size = len(Y[0])
    view_num = len(X)
    t = np.linspace(0, size - 1, size, dtype=int)

    random.shuffle(t)
    Xtmp = []
    Ytmp = []
    for i in range(view_num):
        xtmp = np.copy(X[i])
        Xtmp.append(xtmp)
        ytmp = np.copy(Y[i])
        Ytmp.append(ytmp)

    for v in range(view_num):
        random.shuffle(t)
        Xtmp[v][:] = X[v][t]
        Ytmp[v][:] = Y[v][t]
    X = Xtmp
    Y = Ytmp

    result = GN_Dataset(X, Y, view)
    return result


class GN_Dataset(Dataset):
    def __init__(self, dataset, y, view_num):
        self.dataset = dataset
        self.labels = y
        self.view_num = view_num

    def __len__(self):
        return len(self.labels[0])

    def __getitem__(self, index):
        X = []
        Y = []
        for i in range(self.view_num):
            data_tensor = torch.from_numpy(self.dataset[i][index].astype(np.float32).transpose())
            label = self.labels[i][index]
            label_tensor = torch.tensor(label)
            X.append(data_tensor)
            Y.append(label_tensor)

        return X, Y, index
