import argparse

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.cluster import SpectralClustering
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import pairwise_distances_argmin_min
from torch import nn, optim
from torch.utils.data import DataLoader

import dataloader
from model import HyperedgeGenerator, Network
from autoEncoder import ViewAutoEncoder
from metric import valid
from util import setup_seed

torch.set_printoptions(sci_mode=False, precision=4)


def parse_args():
    parser = argparse.ArgumentParser(description='Train HGNN Model')
    parser.add_argument('--dataset', default='handwritten', type=str)
    parser.add_argument('--batch_size', default=1024, type=int)
    parser.add_argument('--epochs', default=160, type=int)
    parser.add_argument('--autoEncoder_epochs', default=800, type=int)
    parser.add_argument('--learning_rate', default=0.003, type=float)
    parser.add_argument('--autoEncoder_learning_rate', default=0.001, type=float)
    parser.add_argument('--weight_decay', default=5e-4, type=float)
    parser.add_argument('--seed', default=64, type=int)
    parser.add_argument('--prototypes_per_class', default=3, type=int)
    parser.add_argument('--shared_embed_dim', default=10, type=int, help='Dimension of the shared latent space')
    parser.add_argument('--lambda_recon', default=1, type=float, help='Weight for the recon loss')
    parser.add_argument('--lambda_modeling', default=10, type=float, help='Weight for the modeling loss')
    parser.add_argument('--lambda_fusion', default=300, type=float, help='Weight for the fusion loss')
    parser.add_argument(
        '--device',
        default='auto',
        type=str,
        help="Device to use: auto, cpu, cuda, cuda:0, cuda:1, etc."
    )
    return parser.parse_args()


def resolve_device(device_arg):
    if device_arg == 'auto':
        return torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    device = torch.device(device_arg)
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError(f"Requested device '{device_arg}', but CUDA is not available.")
    return device


def train_autoencoder(autoEncoder, data_loader, optimizer, epochs, view, device):
    print('\n--- Training Auto-Encoder ---')
    recon_loss_fn = nn.MSELoss()

    for epoch in range(epochs):
        autoEncoder.train()
        total_recon_loss = 0.0
        num_batches = 0

        for X, _, _ in data_loader:
            optimizer.zero_grad()
            X = [x.to(device) for x in X]
            _, reconstructions = autoEncoder(X)
            loss_recon = [recon_loss_fn(reconstructions[v], X[v]) for v in range(view)]
            loss = 10 * sum(loss_recon)

            loss.backward()
            optimizer.step()

            total_recon_loss += sum(loss_recon).item()
            num_batches += 1

        epoch_recon_loss = total_recon_loss / num_batches
        if (epoch + 1) % 25 == 0:
            print(f'Epoch {epoch + 1}: Recon Loss: {10 * epoch_recon_loss:.4f}')


def init_prototypes_with_spectral(init_Z, class_num, affiliation_map, device):
    print('Using Spectral Clustering for initialization...')
    spectral = SpectralClustering(
        n_clusters=class_num,
        affinity='nearest_neighbors',
        random_state=42
    )

    all_anchors = []
    all_prototypes = []

    for v in range(len(init_Z)):
        features_np = init_Z[v].cpu().detach().numpy()
        labels = spectral.fit_predict(features_np)
        centers_np = np.zeros((class_num, features_np.shape[1]))
        for c in range(class_num):
            cluster_points = features_np[labels == c]
            if len(cluster_points) > 0:
                centers_np[c] = cluster_points.mean(axis=0)
            else:
                centers_np[c] = features_np[np.random.choice(len(features_np))]
        closest_indices, _ = pairwise_distances_argmin_min(centers_np, features_np)
        anchors_np = features_np[closest_indices].astype(np.float32)
        anchors_v = torch.from_numpy(anchors_np).to(device)
        all_anchors.append(anchors_v)
        prototypes_v = anchors_v[affiliation_map]
        noise = torch.randn_like(prototypes_v) * 0.001
        prototypes_v = prototypes_v + noise
        all_prototypes.append(prototypes_v)

    all_anchors_stacked = torch.stack(all_anchors, dim=0).to(device)
    all_prototypes_stacked = torch.stack(all_prototypes, dim=0).to(device)
    return all_anchors_stacked, all_prototypes_stacked

def compute_cross_view_cluster_matches(model, data_loader, view, ref_view_idx, device):
    was_training = model.training
    current_fixed_matches = getattr(model, 'fixed_cluster_matches', None)
    model.clear_fixed_cluster_matches()
    model.eval()

    try:
        X, _, _ = next(iter(data_loader))
        X = [x.to(device) for x in X]

        with torch.no_grad():
            (_, _, _, _, all_A_matrices, _, all_He, _) = model(X, ref_view_idx)

        aff_map = model.hgnn_layers[0][0].affiliation_map
        A_meta = F.one_hot(aff_map, num_classes=model.class_num).float().to(device)
        ref_skeleton_fp = model.skeleton_fingerprint_gen(all_He[ref_view_idx].detach())

        matches = {}
        for v in range(view):
            if v == ref_view_idx:
                continue

            active_skeleton_fp = model.skeleton_fingerprint_gen(all_He[v])
            cost_matrix = torch.norm(
                active_skeleton_fp.unsqueeze(1) - ref_skeleton_fp.unsqueeze(0),
                p=2,
                dim=2
            )
            row_ind, col_ind = linear_sum_assignment(cost_matrix.detach().cpu().numpy())
            matches[v] = (row_ind, col_ind)

        return matches
    finally:
        if current_fixed_matches is not None:
            model.set_fixed_cluster_matches(current_fixed_matches)
        if was_training:
            model.train()


def freeze_cross_view_cluster_matches(model, data_loader, epoch, view, ref_view_idx, device):
    matches = compute_cross_view_cluster_matches(model, data_loader, view, ref_view_idx, device)
    model.set_fixed_cluster_matches(matches)
    print(f'Locked cross-view cluster matches at epoch {epoch + 1}.')
    for v, (row_ind, col_ind) in matches.items():
        pairs = '; '.join(f'{int(a)}->{int(r)}' for a, r in zip(row_ind, col_ind))
        print(f'  view {v}: {pairs}')


def report_cross_view_cluster_matches(model, data_loader, epoch, args, view, ref_view_idx, device):
    if view < 2:
        return

    was_training = model.training
    model.eval()

    try:
        X, _, _ = next(iter(data_loader))
        X = [x.to(device) for x in X]

        with torch.no_grad():
            (all_final_features,
             _,
             _,
             _,
             all_A_matrices,
             _,
             all_He,
             _) = model(X, ref_view_idx)

        aff_map = model.hgnn_layers[0][0].affiliation_map
        A_meta = F.one_hot(aff_map, num_classes=args.class_num).float().to(device)

        A_ref_c = torch.matmul(all_A_matrices[ref_view_idx].detach(), A_meta)
        ref_cluster_ids = torch.argmax(A_ref_c, dim=1)
        ref_skeleton_fp = model.skeleton_fingerprint_gen(all_He[ref_view_idx].detach())
        X_ref = all_final_features[ref_view_idx].detach()

        print()
        print(f'Cluster matches at epoch {epoch + 1} (ref view {ref_view_idx})')
        for v in range(view):
            if v == ref_view_idx:
                continue

            A_v_c = torch.matmul(all_A_matrices[v], A_meta)
            active_cluster_ids = torch.argmax(A_v_c, dim=1)
            active_skeleton_fp = model.skeleton_fingerprint_gen(all_He[v])
            cost_matrix = torch.norm(
                active_skeleton_fp.unsqueeze(1) - ref_skeleton_fp.unsqueeze(0),
                p=2,
                dim=2
            )
            row_ind, col_ind = linear_sum_assignment(cost_matrix.detach().cpu().numpy())

            pairs = []
            for active_c, ref_c in zip(row_ind, col_ind):
                active_c = int(active_c)
                ref_c = int(ref_c)
                active_mask = (active_cluster_ids == active_c)
                ref_mask = (ref_cluster_ids == ref_c)
                topology_distance = float(cost_matrix[active_c, ref_c].detach().cpu())

                if active_mask.sum() > 0 and ref_mask.sum() > 0:
                    active_center = all_final_features[v][active_mask].mean(dim=0)
                    ref_center = X_ref[ref_mask].mean(dim=0)
                    feature_center_l2 = float(torch.norm(active_center - ref_center, p=2).detach().cpu())
                else:
                    feature_center_l2 = float('nan')

                pairs.append(
                    f'{active_c}->{ref_c} '
                    f'(topo={topology_distance:.4f}, center={feature_center_l2:.4f})'
                )

            print(f'  view {v}: ' + '; '.join(pairs))
    finally:
        if was_training:
            model.train()


def train_main_model(model, data_loader, optimizer, epochs, args, view, ref_view_idx, device):
    print('\n--- Start Training Model ---')
    recon_loss_fn = nn.MSELoss()

    for epoch in range(epochs):
        model.train()

        epoch_loss = 0.0
        epoch_loss_modeling = 0.0
        epoch_loss_fusion = 0.0
        epoch_loss_recon = 0.0
        num_batches = 0

        for X, labels, _ in data_loader:
            optimizer.zero_grad()
            X = [x.to(device) for x in X]
            labels = [y.to(device).long() for y in labels]
            (_, _, loss_modeling, _, _, loss_fusion, _, reconstructions) = model(X, ref_view_idx)
            loss_recon = sum(recon_loss_fn(reconstructions[v], X[v]) for v in range(view))
            batch_loss = (args.lambda_fusion * loss_fusion +
                          args.lambda_modeling * loss_modeling +
                          args.lambda_recon * loss_recon)
            batch_loss.backward()
            optimizer.step()
            epoch_loss += batch_loss.item()
            epoch_loss_modeling += loss_modeling.item()
            epoch_loss_fusion += loss_fusion.item()
            epoch_loss_recon += loss_recon.item()
            num_batches += 1
        avg_loss = epoch_loss / num_batches
        avg_loss_modeling = epoch_loss_modeling / num_batches
        avg_loss_fusion = epoch_loss_fusion / num_batches
        avg_loss_recon = epoch_loss_recon / num_batches

        print(f'Epoch [{epoch + 1}/{epochs}] | '
              f'Total Loss: {avg_loss:.4f} | '
              f'loss_recon: {args.lambda_recon * avg_loss_recon:.4f} | '
              f'loss_modeling: {args.lambda_modeling * avg_loss_modeling:.4f} | '
              f'loss_fusion: {args.lambda_fusion * avg_loss_fusion:.4f}')

        if (epoch + 1) % 20 == 0 or epoch == 0:
            print(f'\n--- Validating model at Epoch {epoch + 1} ---')
            model.eval()
            valid(
                loader=data_loader,
                model=model,
                class_num=args.class_num,
                ref_view=ref_view_idx
            )
            if epoch + 1 == 10 and getattr(model, 'fixed_cluster_matches', None) is None:
                freeze_cross_view_cluster_matches(
                    model=model,
                    data_loader=data_loader,
                    epoch=epoch,
                    view=view,
                    ref_view_idx=ref_view_idx,
                    device=device
                )
            model.train()
            print('=' * 75 + '\n')

    print('--- Training Finished ---')


def main():
    args = parse_args()
    setup_seed(args.seed)
    device = resolve_device(args.device)
    print(f'Using device: {device}')
    dataset, dims, view, data_size, class_num = dataloader.load_data(args.dataset)
    args.class_num = class_num
    print(f"Dataset '{args.dataset}' loaded with {view} views. Dimensions: {dims}.")
    generator = torch.Generator().manual_seed(args.seed)
    data_loader = DataLoader(
        dataset,
        batch_size=data_size,
        shuffle=False,
        generator=generator,
        drop_last=True
    )
    print(f'DataLoader created. Batch Size: {args.batch_size}, Batches per Epoch: {len(data_loader)}')
    num_hyperedges = class_num * args.prototypes_per_class
    affiliation_map = torch.arange(num_hyperedges, device=device) // args.prototypes_per_class
    print(f'Number of hyperedges for each view: {num_hyperedges}')

    autoEncoder = ViewAutoEncoder(view_dims=dims, feature_dim=args.shared_embed_dim).to(device)
    optimizer_autoEncoder = optim.AdamW(
        autoEncoder.parameters(),
        lr=args.autoEncoder_learning_rate,
        weight_decay=args.weight_decay
    )
    ref_view_idx = int(np.argmax(dims))
    weights_path = f'{args.dataset}_autoEncoder_weights.pth'
    train_autoencoder(
        autoEncoder=autoEncoder,
        data_loader=data_loader,
        optimizer=optimizer_autoEncoder,
        epochs=args.autoEncoder_epochs,
        view=view,
        device=device
    )
    torch.save(autoEncoder.state_dict(), weights_path)
    print(f'Ref View is {ref_view_idx}')
    try:
        init_X, init_labels, _ = next(iter(data_loader))
    except StopIteration:
        generator = torch.Generator().manual_seed(args.seed)
        temp_loader = DataLoader(
            dataset,
            batch_size=args.batch_size,
            shuffle=False,
            generator=generator,
            drop_last=True
        )
        init_X, init_labels, _ = next(iter(temp_loader))

    init_X = [x.to(device) for x in init_X]
    init_labels = [l.to(device).long() for l in init_labels]

    with torch.no_grad():
        init_Z, _ = autoEncoder(init_X)
        init_Z = [F.normalize(z, p=2, dim=1) for z in init_Z]

    _, all_prototypes_stacked = init_prototypes_with_spectral(
        init_Z=init_Z,
        class_num=class_num,
        affiliation_map=affiliation_map,
        device=device
    )

    model = Network(
        view_dims=dims,
        class_num=class_num,
        hyperedges_num=num_hyperedges,
        centres=all_prototypes_stacked,
        affiliation_map=affiliation_map,
        shared_embed_dim=args.shared_embed_dim,
        autoEncoder=autoEncoder
    ).to(device)
    autoEncoder.to(device)
    ae_params = model.autoEncoder.parameters()
    base_model_params = [
        param for name, param in model.named_parameters()
        if not name.startswith('autoEncoder.')
    ]
    optimizer_model = optim.Adam([
        {'params': base_model_params, 'lr': args.learning_rate, 'weight_decay': args.weight_decay},
        {'params': ae_params, 'lr': args.learning_rate / 10, 'weight_decay': args.weight_decay}
    ])

    train_main_model(
        model=model,
        data_loader=data_loader,
        optimizer=optimizer_model,
        epochs=args.epochs,
        args=args,
        view=view,
        ref_view_idx=ref_view_idx,
        device=device
    )


if __name__ == '__main__':
    main()
