import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
from torch.nn import GELU
from autoEncoder import ViewAutoEncoder


def sinkhorn_normalize(log_alpha, n_iters=20):
    for _ in range(n_iters):
        log_alpha = log_alpha - torch.logsumexp(log_alpha, dim=1, keepdim=True)
        log_alpha = log_alpha - torch.logsumexp(log_alpha, dim=0, keepdim=True)
    return torch.exp(log_alpha)


def cal_modeling_loss(prototypes, target_centers):
    if target_centers is None:
        return torch.tensor(0.0, device=prototypes.device)

    prototypes_norm = F.normalize(prototypes, p=2, dim=1)
    target_norm = F.normalize(target_centers.detach(), p=2, dim=1)
    valid_mask = (target_centers.norm(p=2, dim=1) > 1e-6).float().unsqueeze(1)
    traction_dist_sq = (prototypes_norm - target_norm).pow(2).sum(dim=1, keepdim=True)
    loss = (traction_dist_sq * valid_mask).sum() / (valid_mask.sum() + 1e-9)
    return loss


class SkeletonFingerprintGenerator(nn.Module):

    def __init__(self, affiliation_map, class_num):
        super().__init__()
        self.register_buffer('affiliation_map', affiliation_map)
        self.class_num = class_num

    def forward(self, He):
        fingerprints = []
        for c in range(self.class_num):
            mask = (self.affiliation_map == c)
            skeleton_vectors = He[mask]
            skeleton_vectors = F.normalize(skeleton_vectors, p=2, dim=1)
            gram_matrix = torch.matmul(skeleton_vectors, skeleton_vectors.t())
            eig_vals = torch.linalg.eigvalsh(gram_matrix)
            fingerprints.append(eig_vals)

        fingerprints_matrix = torch.stack(fingerprints, dim=0)
        return fingerprints_matrix


class HyperedgeGenerator(nn.Module):

    def __init__(self, hyperedges_num, embed_dim, centre, use_cosine=True, temp=0.1, use_gumbel=False, eps=1e-6):
        super().__init__()
        assert isinstance(hyperedges_num, int) and hyperedges_num > 0
        assert isinstance(embed_dim, int) and embed_dim > 0
        self.k = hyperedges_num
        self.d = embed_dim
        self.use_cosine = use_cosine
        self.temp = float(temp)
        self.use_gumbel = use_gumbel
        self.eps = eps
        self.prototypes = nn.Parameter(centre)

    def get_prototypes(self):
        return self.prototypes

    def _compute_logits(self, X):
        P = self.prototypes
        if self.use_cosine:
            Xn = F.normalize(X, p=2, dim=-1, eps=self.eps)
            Pn = F.normalize(P, p=2, dim=1, eps=self.eps)
            logits = torch.einsum('...d,kd->...k', Xn, Pn)
        else:
            logits = torch.einsum('...d,kd->...k', X, P)
        return logits

    def forward(self, X):
        n, d_in = X.shape
        if d_in != self.d:
            raise ValueError(f"Input dim {d_in} != expected {self.d}")

        logits = self._compute_logits(X)

        if self.use_gumbel and self.training:
            A_soft = F.gumbel_softmax(logits, tau=self.temp, hard=False, dim=-1)
        else:
            A_soft = F.softmax(logits / self.temp, dim=-1)

        return A_soft, logits


class NodeProjection(nn.Module):

    def __init__(self, embed_dim, expansion=8):
        super().__init__()
        hidden_dim = embed_dim * expansion
        self.pre_norm = nn.LayerNorm(embed_dim)
        self.net = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            GELU(),
            nn.Linear(hidden_dim, embed_dim),
        )
        self.out_norm = nn.LayerNorm(embed_dim)
        self.res_scale = nn.Parameter(torch.tensor(0.1))
        self.reset_parameters()

    def reset_parameters(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.LayerNorm):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

        with torch.no_grad():
            self.res_scale.fill_(0.1)

    def forward(self, X):
        return self.out_norm(X + self.res_scale * self.net(self.pre_norm(X)))


class HGConv(nn.Module):

    def __init__(self, embed_dim, num_hyperedges, centre, class_num,
                shared_edge_mlp, affiliation_map, beta=0.8):
        super().__init__()
        self.c = class_num
        self.k = num_hyperedges
        self.edge_generator = HyperedgeGenerator(num_hyperedges, embed_dim, centre)
        self.shared_edge_mlp = shared_edge_mlp
        self.beta = beta

        self.node_proj = NodeProjection(embed_dim)

        self.top_k = 1
        self.register_buffer('affiliation_map', affiliation_map.clone())

    def get_prototypes(self):
        return self.edge_generator.get_prototypes()

    def get_cluster_assignments(self):
        indices = torch.argmax(self.A_cluster_logits, dim=1)
        return indices

    def forward(self, X):
        A_soft, logits = self.edge_generator(X)
        A = A_soft

        if self.top_k is not None and self.top_k < A_soft.size(-1):
            topk_vals, topk_idx = torch.topk(A_soft, k=self.top_k, dim=-1)
            mask = torch.zeros_like(A_soft)
            mask.scatter_(-1, topk_idx, 1.0)
            A = A_soft * mask
            A = A / (A.sum(dim=-1, keepdim=True) + 1e-9)

        d_v = A.sum(dim=1).clamp_min(1e-9).pow(-0.5)
        d_e = A.sum(dim=0).clamp_min(1e-9).pow(-1)
        X_norm = X * d_v.unsqueeze(1)
        He = torch.mm(A.transpose(0, 1), X_norm) * d_e.unsqueeze(1)

        loss_modeling = cal_modeling_loss(self.edge_generator.prototypes, He)

        He_proj = F.normalize(He, p=2, dim=1)
        # sim_matrix = torch.matmul(He_norm, He_norm.t())
        # attn_weights = F.softmax(sim_matrix, dim=-1)
        # context = torch.matmul(attn_weights, He)

        # mlp_input = torch.cat([He, context], dim=1)
        # He_proj = self.shared_edge_mlp(mlp_input)

        A_meta = F.one_hot(self.affiliation_map, num_classes=self.c).float()
        group_counts = A_meta.sum(dim=0).clamp_min(1e-9)
        group_sums = torch.mm(He_proj.t(), A_meta)
        C_k_dynamic = (group_sums / group_counts).t()
        mean_broadcast = torch.mm(A_meta, C_k_dynamic)
        He_proj_target_centroids = self.beta * mean_broadcast + (1 - self.beta) * He_proj
        X_new = torch.mm(A, He_proj_target_centroids)
        X_new = X_new * d_v.unsqueeze(1)
        X_new = self.node_proj(X_new)
        X_new = 1 * X_new + 0.1 * X
        X_new = F.normalize(X_new, p=2, dim=1)
        He_match_sum = torch.mm(A.transpose(0, 1), X_new)
        He_match = F.normalize(He_match_sum, p=2, dim=1)

        return X_new, A, He_match, loss_modeling, C_k_dynamic


class Network(nn.Module):

    def __init__(self, view_dims, class_num, hyperedges_num, centres, autoEncoder: ViewAutoEncoder,
                 affiliation_map, shared_embed_dim=32, num_hgnn_layers=1):
        super().__init__()
        self.view_dims = view_dims
        self.class_num = class_num
        self.num_views = len(view_dims)
        self.shared_embed_dim = shared_embed_dim
        self.hyperedges_num = hyperedges_num
        self.top_k = 7
        self.lambda_struct = 0.0001

        self.autoEncoder = autoEncoder

        self.shared_edge_mlp = nn.Sequential(
            nn.Linear(self.shared_embed_dim * 2, self.shared_embed_dim * 4),
            nn.ReLU(),
            nn.Linear(self.shared_embed_dim * 4, self.shared_embed_dim),
            nn.LayerNorm(self.shared_embed_dim)
        )

        self.hgnn_layers = nn.ModuleList([
            nn.ModuleList([
                HGConv(
                    embed_dim=self.shared_embed_dim,
                    class_num=class_num,
                    num_hyperedges=hyperedges_num,
                    centre=centres[v],
                    affiliation_map=affiliation_map,
                    shared_edge_mlp=self.shared_edge_mlp
                )
                for _ in range(num_hgnn_layers)
            ])
            for v in range(self.num_views)
        ])

        self.skeleton_fingerprint_gen = SkeletonFingerprintGenerator(
            affiliation_map=affiliation_map,
            class_num=class_num
        )
        self.fixed_cluster_matches = None

    def set_fixed_cluster_matches(self, matches):
        self.fixed_cluster_matches = matches

    def clear_fixed_cluster_matches(self):
        self.fixed_cluster_matches = None

    def get_prototypes(self):
        prototypes = []
        for v in range(self.num_views):
            prototypes.append(self.hgnn_layers[v][0].get_prototypes())
        return prototypes

    def forward(self, X, ref_view=0):
        Z, reconstructions = self.autoEncoder(X)
        Z = [F.normalize(z, p=2, dim=1) for z in Z]
        latent_features = []
        all_final_features = []
        all_modeling_losses = []
        all_fusion_losses = []
        all_A_matrices = []
        all_He = []
        all_C_dynamic = []
        fusion_final_features = []
        fusion_A_matrices = []
        fusion_He = []
        for v in range(self.num_views):
            latent_features.append(Z[v])

        device = latent_features[0].device
        for v in range(self.num_views):
            current_features = latent_features[v]
            hgnn_v = self.hgnn_layers[v]
            num_layers = len(hgnn_v)
            for i in range(num_layers):
                current_layer = hgnn_v[i]
                output_features, A_v, He, loss_modeling, C_dynamic_v = current_layer(current_features)
                current_features = output_features

            final_features_v = current_features
            all_final_features.append(final_features_v)
            all_modeling_losses.append(loss_modeling)
            all_A_matrices.append(A_v)
            all_He.append(He)
            all_C_dynamic.append(C_dynamic_v)
        for v in range(self.num_views):
            current_features = latent_features[v].detach()
            hgnn_v = self.hgnn_layers[v]

            if v == ref_view:
                with torch.no_grad():
                    for current_layer in hgnn_v:
                        output_features, A_v, He, _, _ = current_layer(current_features)
                        current_features = output_features

                current_features = current_features.detach()
                A_v = A_v.detach()
                He = He.detach()
            else:
                for current_layer in hgnn_v:
                    output_features, A_v, He, _, _ = current_layer(current_features)
                    current_features = output_features

            fusion_final_features.append(current_features)
            fusion_A_matrices.append(A_v)
            fusion_He.append(He)
        ref_view_idx = ref_view
        A_ref = fusion_A_matrices[ref_view_idx].detach()
        aff_map = self.hgnn_layers[0][0].affiliation_map
        A_meta = F.one_hot(aff_map, num_classes=self.class_num).float().to(device)
        A_ref_c = torch.matmul(A_ref, A_meta)
        ref_cluster_ids = torch.argmax(A_ref_c, dim=1)
        all_P_c = {}        
        all_cluster_ids = {}  
        all_cluster_ids[ref_view_idx] = ref_cluster_ids

        for v in range(self.num_views):
            if v == ref_view_idx:
                continue

            A_v = fusion_A_matrices[v]
            A_v_c = torch.matmul(A_v, A_meta)
            active_cluster_ids = torch.argmax(A_v_c, dim=1)
            all_cluster_ids[v] = active_cluster_ids
            ref_He = fusion_He[ref_view_idx].detach()
            skeleton_fp_ref = self.skeleton_fingerprint_gen(ref_He)
            active_He = fusion_He[v]
            skeleton_fp_active = self.skeleton_fingerprint_gen(active_He)
            diff = skeleton_fp_active.unsqueeze(1) - skeleton_fp_ref.unsqueeze(0)
            structure_cost_matrix = torch.norm(diff, p=2, dim=2)

            fixed_matches = self.fixed_cluster_matches or {}
            if v in fixed_matches:
                row_ind, col_ind = fixed_matches[v]
            else:
                cost_matrix_np = structure_cost_matrix.detach().cpu().numpy()
                row_ind, col_ind = linear_sum_assignment(cost_matrix_np)

            P_c = torch.zeros_like(structure_cost_matrix)
            P_c[row_ind, col_ind] = 1.0
            all_P_c[v] = P_c
            X_active = fusion_final_features[v]
            X_ref = fusion_final_features[ref_view_idx].detach()
            loss_fusion_v = torch.tensor(0.0, device=device)
            tau_attn = 0.1

            for idx in range(len(row_ind)):
                active_c = row_ind[idx]
                ref_c = col_ind[idx]
                active_mask = (active_cluster_ids == active_c)
                ref_mask = (ref_cluster_ids == ref_c)
                if active_mask.sum() == 0 or ref_mask.sum() == 0:
                    continue
                Z_j = X_active[active_mask]
                Z_i = X_ref[ref_mask]       
                sim = torch.matmul(Z_j, Z_i.t()) / tau_attn 
                A_ji = F.softmax(sim, dim=1)              
                target = torch.matmul(A_ji, Z_i) 
                loss_node = F.mse_loss(Z_j, target)
                t_j = skeleton_fp_active[active_c]
                t_i = skeleton_fp_ref[ref_c]        
                loss_topo = F.mse_loss(t_j, t_i)

                loss_fusion_v = loss_fusion_v + loss_node + loss_topo

            if len(row_ind) > 0:
                loss_fusion_v = loss_fusion_v / self.class_num
            else:
                loss_fusion_v = torch.tensor(0.0, device=device)

            all_fusion_losses.append(loss_fusion_v)
        X_ref = fusion_final_features[ref_view_idx]
        fused_features = torch.zeros_like(X_ref)
        fusion_temp = 10.0
        for ref_c in range(self.class_num):
            ref_mask = (ref_cluster_ids == ref_c)
            if ref_mask.sum() == 0:
                continue
            Z_i = X_ref[ref_mask]
            sum_fused = Z_i.clone()
            count = 1
            for v in range(self.num_views):
                if v == ref_view_idx:
                    continue
                P_c_v = all_P_c[v]
                active_c = torch.argmax(P_c_v[:, ref_c]).item()
                active_cluster_ids_v = all_cluster_ids[v]
                active_mask = (active_cluster_ids_v == active_c)
                if active_mask.sum() == 0:
                    continue

                Z_j = fusion_final_features[v][active_mask]
                sim = torch.matmul(Z_i, Z_j.t()) / fusion_temp 
                A_tilde = F.softmax(sim, dim=1)                 
                replica = torch.matmul(A_tilde, Z_j)      
                sum_fused = sum_fused + replica
                count += 1
            fused_c = sum_fused / count
            fused_features[ref_mask] = fused_c
        modeling_losses = torch.stack(all_modeling_losses)
        weights = torch.ones_like(modeling_losses)
        loss_modeling = torch.mean(modeling_losses * weights)
        if all_fusion_losses:
            loss_fusion = torch.mean(torch.stack(all_fusion_losses))
        else:
            loss_fusion = torch.tensor(0.0, device=device)

        return (all_final_features, fused_features, loss_modeling, latent_features,
                all_A_matrices, loss_fusion, all_He, reconstructions)
