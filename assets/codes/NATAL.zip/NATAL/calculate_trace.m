function [ E ] = calculate_trace( sigma, G )

[U,S,V] = svd(G);
S(S > sigma) = S(S > sigma) - sigma;
S(S < (-sigma)) = S(S < (-sigma)) + sigma;
S(intersect(find(S > (-sigma)),find(S < sigma))) = 0;
E = U*S*V';

end