function Outputs = predict( test_data, W )

Outputs = W' * test_data';

end

