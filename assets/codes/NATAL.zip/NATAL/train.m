function W = train( train_data,train_p_target )

train_data = train_data';
[fea_num, ins_num] = size(train_data);
lab_num = size(train_p_target,1);

X = train_data;%d*n
Y = train_p_target;
W = ones(fea_num, lab_num);%d*q
E = ones(fea_num, ins_num);

alpha = 1;
beta = 1e-6;
lambda = 1e-2;

tau_w = norm(E'*E,'fro');
tau_e = norm(W'*W,'fro');
loss_former = 0;

for iter = 1 : 100

        
    W = calculate_trace(alpha/(tau_w),(W - (1/tau_w) * (X + E) * (W' * (X + E) - Y)'));
        
    E = calculate_trace(2*lambda/((1+2*beta)*tau_e),(E - (1/((1/2+beta)*tau_e)) * (W * (Y - W' * (X + E))...
        -4*beta*(X+E)*(Y'*Y-(X+E)'*(X+E)) )));


    loss_later = 1/2 *(norm(Y - W' * (X + E),'fro'))^2 + alpha * (sum(svd(W))) + lambda * (sum(svd(E)));
    loss_later = loss_later + (norm(Y'*Y-(X+E)'*(X+E),'fro'))^2;
     
    if (abs(loss_later - loss_former) < 0.0010 * 1e-2)
        break;
    end
    
    loss_former = loss_later;

end

end

