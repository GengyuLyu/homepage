
load('emotions2.mat');

partial_target = partial_labels;

[row,col]=size(data);

data = zscore(data);

nfold = 10;
encode=crossvalind('Kfold',data(1:row,col),nfold);
for i = 1 : 10
    test = (encode == i);
    train_data = data(~test, :);
    test_data = data(test, :);
    train_p_target = partial_target(:, ~test);
    test_GT = target(:, test);
    train_GT = target(:, ~test);
    
    %training
    W = train(train_data, train_p_target);
    
    % prediction
    Outputs = predict(test_data, W);
    % normalize the outputs
    for iter = 1 : size(test_data,1)
        max_value = max(Outputs(:,iter));
        Outputs(:,iter) = Outputs(:,iter)/max_value;
    end

    
end
    
    
    
    
    