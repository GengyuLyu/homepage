import numpy as np
import scipy.io as sio
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import Dataset
import torch

import h5py
import scipy.sparse as scsp


class MultiViewDataset(Dataset):
    def __init__(self, data_name, data_X, data_Y):
        super(MultiViewDataset, self).__init__()
        self.data_name = data_name

        self.X = dict()
        self.num_views = data_X.shape[0]
        # 对视图数据归一化
        for v in range(self.num_views):
            self.X[v] = self.normalize(data_X[v])

        self.Y = data_Y
        self.Y = np.squeeze(self.Y)
        # 调整标签值
        if np.min(self.Y) == 1:
            self.Y = self.Y - 1
        self.Y = self.Y.astype(dtype=np.int64)
        self.num_classes = len(np.unique(self.Y))
        self.dims = self.get_dims()

    # 获取下标index在所有视图下的数据与对应的标签
    def __getitem__(self, index):
        data = dict()
        # print(len(self.X))
        for v_num in range(len(self.X)):
            # print(self.X[v_num].shape)
            data[v_num] = (self.X[v_num][index]).astype(np.float32)
        target = self.Y[index]
        return data, target, index

    def __len__(self):
        return len(self.X[0])

    def get_dims(self):
        dims = []
        for view in range(self.num_views):
            dims.append([self.X[view].shape[1]])
        return np.array(dims)

    @staticmethod
    def normalize(x, min=0):
        if min == 0:
            scaler = MinMaxScaler((0, 1))
        else:  # min=-1
            scaler = MinMaxScaler((-1, 1))
        norm_x = scaler.fit_transform(x)
        return norm_x

    def postprocessing(self, index, addNoise=False, sigma=0, ratio_noise=0.5, addConflict=False, ratio_conflict=0.5):
        if addNoise:
            self.addNoise(index, ratio_noise, sigma=sigma)
        if addConflict:
            self.addConflict(index, ratio_conflict)
        pass

    def addNoise(self, index, ratio, sigma):
        selects = np.random.choice(index, size=int(ratio * len(index)), replace=False)
        for i in selects:
            views = np.random.choice(np.array(self.num_views), size=np.random.randint(self.num_views), replace=False)
            for v in views:
                self.X[v][i] = np.random.normal(self.X[v][i], sigma)
        pass

    def addConflict(self, index, ratio):
        records = dict()
        for c in range(self.num_classes):
            i = np.where(self.Y == c)[0][0]
            temp = dict()
            for v in range(self.num_views):
                temp[v] = self.X[v][i]
            records[c] = temp
        selects = np.random.choice(index, size=int(ratio * len(index)), replace=False)
        for i in selects:
            v = np.random.randint(self.num_views)
            self.X[v][i] = records[(self.Y[i] + 1) % self.num_classes][v]
        pass


def HandWritten():
    # dims of views: 240 76 216 47 64 6
    # data_path = "data/handwritten.mat"
    # data_path = "../data/handwritten.mat"
    # data_path = "./data/handwritten.mat"
    data_path = "../data/handwritten.mat"
    # data_path = "~/MultiView_data/handwritten.mat"
    data = sio.loadmat(data_path)
    data_X = data['X'][0]
    data_Y = data['Y']
    return MultiViewDataset("HandWritten", data_X, data_Y)


def Scene():
    # dims of views: 20 59 40
    data_path = "./data/scene15_mtv.mat"
    data = sio.loadmat(data_path)

    # data = h5py.File(data_path, 'r')

    data_X = data['X'][0]

    data_Y = data['gt']
    # data_Y = data['Y']
    for v in range(len(data_X)):
        data_X[v] = data_X[v].T
    return MultiViewDataset("Scene", data_X, data_Y)


def PIE():
    # dims of views: 484 256 279
    data_path = "data/PIE_face_10.mat"
    data = sio.loadmat(data_path)
    data_X = data['X'][0]
    data_Y = data['gt']
    for v in range(len(data_X)):
        data_X[v] = data_X[v].T
        print(data_X[v].shape)
    return MultiViewDataset("PIE", data_X, data_Y)

def BBCSPORT():

    data_path = "./data/bbcsport.mat"
    # data_path = "data/scene15.mat"

    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))

        data_Y = file['Y'][:]

        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data = np.array(data_ref['data'][()])
            ir = np.array(data_ref['ir'][()])
            jc = np.array(data_ref['jc'][()])
            data_matrix = (scsp.csc_matrix((data, ir, jc))).T
            # print(data_matrix.shape)
            data_X.append(data_matrix.toarray())
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)

    return MultiViewDataset("BBSPORT", data_X, data_Y)


def Caltech101():
    # dims of views: 484 256 279
    data_path = "data/Caltech101-all.mat"

    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))

        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64)
            # print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)
    return MultiViewDataset("Caltech101", data_X, data_Y)


def Aloi100():
    data_path = "data/Aloi-100.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))

        data_Y = file['Y'][:]
        print(data_Y.shape)
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64)
            # print(data_array.shape)
            data_X.append(data_array)
            print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)
    return MultiViewDataset("Aloi100", data_X, data_Y)


def Animal():
    data_path = "../data/Animal.mat"
    data = sio.loadmat(data_path)
    data_X = data['X'][0]
    data_Y = data['Y']
    for v in range(len(data_X)):
        data_X[v] = data_X[v]
        print(data_X[v].shape)
    return MultiViewDataset("Animal", data_X, data_Y)


def CCV():
    data_path = "data/CCV.mat"

    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))

        data_Y = file['Y'][:]

        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64).T
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        # for v in range(len(data_X)):
        #     data_X[v] = data_X[v].T
            # print(data_X[v].shape)
    return MultiViewDataset("CCV", data_X, data_Y)

def MFeat():
    data_path = "data/Mfeat.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64)
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)
    return MultiViewDataset("Mfeat", data_X, data_Y)

def NGs():
    data_path = "data/NGs.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64).T
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        # for v in range(len(data_X)):
        #     data_X[v] = data_X[v].T
        #     print(data_X[v].shape)
    return MultiViewDataset("NGs", data_X, data_Y)


def NGs():
    data_path = "data/NGs.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64).T
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        # for v in range(len(data_X)):
        #     data_X[v] = data_X[v].T
        #     print(data_X[v].shape)
    return MultiViewDataset("NGs", data_X, data_Y)


def Cifar10():
    data_path = "data/cifar10.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64)
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)
    return MultiViewDataset("Cifar10", data_X, data_Y)


def YoutubeFace():
    data_path = "data/YoutubeFace.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64)
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        for v in range(len(data_X)):
            data_X[v] = data_X[v].T
            print(data_X[v].shape)
    return MultiViewDataset("YoutubeFace", data_X, data_Y)

def NoisyMNIST():
    data_path = "data/NoisyMNIST-30000.mat"
    data = sio.loadmat(data_path)
    print(data.keys())
    data_X1 = data['X1']
    data_X2 = data['X2']
    data_Y = data['Y']
    data_X = []
    data_X.append(data_X1)
    print(data_X1.shape)
    data_X.append(data_X2)
    print(data_X2.shape)
    data_X = np.array(data_X)
    return MultiViewDataset("NoisyMNIST", data_X, data_Y)

def Leaves100():
    data_path = "data/100Leaves.mat"
    with h5py.File(data_path, 'r') as file:
        print("Keys in file:", list(file.keys()))
        data_Y = file['Y'][:]
        data_X = []
        for ref in file['X']:
            # Dereference the HDF5 reference
            data_ref = file[ref[0]]  # Dereference first element (assuming each column is a reference)
            data_array = np.array(data_ref).astype(np.float64).T
            print(data_array.shape)
            data_X.append(data_array)
            # print('Array:', data_array.shape)
        data_X = np.array(data_X)
        # for v in range(len(data_X)):
        #     data_X[v] = data_X[v].T
        #     print(data_X[v].shape)
    return MultiViewDataset("Leaves100", data_X, data_Y)


def Hdigit():
    data_path = "data/Hdigit.mat"
    data = sio.loadmat(data_path)
    print(data.keys())
    data_X = data['data'][0]
    data_Y = data['truelabel'][0][0]
    print(data_Y.shape)
    # print(np.sum(np.abs(data_Y[1]-data_Y[0])))

    for v in range(len(data_X)):
        data_X[v] = data_X[v].T
        print(data_X[v].shape)
    return MultiViewDataset("Hdigit", data_X, data_Y)

