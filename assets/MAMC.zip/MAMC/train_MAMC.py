import numpy as np
import torch
import torch.optim as optim
from torch.utils.data import DataLoader, Subset

from data import *
from model import MAMC

from sklearn.metrics import f1_score

import random

np.set_printoptions(precision=4, suppress=True)


def normal(args):

    dataset = Scene()

    print('DataSet:', dataset.data_name)
    num_samples = len(dataset)
    # print('Samples:', num_samples)
    num_classes = dataset.num_classes
    num_views = dataset.num_views
    dims = dataset.dims
    index = np.arange(num_samples)
    np.random.shuffle(index)
    train_index, test_index = index[:int(0.8 * num_samples)], index[int(0.8 * num_samples):]
    train_loader = DataLoader(Subset(dataset, train_index), batch_size=args.batch_size, shuffle=True, drop_last=True)
    test_loader = DataLoader(Subset(dataset, test_index), batch_size=args.batch_size, shuffle=False)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")

    model = MAMC(num_views, dims, 512, num_classes, args.rule_num, device)

    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=0.98, weight_decay=0.)

    model.to(device)
    model.train()
    criterion = torch.nn.CrossEntropyLoss()
    prototype_init = True  # Initiate the prototypes at the first epoch
    for epoch in range(1, args.epochs + 1):
        for X, Y, indexes in train_loader:
            loss = 0
            for v in range(num_views):
                X[v] = X[v].to(device)
            Y = Y.to(device)
            hiddens, restore_X = model(X)
            loss += args.alpha * model.Instance_loss(hiddens, tau=args.tau1)
            loss += args.beta * model.Fuzzy_Prototype_loss(hiddens, Y, tau=args.tau2, pro_init=prototype_init)
            loss += model.ReconstrctionLoss(X, restore_X)
            prediction = model.ClassifierLists.classify(hiddens)
            loss += criterion(prediction, Y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        prototype_init = False

        if epoch % 50 == 0:
            model.eval()
            num_correct, num_sample = 0, 0
            pred = []
            true_label = []
            for X, Y, indexes in test_loader:
                for v in range(num_views):
                    X[v] = X[v].to(device)
                Y = Y.to(device)

                with torch.no_grad():
                    hiddens, restore_X = model(X)
                    prediction = model.ClassifierLists.classify(hiddens)
                    _, Y_pre = torch.max(prediction, dim=1)
                    true_label.append(Y.cpu().numpy())
                    pred.append(Y_pre.cpu().numpy())
                    num_correct += (Y_pre == Y).sum().item()
                    num_sample += Y.shape[0]
            acc = num_correct / num_sample
            pred = np.concatenate(pred)
            true_label = np.concatenate(true_label)
            macro = f1_score(true_label, pred, average="macro")
            weighted = f1_score(true_label, pred, average="weighted")

            print(f'====> {epoch}')
            print('Acc:', acc)
            print('MaF1:', macro)
            print('Weighted F1:', weighted)


    model.eval()
    num_correct, num_sample = 0, 0
    pred = []
    true_label = []
    for X, Y, indexes in test_loader:
        for v in range(num_views):
            X[v] = X[v].to(device)
        Y = Y.to(device)

        with torch.no_grad():
            hiddens, restore_X = model(X)
            prediction = model.ClassifierLists.classify(hiddens)
            _, Y_pre = torch.max(prediction, dim=1)
            true_label.append(Y.cpu().numpy())
            pred.append(Y_pre.cpu().numpy())
            num_correct += (Y_pre == Y).sum().item()
            num_sample += Y.shape[0]
    acc = num_correct / num_sample
    pred = np.concatenate(pred)
    true_label = np.concatenate(true_label)
    macro = f1_score(true_label, pred, average="macro")
    weighted = f1_score(true_label, pred, average="weighted")

    print(f'====> {epoch}')
    print('Acc:', acc)
    print('MaF1:', macro)
    print('Weighted F1:', weighted)
    return acc


def set_random_seeds(random_seed=0):
    r"""Sets the seed for generating random numbers."""
    torch.manual_seed(random_seed)
    torch.cuda.manual_seed(random_seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(random_seed)
    random.seed(random_seed)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    #
    parser.add_argument('--batch-size', type=int, default=256, metavar='N', help='input batch size for training [default: 100]')
    parser.add_argument('--epochs', type=int, default=160, metavar='N', help='number of epochs to train [default: 500]')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR', help='learning rate')
    parser.add_argument('--tau1', type=float, default=3., metavar='LR', help='temperature coefficient')
    parser.add_argument('--tau2', type=float, default=1.2, metavar='LR', help='temperature coefficient')
    parser.add_argument('--alpha', type=float, default=0.05, metavar='LR', help='penalty coefficient')
    parser.add_argument('--beta', type=float, default=0.01, metavar='LR', help='penalty coefficient')
    parser.add_argument('--rule_num', type=int, default=5, metavar='N', help='number of rules')
    args = parser.parse_args()

    seed = 42
    set_random_seeds(seed)

    repeat = 10
    acc_list = []
    for i in range(repeat):
        set_random_seeds(seed + i)
        acc_list.append(normal(args))
    print('Mean_Acc:', np.mean(acc_list), '±', np.std(acc_list))
