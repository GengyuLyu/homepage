import torch.nn as nn
import torch.nn.functional as F
import torch
import torch.nn.init as Init
import numpy as np


class MAMC(nn.Module):
    def __init__(self, num_views, dims, dim_hidden, num_classes, n_rule, device):
        super(MAMC, self).__init__()
        self.num_views = num_views
        self.dim_hidden = dim_hidden
        self.num_classes = num_classes
        self.n_rule = n_rule
        self.device = device

        self.EncoderLists = nn.ModuleList([EncoderList(dims[i], self.dim_hidden) for i in range(self.num_views)])
        self.DecoderLists = nn.ModuleList([DecoderList(self.dim_hidden, dims[i]) for i in range(self.num_views)])
        self.ClassifierLists = ClassifierList(self.dim_hidden, self.num_classes)
        self.fls = Fuzzifier(self.dim_hidden, n_rules=self.n_rule).to(self.device)
        self.mlp = MLP_Projector(self.dim_hidden * 2, self.dim_hidden)

        self.prototypes = dict()  # crisp prototypes
        self.fuzzy_prototypes = dict()  # fuzzy prototypes
        self.fused_prototypes = dict()  # fuse the crisp prototypes and fuzzy prototypes
        self.init_prototypes = dict()  # store the initial prototypes at the first epoch
        self.ins_counter = []  # count instance number of each class

        self.Init()
        self.init_idx_pairs()
        self.first_prototype = True  # first to calculate the prototypes

    def forward(self, X):
        # get evidence
        hiddens = dict()
        restore_X = dict()
        for v in range(self.num_views):
            hiddens[v] = self.EncoderLists[v](X[v])
            restore_X[v] = self.DecoderLists[v](hiddens[v])

        return hiddens, restore_X

    #  Initiate the prototypes and the counter
    def Init(self):
        for i in range(self.num_classes):
            self.prototypes[i] = torch.zeros((1, self.dim_hidden)).to(self.device)
            self.fuzzy_prototypes[i] = torch.zeros((1, self.dim_hidden)).to(self.device)
            self.fused_prototypes[i] = torch.zeros((1, self.dim_hidden)).to(self.device)
            self.init_prototypes[i] = torch.zeros((1, self.dim_hidden)).to(self.device)
            self.ins_counter.append(0)

    def init_idx_pairs(self):
        idx_pairs = []
        torch.tensor([[0, 1], [0, 2], [1, 2]])
        for i in range(self.num_views):
            for j in range(i, self.num_views):
                idx_pairs.append([i, j])
        self.idx_pairs = torch.tensor(idx_pairs)

    def ReconstrctionLoss(self, X, restore_X):
        recon_loss = 0
        for v in range(self.num_views):
            recon1 = F.mse_loss(X[v], restore_X[v])
            recon_loss += recon1
        return recon_loss / self.num_views

    def Instance_loss(self, x, tau=1.):
        f = lambda x: torch.exp(x * tau)
        x = torch.cat([x[i].unsqueeze(0) for i in range(self.num_views)])

        x1 = x[self.idx_pairs[:, 0]]
        x2 = x[self.idx_pairs[:, 1]]

        sim_matrices = f(torch.bmm(x1, x2.permute(0, 2, 1)))

        diag = torch.diagonal(sim_matrices, dim1=1, dim2=2)
        loss = -torch.log(diag / sim_matrices.sum(2)).mean()

        return loss

    # calculate similarity matrices for representation matrices in each view
    def Prototype_loss(self, x, y, tau=1., pro_init=True, tradeoff=0.99):
        f = lambda t: torch.exp(t * tau)

        positive_set = self.Prototype_Unpdate(x, y, pro_init=pro_init, tradeoff=tradeoff)  # store the positives for each class
        prototype_matrix = []  # collect the prototype vectors into a matrx for computing efficiently
        for i in range(self.num_classes):
            self.prototypes[i] = F.normalize(self.prototypes[i], p=2.0).detach()
            prototype_matrix.append(self.prototypes[i])
        prototype_matrix = torch.cat(prototype_matrix)

        proto_loss = 0
        for i in range(self.num_classes):
            if len(positive_set[i]) <= self.num_views:
                continue

            sim_ins_pro = f(torch.mm(positive_set[i], prototype_matrix.T))  # similarity matrix between instances and prototypes
            proto_loss += -torch.log(sim_ins_pro[:, i] / sim_ins_pro.sum(1)).mean()

        return proto_loss / self.num_classes

    # update the prototypes and collect the positives for each class
    def Prototype_Unpdate(self, x, y, pro_init=True, tradeoff=0.99):
        label_index_set = dict()
        positive_collector = dict()  # collect positive samples with the same label
        for i in range(self.num_classes):
            positive_collector[i] = []
            label_index_set[i] = torch.where(y == i)
            temp = 0
            for j in range(self.num_views):
                temp += x[j][label_index_set[i]]
                positive_collector[i].append(x[j][label_index_set[i]])
            same_label_x_num = temp.shape[0]  # number of instances with same label

            if same_label_x_num == 0:
                continue

            num = same_label_x_num * self.num_views
            temp = torch.sum(temp, dim=0)
            temp = torch.unsqueeze(temp, dim=0)

            if pro_init is True:
                self.init_prototypes[i] += temp
                self.ins_counter[i] += num  # update the counter
                self.prototypes[i] = self.init_prototypes[i] / self.ins_counter[i]
            else:
                temp = temp / num
                self.prototypes[i] = tradeoff * self.prototypes[i] + (1 - tradeoff) * temp
            positive_collector[i] = torch.cat(positive_collector[i])

        return positive_collector

    def Fuzzy_Prototype_loss(self, x, y, tau=1., pro_init=True, tradeoff=0.9):
        f = lambda t: torch.exp(t * tau)

        # Store the centralized positives for each class
        positive_set = self.Prototype_Unpdate(x, y, pro_init=pro_init, tradeoff=tradeoff)
        prototype_matrix = []
        fuzzy_boundary_element_set = dict()

        prototypes_count = 0  # count the number of prototypes

        # Construct the fuzzy boundary
        for i in range(self.num_classes):
            self.prototypes[i] = self.prototypes[i].detach()
            if len(positive_set[i]) <= self.num_views:
                continue
            positive_set[i] = positive_set[i] - self.prototypes[i]
            fuzzy_boundary_element_set[i] = self.Calculate_Fuzzy_Boundary(positive_set[i]) + self.prototypes[i]
            fuzzy_prototype = torch.mean(fuzzy_boundary_element_set[i], dim=0).unsqueeze(dim=0)

            fused_prototype = tradeoff * self.prototypes[i] + (1 - tradeoff) * fuzzy_prototype
            prototype_matrix.append(F.normalize(fused_prototype, p=2.0))

            prototypes_count += 1
        # print(prototype_matrix)
        prototype_matrix = torch.cat(prototype_matrix).detach()

        proto_loss = 0
        # for i in range(self.num_classes):
        for i in range(prototypes_count):
            if len(positive_set[i]) <= self.num_views:
                continue
            sim_ins_pro = f(-dis_fun(fuzzy_boundary_element_set[i], prototype_matrix) * tau)
            proto_loss += -torch.log(sim_ins_pro[:, i] / sim_ins_pro.sum(1)).mean()

        return proto_loss / self.num_classes

    # Centralize the representations
    def Centralize_with_Prototypes(self, x, y, pro_init=True, tradeoff=0.99):
        label_index_set = dict()
        centralized_positive_collector = dict()  # collect positive samples with the same label
        for i in range(self.num_classes):
            centralized_positive_collector[i] = []
            label_index_set[i] = torch.where(y == i)
            temp = 0
            for j in range(self.num_views):
                temp += x[j][label_index_set[i]]
                centralized_positive_collector[i].append(x[j][label_index_set[i]])
            same_label_x_num = temp.shape[0]  # number of instances with same label

            if same_label_x_num == 0:
                continue

            num = same_label_x_num * self.num_views
            temp = torch.sum(temp, dim=0)
            temp = torch.unsqueeze(temp, dim=0)

            if pro_init is True:
                self.init_prototypes[i] += temp
                self.ins_counter[i] += num  # update the counter
                self.prototypes[i] = self.init_prototypes[i] / self.ins_counter[i]

            centralized_positive_collector[i] = torch.cat(centralized_positive_collector[i])
        return centralized_positive_collector

    def Calculate_Fuzzy_Boundary(self, x):
        fz_degree, x = self.fls.fuzzify(x)
        return x

    def Update_Fused_Prototype(self, fuzzy_prototype, alpha=0.99):
        fused_prototypes = alpha * self.prototypes + (1 - alpha) * fuzzy_prototype
        return fused_prototypes


def sim(z1, z2):
    z1 = F.normalize(z1)
    z2 = F.normalize(z2)
    return torch.mm(z1, z2.t())


def dis_fun(x, c):
    xx = (x * x).sum(-1).reshape(-1, 1).repeat(1, c.shape[0])
    cc = (c * c).sum(-1).reshape(1, -1).repeat(x.shape[0], 1)
    xx_cc = xx + cc
    xc = x @ c.T
    distance = xx_cc - 2 * xc
    return distance


class EncoderList(nn.Module):
    def __init__(self, dims, dim_hidden):
        super(EncoderList, self).__init__()
        dim_list = [dims.item(), int(1.4 * dim_hidden), int(1.2 * dim_hidden)]
        self.num_layers = len(dim_list)
        self.net = nn.ModuleList()
        for i in range(self.num_layers - 1):
            self.net.append(nn.Linear(dim_list[i], dim_list[i + 1]))
            self.net.append(nn.ReLU())
            self.net.append(nn.Dropout(0.15))
        self.net.append(nn.Linear(dim_list[self.num_layers - 1], dim_hidden))

    def forward(self, x):
        h = self.net[0](x)
        for i in range(1, len(self.net)):
            h = self.net[i](h)
        h = F.normalize(h, p=2.0)
        return h


class DecoderList(nn.Module):
    def __init__(self, dim_hidden, dims):
        super(DecoderList, self).__init__()
        dim_list = [dim_hidden, int(0.6 * dims.item()), int(0.8 * dims.item())]
        self.num_layers = len(dim_list)
        self.net = nn.ModuleList()
        for i in range(self.num_layers - 1):
            self.net.append(nn.Linear(dim_list[i], dim_list[i + 1]))
            self.net.append(nn.ReLU())
            self.net.append(nn.Dropout(0.1))
        self.net.append(nn.Linear(dim_list[self.num_layers - 1], dims.item()))

    def forward(self, x):
        h = self.net[0](x)
        for i in range(1, len(self.net)):
            h = self.net[i](h)
        return h


class ClassifierList(nn.Module):
    def __init__(self, dims, num_classes):
        super(ClassifierList, self).__init__()
        # self.num_layers = len(dims)
        self.num_layers = 1
        self.net = nn.ModuleList()
        for i in range(self.num_layers - 1):
            self.net.append(nn.Linear(dims, dims))
            self.net.append(nn.ReLU())
            self.net.append(nn.Dropout(0.1))
        self.net.append(nn.Linear(dims, num_classes))


    def forward(self, x):
        # source code
        h = self.net[0](x)
        for i in range(1, len(self.net)):
            h = self.net(h)
        return h

    def classify(self, x):
        view_num = len(x)

        pred = 0
        h = dict()
        for i in range(view_num):
            for j in range(0, len(self.net)):
                h[i] = self.net[j](x[i])
                pred += h[i]
        pred /= view_num

        return pred


class MLP_Projector(nn.Module):
    def __init__(self, input_size, output_size, hidden_size=512, dropout=0.2):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(input_size, hidden_size, bias=True),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size, bias=True),
        )
        self.reset_parameters()

    def forward(self, x):
        return self.net(x)

    def reset_parameters(self):
        # kaiming_uniform
        for m in self.modules():
            if isinstance(m, nn.Linear):
                m.reset_parameters()


class Fuzzifier(nn.Module):
    def __init__(self, in_dim, n_rules, fz=True):
        super(Fuzzifier, self).__init__()
        self.in_dim = in_dim
        self.n_rules = n_rules
        self.fz = fz  # whether to do fuzzifying operation
        self.eps = 1e-10
        #self.init_centers = None
        #self.init_Vs = None

        self.build_model()

    def build_model(self):
        if self.fz == True:  # create antecedent parameters
            self.fz_weight = nn.Parameter(torch.FloatTensor(size=(1, self.n_rules)), requires_grad=True)
            Init.uniform_(self.fz_weight, 0, 1)

            self.Cs = nn.Parameter(torch.FloatTensor(size=(self.in_dim, self.n_rules)), requires_grad=True)
            Init.normal_(self.Cs, mean=0, std=1)
            self.Vs = nn.Parameter(torch.FloatTensor(size=self.Cs.size()), requires_grad=True)
            Init.uniform_(self.Vs, 0, 1)

    # This process has calculated the fuzzy boundary
    def fuzzify(self, features):
        fz_degree = -(features.unsqueeze(dim=2) - self.Cs) ** 2 / ((2 * self.Vs ** 2) + self.eps)

        if self.fz == True:
            fz_degree = torch.exp(fz_degree)
            weighted_fz_degree = torch.min(fz_degree, dim=2)[0]
        fz_features = torch.mul(features, 2. - weighted_fz_degree)

        return weighted_fz_degree, fz_features
